use plugify::register_plugin; // Подключаем макрос, который "регистрирует" плагин в движке CS2
use std::error::Error;        // Подключаем стандартный инструмент для работы с любыми ошибками
use std::sync::Mutex;         // Подключаем "электронный замок" для защиты глобальных данных
mod s2sdk;                    // Говорим компилятору: "найди и подключи наш файл s2sdk.rs"
mod chat;                     // Говорим компилятору: "найди и подключи наш файл chat.rs"
mod config;                   // Говорим компилятору: "найди и подключи наш файл config.rs"

// Чертёж (структура) для хранения состояния таймера рекламы
struct AdvertTimer {
    elapsed: f32,              // Сколько секунд прошло с последнего показа рекламы
    current_index: usize,      // Номер текущего сообщения в списке
    interval_seconds: f32,     // Интервал между рекламами из конфига
    messages: Vec<String>,     // Список рекламных сообщений, загруженный из конфига
}

static ADVERT_TIMER: Mutex<AdvertTimer> = Mutex::new(AdvertTimer {
    elapsed: 0.0,
    current_index: 0,
    interval_seconds: 30.0,
    messages: Vec::new(),
});

fn on_plugin_start() -> Result<(), Box<dyn Error>> {
    println!("[Advert] Plugin successfully loaded");

    let config = config::Config::load()?;

    let mut state = ADVERT_TIMER
        .lock()
        .map_err(|e| format!("[Advert] Failed to lock advert timer on start: {}", e))?;

    // elapsed инициализируем равным interval_seconds — первый показ произойдёт
    // ровно через один полный интервал после старта плагина.
    *state = AdvertTimer {
        elapsed: 0.0,
        current_index: 0,
        interval_seconds: config.adverts.interval_seconds,
        messages: config.adverts.messages,
    };

    Ok(())
}

fn on_plugin_update(dt: f32) -> Result<(), Box<dyn Error>> {
    // Берём сообщение под замком, сразу освобождаем его —
    // FFI-вызов chat::print_colored_to_all происходит уже без удержания мьютекса.
    let message_to_send: Option<String> = {
        let mut timer = ADVERT_TIMER
            .lock()
            .map_err(|e| format!("[Advert] Failed to lock advert timer on update: {}", e))?;

        if timer.messages.is_empty() {
            None
        } else {
            timer.elapsed += dt;

            if timer.elapsed >= timer.interval_seconds {
                let msg = timer.messages[timer.current_index].clone();
                timer.current_index = (timer.current_index + 1) % timer.messages.len();
                timer.elapsed = 0.0;
                Some(msg)
            } else {
                None
            }
        }
    }; // <- замок освобождается здесь

    if let Some(msg) = message_to_send {
        chat::print_colored_to_all(&msg);
    }

    Ok(())
}

fn on_plugin_end() -> Result<(), Box<dyn Error>> {
    println!("[Advert] Plugin successfully unloaded");
    Ok(())
}

register_plugin!(
    start: on_plugin_start,
    update: on_plugin_update,
    end: on_plugin_end
);
