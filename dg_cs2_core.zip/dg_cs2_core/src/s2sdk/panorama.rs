// Generated from s2sdk.pplugin (group: panorama)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Start a new Yes/No vote
///
/// # Arguments
/// * `duration` - (double): Maximum time to leave vote active for
/// * `caller` - (int32): Player slot of the vote caller. Use VOTE_CALLER_SERVER for 'Server'.
/// * `voteTitle` - (string): Translation string to use as the vote message. (Only '#SFUI_vote' or '#Panorama_vote' strings)
/// * `detailStr` - (string): Extra string used in some vote translation strings.
/// * `votePassTitle` - (string): Translation string to use as the vote message. (Only '#SFUI_vote' or '#Panorama_vote' strings)
/// * `detailPassStr` - (string): Extra string used in some vote translation strings when the vote passes.
/// * `failReason` - (int32): Reason for the vote to fail, used in some translation strings.
/// * `filter` - (uint64): Recipient filter with all the clients who are allowed to participate in the vote.
/// * `result` - (function): Called when a menu action is completed.
/// * `handler` - (function): Called when the vote has finished.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PanoramaSendYesNoVote(duration: f64, caller: i32, voteTitle: &Str, detailStr: &Str, votePassTitle: &Str, detailPassStr: &Str, failReason: VoteCreateFailed, filter: u64, result: YesNoVoteResult, handler: YesNoVoteHandler) -> bool {
    unsafe { __s2sdk_PanoramaSendYesNoVote.expect("PanoramaSendYesNoVote function was not found")(duration, caller, voteTitle, detailStr, votePassTitle, detailPassStr, failReason, filter, result, handler) }
}
pub type _PanoramaSendYesNoVote = unsafe extern "C" fn(f64, i32, &Str, &Str, &Str, &Str, VoteCreateFailed, u64, YesNoVoteResult, YesNoVoteHandler) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PanoramaSendYesNoVote: Option<_PanoramaSendYesNoVote> = None;

/// Start a new Yes/No vote with all players included
///
/// # Arguments
/// * `duration` - (double): Maximum time to leave vote active for
/// * `caller` - (int32): Player slot of the vote caller. Use VOTE_CALLER_SERVER for 'Server'.
/// * `voteTitle` - (string): Translation string to use as the vote message. (Only '#SFUI_vote' or '#Panorama_vote' strings)
/// * `detailStr` - (string): Extra string used in some vote translation strings.
/// * `votePassTitle` - (string): Translation string to use as the vote message. (Only '#SFUI_vote' or '#Panorama_vote' strings)
/// * `detailPassStr` - (string): Extra string used in some vote translation strings when the vote passes.
/// * `failReason` - (int32): Reason for the vote to fail, used in some translation strings.
/// * `result` - (function): Called when a menu action is completed.
/// * `handler` - (function): Called when the vote has finished.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PanoramaSendYesNoVoteToAll(duration: f64, caller: i32, voteTitle: &Str, detailStr: &Str, votePassTitle: &Str, detailPassStr: &Str, failReason: VoteCreateFailed, result: YesNoVoteResult, handler: YesNoVoteHandler) -> bool {
    unsafe { __s2sdk_PanoramaSendYesNoVoteToAll.expect("PanoramaSendYesNoVoteToAll function was not found")(duration, caller, voteTitle, detailStr, votePassTitle, detailPassStr, failReason, result, handler) }
}
pub type _PanoramaSendYesNoVoteToAll = unsafe extern "C" fn(f64, i32, &Str, &Str, &Str, &Str, VoteCreateFailed, YesNoVoteResult, YesNoVoteHandler) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PanoramaSendYesNoVoteToAll: Option<_PanoramaSendYesNoVoteToAll> = None;

/// Removes a player from the current vote.
///
/// # Arguments
/// * `playerSlot` - (int32): The slot/index of the player to remove from the vote.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PanoramaRemovePlayerFromVote(playerSlot: i32) {
    unsafe { __s2sdk_PanoramaRemovePlayerFromVote.expect("PanoramaRemovePlayerFromVote function was not found")(playerSlot) }
}
pub type _PanoramaRemovePlayerFromVote = unsafe extern "C" fn(i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PanoramaRemovePlayerFromVote: Option<_PanoramaRemovePlayerFromVote> = None;

/// Checks if a player is in the vote pool.
///
/// # Arguments
/// * `playerSlot` - (int32): The slot/index of the player to check.
///
/// # Returns - (bool):
/// true if the player is in the vote pool, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PanoramaIsPlayerInVotePool(playerSlot: i32) -> bool {
    unsafe { __s2sdk_PanoramaIsPlayerInVotePool.expect("PanoramaIsPlayerInVotePool function was not found")(playerSlot) }
}
pub type _PanoramaIsPlayerInVotePool = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PanoramaIsPlayerInVotePool: Option<_PanoramaIsPlayerInVotePool> = None;

/// Redraws the vote UI to a specific player client.
///
/// # Arguments
/// * `playerSlot` - (int32): The slot/index of the player to update.
///
/// # Returns - (bool):
/// true if the vote UI was successfully redrawn, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PanoramaRedrawVoteToClient(playerSlot: i32) -> bool {
    unsafe { __s2sdk_PanoramaRedrawVoteToClient.expect("PanoramaRedrawVoteToClient function was not found")(playerSlot) }
}
pub type _PanoramaRedrawVoteToClient = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PanoramaRedrawVoteToClient: Option<_PanoramaRedrawVoteToClient> = None;

/// Checks if a vote is currently in progress.
///
/// # Returns - (bool):
/// true if a vote is active, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PanoramaIsVoteInProgress() -> bool {
    unsafe { __s2sdk_PanoramaIsVoteInProgress.expect("PanoramaIsVoteInProgress function was not found")() }
}
pub type _PanoramaIsVoteInProgress = unsafe extern "C" fn() -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PanoramaIsVoteInProgress: Option<_PanoramaIsVoteInProgress> = None;

/// Ends the current vote with a specified reason.
///
/// # Arguments
/// * `reason` - (int32): The reason for ending the vote.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PanoramaEndVote(reason: VoteEndReason) {
    unsafe { __s2sdk_PanoramaEndVote.expect("PanoramaEndVote function was not found")(reason) }
}
pub type _PanoramaEndVote = unsafe extern "C" fn(VoteEndReason);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PanoramaEndVote: Option<_PanoramaEndVote> = None;

