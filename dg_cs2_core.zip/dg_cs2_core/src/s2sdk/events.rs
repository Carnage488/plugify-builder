// Generated from s2sdk.pplugin (group: events)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Creates a hook for when a game event is fired.
///
/// # Arguments
/// * `name` - (string): The name of the event to hook.
/// * `callback` - (function): The callback function to call when the event is fired.
/// * `type_` - (uint8): Whether the hook was in post mode (after processing) or pre mode (before processing).
///
/// # Returns - (int32):
/// An integer indicating the result of the hook operation.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn HookEvent(name: &Str, callback: EventCallback, type_: HookMode) -> EventHookError {
    unsafe { __s2sdk_HookEvent.expect("HookEvent function was not found")(name, callback, type_) }
}
pub type _HookEvent = unsafe extern "C" fn(&Str, EventCallback, HookMode) -> EventHookError;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_HookEvent: Option<_HookEvent> = None;

/// Removes a hook for when a game event is fired.
///
/// # Arguments
/// * `name` - (string): The name of the event to unhook.
/// * `callback` - (function): The callback function to remove.
/// * `type_` - (uint8): Whether the hook was in post mode (after processing) or pre mode (before processing).
///
/// # Returns - (int32):
/// An integer indicating the result of the unhook operation.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UnhookEvent(name: &Str, callback: EventCallback, type_: HookMode) -> EventHookError {
    unsafe { __s2sdk_UnhookEvent.expect("UnhookEvent function was not found")(name, callback, type_) }
}
pub type _UnhookEvent = unsafe extern "C" fn(&Str, EventCallback, HookMode) -> EventHookError;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UnhookEvent: Option<_UnhookEvent> = None;

/// Creates a game event to be fired later.
///
/// # Arguments
/// * `name` - (string): The name of the event to create.
/// * `force` - (bool): A boolean indicating whether to force the creation of the event.
///
/// # Returns - (ptr64):
/// A pointer to the created IGameEvent object.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateEvent(name: &Str, force: bool) -> usize {
    unsafe { __s2sdk_CreateEvent.expect("CreateEvent function was not found")(name, force) }
}
pub type _CreateEvent = unsafe extern "C" fn(&Str, bool) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateEvent: Option<_CreateEvent> = None;

/// Fires a game event.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `dontBroadcast` - (bool): A boolean indicating whether to broadcast the event.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FireEvent(event: usize, dontBroadcast: bool) {
    unsafe { __s2sdk_FireEvent.expect("FireEvent function was not found")(event, dontBroadcast) }
}
pub type _FireEvent = unsafe extern "C" fn(usize, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FireEvent: Option<_FireEvent> = None;

/// Fires a game event to a specific client.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `playerSlot` - (int32): The index of the client to fire the event to.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FireEventToClient(event: usize, playerSlot: i32) {
    unsafe { __s2sdk_FireEventToClient.expect("FireEventToClient function was not found")(event, playerSlot) }
}
pub type _FireEventToClient = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FireEventToClient: Option<_FireEventToClient> = None;

/// Cancels a previously created game event that has not been fired.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object of the event to cancel.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CancelCreatedEvent(event: usize) {
    unsafe { __s2sdk_CancelCreatedEvent.expect("CancelCreatedEvent function was not found")(event) }
}
pub type _CancelCreatedEvent = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CancelCreatedEvent: Option<_CancelCreatedEvent> = None;

/// Retrieves the boolean value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the boolean value.
///
/// # Returns - (bool):
/// The boolean value associated with the key.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventBool(event: usize, key: &Str) -> bool {
    unsafe { __s2sdk_GetEventBool.expect("GetEventBool function was not found")(event, key) }
}
pub type _GetEventBool = unsafe extern "C" fn(usize, &Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventBool: Option<_GetEventBool> = None;

/// Retrieves the float value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the float value.
///
/// # Returns - (float):
/// The float value associated with the key.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventFloat(event: usize, key: &Str) -> f32 {
    unsafe { __s2sdk_GetEventFloat.expect("GetEventFloat function was not found")(event, key) }
}
pub type _GetEventFloat = unsafe extern "C" fn(usize, &Str) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventFloat: Option<_GetEventFloat> = None;

/// Retrieves the integer value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the integer value.
///
/// # Returns - (int32):
/// The integer value associated with the key.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventInt(event: usize, key: &Str) -> i32 {
    unsafe { __s2sdk_GetEventInt.expect("GetEventInt function was not found")(event, key) }
}
pub type _GetEventInt = unsafe extern "C" fn(usize, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventInt: Option<_GetEventInt> = None;

/// Retrieves the long integer value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the long integer value.
///
/// # Returns - (uint64):
/// The long integer value associated with the key.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventUInt64(event: usize, key: &Str) -> u64 {
    unsafe { __s2sdk_GetEventUInt64.expect("GetEventUInt64 function was not found")(event, key) }
}
pub type _GetEventUInt64 = unsafe extern "C" fn(usize, &Str) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventUInt64: Option<_GetEventUInt64> = None;

/// Retrieves the string value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the string value.
///
/// # Returns - (string):
/// A string where the result will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventString(event: usize, key: &Str) -> Str {
    unsafe { __s2sdk_GetEventString.expect("GetEventString function was not found")(event, key) }
}
pub type _GetEventString = unsafe extern "C" fn(usize, &Str) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventString: Option<_GetEventString> = None;

/// Retrieves the pointer value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the pointer value.
///
/// # Returns - (ptr64):
/// The pointer value associated with the key.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventPtr(event: usize, key: &Str) -> usize {
    unsafe { __s2sdk_GetEventPtr.expect("GetEventPtr function was not found")(event, key) }
}
pub type _GetEventPtr = unsafe extern "C" fn(usize, &Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventPtr: Option<_GetEventPtr> = None;

/// Retrieves the player controller address of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the player controller address.
///
/// # Returns - (ptr64):
/// A pointer to the player controller associated with the key.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventPlayerController(event: usize, key: &Str) -> usize {
    unsafe { __s2sdk_GetEventPlayerController.expect("GetEventPlayerController function was not found")(event, key) }
}
pub type _GetEventPlayerController = unsafe extern "C" fn(usize, &Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventPlayerController: Option<_GetEventPlayerController> = None;

/// Retrieves the player index of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the player index.
///
/// # Returns - (int32):
/// The player index associated with the key.
#[deprecated(note = "Use GetEventPlayerSlot instead. Will be removed soon")]
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventPlayerIndex(event: usize, key: &Str) -> i32 {
    unsafe { __s2sdk_GetEventPlayerIndex.expect("GetEventPlayerIndex function was not found")(event, key) }
}
pub type _GetEventPlayerIndex = unsafe extern "C" fn(usize, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventPlayerIndex: Option<_GetEventPlayerIndex> = None;

/// Retrieves the player slot of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the player index.
///
/// # Returns - (int32):
/// The player slot associated with the key.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventPlayerSlot(event: usize, key: &Str) -> i32 {
    unsafe { __s2sdk_GetEventPlayerSlot.expect("GetEventPlayerSlot function was not found")(event, key) }
}
pub type _GetEventPlayerSlot = unsafe extern "C" fn(usize, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventPlayerSlot: Option<_GetEventPlayerSlot> = None;

/// Retrieves the player pawn address of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the player pawn address.
///
/// # Returns - (ptr64):
/// A pointer to the player pawn associated with the key.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventPlayerPawn(event: usize, key: &Str) -> usize {
    unsafe { __s2sdk_GetEventPlayerPawn.expect("GetEventPlayerPawn function was not found")(event, key) }
}
pub type _GetEventPlayerPawn = unsafe extern "C" fn(usize, &Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventPlayerPawn: Option<_GetEventPlayerPawn> = None;

/// Retrieves the entity address of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the entity address.
///
/// # Returns - (ptr64):
/// A pointer to the entity associated with the key.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventEntity(event: usize, key: &Str) -> usize {
    unsafe { __s2sdk_GetEventEntity.expect("GetEventEntity function was not found")(event, key) }
}
pub type _GetEventEntity = unsafe extern "C" fn(usize, &Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventEntity: Option<_GetEventEntity> = None;

/// Retrieves the entity index of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the entity index.
///
/// # Returns - (int32):
/// The entity index associated with the key.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventEntityIndex(event: usize, key: &Str) -> i32 {
    unsafe { __s2sdk_GetEventEntityIndex.expect("GetEventEntityIndex function was not found")(event, key) }
}
pub type _GetEventEntityIndex = unsafe extern "C" fn(usize, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventEntityIndex: Option<_GetEventEntityIndex> = None;

/// Retrieves the entity handle of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to retrieve the entity handle.
///
/// # Returns - (int32):
/// The entity handle associated with the key.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventEntityHandle(event: usize, key: &Str) -> i32 {
    unsafe { __s2sdk_GetEventEntityHandle.expect("GetEventEntityHandle function was not found")(event, key) }
}
pub type _GetEventEntityHandle = unsafe extern "C" fn(usize, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventEntityHandle: Option<_GetEventEntityHandle> = None;

/// Retrieves the name of a game event.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
///
/// # Returns - (string):
/// A string where the result will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEventName(event: usize) -> Str {
    unsafe { __s2sdk_GetEventName.expect("GetEventName function was not found")(event) }
}
pub type _GetEventName = unsafe extern "C" fn(usize) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEventName: Option<_GetEventName> = None;

/// Sets the boolean value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the boolean value.
/// * `value` - (bool): The boolean value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventBool(event: usize, key: &Str, value: bool) {
    unsafe { __s2sdk_SetEventBool.expect("SetEventBool function was not found")(event, key, value) }
}
pub type _SetEventBool = unsafe extern "C" fn(usize, &Str, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventBool: Option<_SetEventBool> = None;

/// Sets the floating point value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the float value.
/// * `value` - (float): The float value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventFloat(event: usize, key: &Str, value: f32) {
    unsafe { __s2sdk_SetEventFloat.expect("SetEventFloat function was not found")(event, key, value) }
}
pub type _SetEventFloat = unsafe extern "C" fn(usize, &Str, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventFloat: Option<_SetEventFloat> = None;

/// Sets the integer value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the integer value.
/// * `value` - (int32): The integer value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventInt(event: usize, key: &Str, value: i32) {
    unsafe { __s2sdk_SetEventInt.expect("SetEventInt function was not found")(event, key, value) }
}
pub type _SetEventInt = unsafe extern "C" fn(usize, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventInt: Option<_SetEventInt> = None;

/// Sets the long integer value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the long integer value.
/// * `value` - (uint64): The long integer value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventUInt64(event: usize, key: &Str, value: u64) {
    unsafe { __s2sdk_SetEventUInt64.expect("SetEventUInt64 function was not found")(event, key, value) }
}
pub type _SetEventUInt64 = unsafe extern "C" fn(usize, &Str, u64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventUInt64: Option<_SetEventUInt64> = None;

/// Sets the string value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the string value.
/// * `value` - (string): The string value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventString(event: usize, key: &Str, value: &Str) {
    unsafe { __s2sdk_SetEventString.expect("SetEventString function was not found")(event, key, value) }
}
pub type _SetEventString = unsafe extern "C" fn(usize, &Str, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventString: Option<_SetEventString> = None;

/// Sets the pointer value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the pointer value.
/// * `value` - (ptr64): The pointer value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventPtr(event: usize, key: &Str, value: usize) {
    unsafe { __s2sdk_SetEventPtr.expect("SetEventPtr function was not found")(event, key, value) }
}
pub type _SetEventPtr = unsafe extern "C" fn(usize, &Str, usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventPtr: Option<_SetEventPtr> = None;

/// Sets the player controller address of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the player controller address.
/// * `value` - (ptr64): A pointer to the player controller to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventPlayerController(event: usize, key: &Str, value: usize) {
    unsafe { __s2sdk_SetEventPlayerController.expect("SetEventPlayerController function was not found")(event, key, value) }
}
pub type _SetEventPlayerController = unsafe extern "C" fn(usize, &Str, usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventPlayerController: Option<_SetEventPlayerController> = None;

/// Sets the player index value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the player index value.
/// * `value` - (int32): The player index value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventPlayerIndex(event: usize, key: &Str, value: i32) {
    unsafe { __s2sdk_SetEventPlayerIndex.expect("SetEventPlayerIndex function was not found")(event, key, value) }
}
pub type _SetEventPlayerIndex = unsafe extern "C" fn(usize, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventPlayerIndex: Option<_SetEventPlayerIndex> = None;

/// Sets the player slot value of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the player slot value.
/// * `value` - (int32): The player slot value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventPlayerSlot(event: usize, key: &Str, value: i32) {
    unsafe { __s2sdk_SetEventPlayerSlot.expect("SetEventPlayerSlot function was not found")(event, key, value) }
}
pub type _SetEventPlayerSlot = unsafe extern "C" fn(usize, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventPlayerSlot: Option<_SetEventPlayerSlot> = None;

/// Sets the entity address of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the entity address.
/// * `value` - (ptr64): A pointer to the entity to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventEntity(event: usize, key: &Str, value: usize) {
    unsafe { __s2sdk_SetEventEntity.expect("SetEventEntity function was not found")(event, key, value) }
}
pub type _SetEventEntity = unsafe extern "C" fn(usize, &Str, usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventEntity: Option<_SetEventEntity> = None;

/// Sets the entity index of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the entity index.
/// * `value` - (int32): The entity index value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventEntityIndex(event: usize, key: &Str, value: i32) {
    unsafe { __s2sdk_SetEventEntityIndex.expect("SetEventEntityIndex function was not found")(event, key, value) }
}
pub type _SetEventEntityIndex = unsafe extern "C" fn(usize, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventEntityIndex: Option<_SetEventEntityIndex> = None;

/// Sets the entity handle of a game event's key.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `key` - (string): The key for which to set the entity handle.
/// * `value` - (int32): The entity handle value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventEntityHandle(event: usize, key: &Str, value: i32) {
    unsafe { __s2sdk_SetEventEntityHandle.expect("SetEventEntityHandle function was not found")(event, key, value) }
}
pub type _SetEventEntityHandle = unsafe extern "C" fn(usize, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventEntityHandle: Option<_SetEventEntityHandle> = None;

/// Sets whether an event's broadcasting will be disabled or not.
///
/// # Arguments
/// * `event` - (ptr64): A pointer to the IGameEvent object containing event data.
/// * `dontBroadcast` - (bool): A boolean indicating whether to disable broadcasting.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEventBroadcast(event: usize, dontBroadcast: bool) {
    unsafe { __s2sdk_SetEventBroadcast.expect("SetEventBroadcast function was not found")(event, dontBroadcast) }
}
pub type _SetEventBroadcast = unsafe extern "C" fn(usize, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEventBroadcast: Option<_SetEventBroadcast> = None;

/// Load game event descriptions from a file (e.g., "resource/gameevents.res").
///
/// # Arguments
/// * `path` - (string): The path to the file containing event descriptions.
/// * `searchAll` - (bool): A boolean indicating whether to search all paths for the file.
///
/// # Returns - (int32):
/// An integer indicating the result of the loading operation.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn LoadEventsFromFile(path: &Str, searchAll: bool) -> i32 {
    unsafe { __s2sdk_LoadEventsFromFile.expect("LoadEventsFromFile function was not found")(path, searchAll) }
}
pub type _LoadEventsFromFile = unsafe extern "C" fn(&Str, bool) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_LoadEventsFromFile: Option<_LoadEventsFromFile> = None;

