// Generated from s2sdk.pplugin (group: models)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Retrieves the attachment angles of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose attachment angles are to be retrieved.
/// * `attachmentIndex` - (int32): The attachment index.
///
/// # Returns - (vec3):
/// A vector representing the attachment angles (pitch, yaw, roll).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityAttachmentAngles(entityHandle: i32, attachmentIndex: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityAttachmentAngles.expect("GetEntityAttachmentAngles function was not found")(entityHandle, attachmentIndex) }
}
pub type _GetEntityAttachmentAngles = unsafe extern "C" fn(i32, i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityAttachmentAngles: Option<_GetEntityAttachmentAngles> = None;

/// Retrieves the forward vector of an entity's attachment.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose attachment forward vector is to be retrieved.
/// * `attachmentIndex` - (int32): The attachment index.
///
/// # Returns - (vec3):
/// A vector representing the forward direction of the attachment.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityAttachmentForward(entityHandle: i32, attachmentIndex: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityAttachmentForward.expect("GetEntityAttachmentForward function was not found")(entityHandle, attachmentIndex) }
}
pub type _GetEntityAttachmentForward = unsafe extern "C" fn(i32, i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityAttachmentForward: Option<_GetEntityAttachmentForward> = None;

/// Retrieves the origin vector of an entity's attachment.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose attachment origin is to be retrieved.
/// * `attachmentIndex` - (int32): The attachment index.
///
/// # Returns - (vec3):
/// A vector representing the origin of the attachment.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityAttachmentOrigin(entityHandle: i32, attachmentIndex: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityAttachmentOrigin.expect("GetEntityAttachmentOrigin function was not found")(entityHandle, attachmentIndex) }
}
pub type _GetEntityAttachmentOrigin = unsafe extern "C" fn(i32, i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityAttachmentOrigin: Option<_GetEntityAttachmentOrigin> = None;

/// Retrieves the material group hash of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
///
/// # Returns - (uint32):
/// The material group hash.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityMaterialGroupHash(entityHandle: i32) -> u32 {
    unsafe { __s2sdk_GetEntityMaterialGroupHash.expect("GetEntityMaterialGroupHash function was not found")(entityHandle) }
}
pub type _GetEntityMaterialGroupHash = unsafe extern "C" fn(i32) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityMaterialGroupHash: Option<_GetEntityMaterialGroupHash> = None;

/// Retrieves the material group mask of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
///
/// # Returns - (uint64):
/// The mesh group mask.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityMaterialGroupMask(entityHandle: i32) -> u64 {
    unsafe { __s2sdk_GetEntityMaterialGroupMask.expect("GetEntityMaterialGroupMask function was not found")(entityHandle) }
}
pub type _GetEntityMaterialGroupMask = unsafe extern "C" fn(i32) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityMaterialGroupMask: Option<_GetEntityMaterialGroupMask> = None;

/// Retrieves the model scale of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
///
/// # Returns - (float):
/// The model scale factor.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityModelScale(entityHandle: i32) -> f32 {
    unsafe { __s2sdk_GetEntityModelScale.expect("GetEntityModelScale function was not found")(entityHandle) }
}
pub type _GetEntityModelScale = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityModelScale: Option<_GetEntityModelScale> = None;

/// Retrieves the render alpha of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
///
/// # Returns - (int32):
/// The alpha modulation value.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityRenderAlpha(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetEntityRenderAlpha.expect("GetEntityRenderAlpha function was not found")(entityHandle) }
}
pub type _GetEntityRenderAlpha = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityRenderAlpha: Option<_GetEntityRenderAlpha> = None;

/// Retrieves the render color of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
///
/// # Returns - (vec3):
/// A vector representing the render color (R, G, B).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityRenderColor2(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityRenderColor2.expect("GetEntityRenderColor2 function was not found")(entityHandle) }
}
pub type _GetEntityRenderColor2 = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityRenderColor2: Option<_GetEntityRenderColor2> = None;

/// Retrieves an attachment index by name.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `attachmentName` - (string): The name of the attachment.
///
/// # Returns - (int32):
/// The attachment index, or -1 if not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ScriptLookupAttachment(entityHandle: i32, attachmentName: &Str) -> i32 {
    unsafe { __s2sdk_ScriptLookupAttachment.expect("ScriptLookupAttachment function was not found")(entityHandle, attachmentName) }
}
pub type _ScriptLookupAttachment = unsafe extern "C" fn(i32, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ScriptLookupAttachment: Option<_ScriptLookupAttachment> = None;

/// Sets a bodygroup value by index.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `group` - (int32): The bodygroup index.
/// * `value` - (int32): The new value to set for the bodygroup.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityBodygroup(entityHandle: i32, group: i32, value: i32) {
    unsafe { __s2sdk_SetEntityBodygroup.expect("SetEntityBodygroup function was not found")(entityHandle, group, value) }
}
pub type _SetEntityBodygroup = unsafe extern "C" fn(i32, i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityBodygroup: Option<_SetEntityBodygroup> = None;

/// Sets a bodygroup value by name.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `name` - (string): The bodygroup name.
/// * `value` - (int32): The new value to set for the bodygroup.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityBodygroupByName(entityHandle: i32, name: &Str, value: i32) {
    unsafe { __s2sdk_SetEntityBodygroupByName.expect("SetEntityBodygroupByName function was not found")(entityHandle, name, value) }
}
pub type _SetEntityBodygroupByName = unsafe extern "C" fn(i32, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityBodygroupByName: Option<_SetEntityBodygroupByName> = None;

/// Sets the light group of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `lightGroup` - (string): The light group name.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityLightGroup(entityHandle: i32, lightGroup: &Str) {
    unsafe { __s2sdk_SetEntityLightGroup.expect("SetEntityLightGroup function was not found")(entityHandle, lightGroup) }
}
pub type _SetEntityLightGroup = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityLightGroup: Option<_SetEntityLightGroup> = None;

/// Sets the material group of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `materialGroup` - (string): The material group name.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityMaterialGroup(entityHandle: i32, materialGroup: &Str) {
    unsafe { __s2sdk_SetEntityMaterialGroup.expect("SetEntityMaterialGroup function was not found")(entityHandle, materialGroup) }
}
pub type _SetEntityMaterialGroup = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityMaterialGroup: Option<_SetEntityMaterialGroup> = None;

/// Sets the material group hash of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `hash` - (uint32): The new material group hash to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityMaterialGroupHash(entityHandle: i32, hash: u32) {
    unsafe { __s2sdk_SetEntityMaterialGroupHash.expect("SetEntityMaterialGroupHash function was not found")(entityHandle, hash) }
}
pub type _SetEntityMaterialGroupHash = unsafe extern "C" fn(i32, u32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityMaterialGroupHash: Option<_SetEntityMaterialGroupHash> = None;

/// Sets the material group mask of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `mask` - (uint64): The new mesh group mask to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityMaterialGroupMask(entityHandle: i32, mask: u64) {
    unsafe { __s2sdk_SetEntityMaterialGroupMask.expect("SetEntityMaterialGroupMask function was not found")(entityHandle, mask) }
}
pub type _SetEntityMaterialGroupMask = unsafe extern "C" fn(i32, u64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityMaterialGroupMask: Option<_SetEntityMaterialGroupMask> = None;

/// Sets the model scale of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `scale` - (float): The new scale factor.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityModelScale(entityHandle: i32, scale: f32) {
    unsafe { __s2sdk_SetEntityModelScale.expect("SetEntityModelScale function was not found")(entityHandle, scale) }
}
pub type _SetEntityModelScale = unsafe extern "C" fn(i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityModelScale: Option<_SetEntityModelScale> = None;

/// Sets the render alpha of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `alpha` - (int32): The new alpha value (0-255).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityRenderAlpha(entityHandle: i32, alpha: i32) {
    unsafe { __s2sdk_SetEntityRenderAlpha.expect("SetEntityRenderAlpha function was not found")(entityHandle, alpha) }
}
pub type _SetEntityRenderAlpha = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityRenderAlpha: Option<_SetEntityRenderAlpha> = None;

/// Sets the render color of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `r` - (int32): The red component (0-255).
/// * `g` - (int32): The green component (0-255).
/// * `b` - (int32): The blue component (0-255).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityRenderColor2(entityHandle: i32, r: i32, g: i32, b: i32) {
    unsafe { __s2sdk_SetEntityRenderColor2.expect("SetEntityRenderColor2 function was not found")(entityHandle, r, g, b) }
}
pub type _SetEntityRenderColor2 = unsafe extern "C" fn(i32, i32, i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityRenderColor2: Option<_SetEntityRenderColor2> = None;

/// Sets the render mode of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `mode` - (int32): The new render mode value.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityRenderMode2(entityHandle: i32, mode: i32) {
    unsafe { __s2sdk_SetEntityRenderMode2.expect("SetEntityRenderMode2 function was not found")(entityHandle, mode) }
}
pub type _SetEntityRenderMode2 = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityRenderMode2: Option<_SetEntityRenderMode2> = None;

/// Sets a single mesh group for an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `meshGroupName` - (string): The name of the mesh group.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntitySingleMeshGroup(entityHandle: i32, meshGroupName: &Str) {
    unsafe { __s2sdk_SetEntitySingleMeshGroup.expect("SetEntitySingleMeshGroup function was not found")(entityHandle, meshGroupName) }
}
pub type _SetEntitySingleMeshGroup = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntitySingleMeshGroup: Option<_SetEntitySingleMeshGroup> = None;

/// Sets the size (bounding box) of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `mins` - (vec3): The minimum bounding box vector.
/// * `maxs` - (vec3): The maximum bounding box vector.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntitySize(entityHandle: i32, mins: &Vec3, maxs: &Vec3) {
    unsafe { __s2sdk_SetEntitySize.expect("SetEntitySize function was not found")(entityHandle, mins, maxs) }
}
pub type _SetEntitySize = unsafe extern "C" fn(i32, &Vec3, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntitySize: Option<_SetEntitySize> = None;

/// Sets the skin of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `skin` - (int32): The new skin index.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntitySkin(entityHandle: i32, skin: i32) {
    unsafe { __s2sdk_SetEntitySkin.expect("SetEntitySkin function was not found")(entityHandle, skin) }
}
pub type _SetEntitySkin = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntitySkin: Option<_SetEntitySkin> = None;

