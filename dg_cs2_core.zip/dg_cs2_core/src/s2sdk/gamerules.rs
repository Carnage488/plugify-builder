// Generated from s2sdk.pplugin (group: gamerules)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Retrieves the pointer to the current game rules proxy instance.
///
/// # Returns - (ptr64):
/// A pointer to the game rules entity instance.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameRulesProxy() -> usize {
    unsafe { __s2sdk_GetGameRulesProxy.expect("GetGameRulesProxy function was not found")() }
}
pub type _GetGameRulesProxy = unsafe extern "C" fn() -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameRulesProxy: Option<_GetGameRulesProxy> = None;

/// Retrieves the pointer to the current game rules instance.
///
/// # Returns - (ptr64):
/// A pointer to the game rules object.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameRules() -> usize {
    unsafe { __s2sdk_GetGameRules.expect("GetGameRules function was not found")() }
}
pub type _GetGameRules = unsafe extern "C" fn() -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameRules: Option<_GetGameRules> = None;

/// Retrieves the team manager instance for a specified team.
///
/// # Arguments
/// * `team` - (int32): The numeric identifier of the team.
///
/// # Returns - (ptr64):
/// A pointer to the corresponding CTeam instance, or nullptr if the team was not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameTeamManager(team: CSTeam) -> usize {
    unsafe { __s2sdk_GetGameTeamManager.expect("GetGameTeamManager function was not found")(team) }
}
pub type _GetGameTeamManager = unsafe extern "C" fn(CSTeam) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameTeamManager: Option<_GetGameTeamManager> = None;

/// Retrieves the current score of a specified team.
///
/// # Arguments
/// * `team` - (int32): The numeric identifier of the team.
///
/// # Returns - (int32):
/// The current score of the team, or -1 if the team could not be found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameTeamScore(team: CSTeam) -> i32 {
    unsafe { __s2sdk_GetGameTeamScore.expect("GetGameTeamScore function was not found")(team) }
}
pub type _GetGameTeamScore = unsafe extern "C" fn(CSTeam) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameTeamScore: Option<_GetGameTeamScore> = None;

/// Retrieves the number of players on a specified team.
///
/// # Arguments
/// * `team` - (int32): The numeric identifier of the team (e.g., CS_TEAM_T, CS_TEAM_CT, CS_TEAM_SPECTATOR).
///
/// # Returns - (int32):
/// The number of players on the team, or -1 if game rules are unavailable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGamePlayerCount(team: CSTeam) -> i32 {
    unsafe { __s2sdk_GetGamePlayerCount.expect("GetGamePlayerCount function was not found")(team) }
}
pub type _GetGamePlayerCount = unsafe extern "C" fn(CSTeam) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGamePlayerCount: Option<_GetGamePlayerCount> = None;

/// Returns the total number of rounds played in the current match.
///
/// # Returns - (int32):
/// The total number of rounds played, or -1 if the game rules are unavailable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameTotalRoundsPlayed() -> i32 {
    unsafe { __s2sdk_GetGameTotalRoundsPlayed.expect("GetGameTotalRoundsPlayed function was not found")() }
}
pub type _GetGameTotalRoundsPlayed = unsafe extern "C" fn() -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameTotalRoundsPlayed: Option<_GetGameTotalRoundsPlayed> = None;

/// Forces the round to end with a specified reason and delay.
///
/// # Arguments
/// * `delay` - (float): Time (in seconds) to delay before the next round starts.
/// * `reason` - (int32): The reason for ending the round, defined by the CSRoundEndReason enum.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TerminateRound(delay: f32, reason: CSRoundEndReason) {
    unsafe { __s2sdk_TerminateRound.expect("TerminateRound function was not found")(delay, reason) }
}
pub type _TerminateRound = unsafe extern "C" fn(f32, CSRoundEndReason);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TerminateRound: Option<_TerminateRound> = None;

