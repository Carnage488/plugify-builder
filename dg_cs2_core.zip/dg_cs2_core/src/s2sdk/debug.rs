// Generated from s2sdk.pplugin (group: debug)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Triggers a breakpoint in the debugger.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugBreak() {
    unsafe { __s2sdk_DebugBreak.expect("DebugBreak function was not found")() }
}
pub type _DebugBreak = unsafe extern "C" fn();
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugBreak: Option<_DebugBreak> = None;

/// Draws a debug overlay box.
///
/// # Arguments
/// * `center` - (vec3): Center of the box in world space.
/// * `mins` - (vec3): Minimum bounds relative to the center.
/// * `maxs` - (vec3): Maximum bounds relative to the center.
/// * `r` - (int32): Red color value.
/// * `g` - (int32): Green color value.
/// * `b` - (int32): Blue color value.
/// * `a` - (int32): Alpha (transparency) value.
/// * `duration` - (float): Duration (in seconds) to display the box.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugDrawBox(center: &Vec3, mins: &Vec3, maxs: &Vec3, r: i32, g: i32, b: i32, a: i32, duration: f32) {
    unsafe { __s2sdk_DebugDrawBox.expect("DebugDrawBox function was not found")(center, mins, maxs, r, g, b, a, duration) }
}
pub type _DebugDrawBox = unsafe extern "C" fn(&Vec3, &Vec3, &Vec3, i32, i32, i32, i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugDrawBox: Option<_DebugDrawBox> = None;

/// Draws a debug box oriented in the direction of a forward vector.
///
/// # Arguments
/// * `center` - (vec3): Center of the box.
/// * `mins` - (vec3): Minimum bounds.
/// * `maxs` - (vec3): Maximum bounds.
/// * `forward` - (vec3): Forward direction vector.
/// * `color` - (vec3): RGB color vector.
/// * `alpha` - (float): Alpha transparency.
/// * `duration` - (float): Duration (in seconds) to display the box.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugDrawBoxDirection(center: &Vec3, mins: &Vec3, maxs: &Vec3, forward: &Vec3, color: &Vec3, alpha: f32, duration: f32) {
    unsafe { __s2sdk_DebugDrawBoxDirection.expect("DebugDrawBoxDirection function was not found")(center, mins, maxs, forward, color, alpha, duration) }
}
pub type _DebugDrawBoxDirection = unsafe extern "C" fn(&Vec3, &Vec3, &Vec3, &Vec3, &Vec3, f32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugDrawBoxDirection: Option<_DebugDrawBoxDirection> = None;

/// Draws a debug circle.
///
/// # Arguments
/// * `center` - (vec3): Center of the circle.
/// * `color` - (vec3): RGB color vector.
/// * `alpha` - (float): Alpha transparency.
/// * `radius` - (float): Circle radius.
/// * `zTest` - (bool): Whether to perform depth testing.
/// * `duration` - (float): Duration (in seconds) to display the circle.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugDrawCircle(center: &Vec3, color: &Vec3, alpha: f32, radius: f32, zTest: bool, duration: f32) {
    unsafe { __s2sdk_DebugDrawCircle.expect("DebugDrawCircle function was not found")(center, color, alpha, radius, zTest, duration) }
}
pub type _DebugDrawCircle = unsafe extern "C" fn(&Vec3, &Vec3, f32, f32, bool, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugDrawCircle: Option<_DebugDrawCircle> = None;

/// Clears all debug overlays.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugDrawClear() {
    unsafe { __s2sdk_DebugDrawClear.expect("DebugDrawClear function was not found")() }
}
pub type _DebugDrawClear = unsafe extern "C" fn();
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugDrawClear: Option<_DebugDrawClear> = None;

/// Draws a debug overlay line.
///
/// # Arguments
/// * `origin` - (vec3): Start point of the line.
/// * `target` - (vec3): End point of the line.
/// * `r` - (int32): Red color value.
/// * `g` - (int32): Green color value.
/// * `b` - (int32): Blue color value.
/// * `zTest` - (bool): Whether to perform depth testing.
/// * `duration` - (float): Duration (in seconds) to display the line.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugDrawLine(origin: &Vec3, target: &Vec3, r: i32, g: i32, b: i32, zTest: bool, duration: f32) {
    unsafe { __s2sdk_DebugDrawLine.expect("DebugDrawLine function was not found")(origin, target, r, g, b, zTest, duration) }
}
pub type _DebugDrawLine = unsafe extern "C" fn(&Vec3, &Vec3, i32, i32, i32, bool, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugDrawLine: Option<_DebugDrawLine> = None;

/// Draws a debug line using a color vector.
///
/// # Arguments
/// * `start` - (vec3): Start point of the line.
/// * `end` - (vec3): End point of the line.
/// * `color` - (vec3): RGB color vector.
/// * `zTest` - (bool): Whether to perform depth testing.
/// * `duration` - (float): Duration (in seconds) to display the line.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugDrawLine_vCol(start: &Vec3, end: &Vec3, color: &Vec3, zTest: bool, duration: f32) {
    unsafe { __s2sdk_DebugDrawLine_vCol.expect("DebugDrawLine_vCol function was not found")(start, end, color, zTest, duration) }
}
pub type _DebugDrawLine_vCol = unsafe extern "C" fn(&Vec3, &Vec3, &Vec3, bool, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugDrawLine_vCol: Option<_DebugDrawLine_vCol> = None;

/// Draws text at a specified screen position with line offset.
///
/// # Arguments
/// * `x` - (float): X coordinate in screen space.
/// * `y` - (float): Y coordinate in screen space.
/// * `lineOffset` - (int32): Line offset value.
/// * `text` - (string): The text string to display.
/// * `r` - (int32): Red color value.
/// * `g` - (int32): Green color value.
/// * `b` - (int32): Blue color value.
/// * `a` - (int32): Alpha transparency value.
/// * `duration` - (float): Duration (in seconds) to display the text.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugDrawScreenTextLine(x: f32, y: f32, lineOffset: i32, text: &Str, r: i32, g: i32, b: i32, a: i32, duration: f32) {
    unsafe { __s2sdk_DebugDrawScreenTextLine.expect("DebugDrawScreenTextLine function was not found")(x, y, lineOffset, text, r, g, b, a, duration) }
}
pub type _DebugDrawScreenTextLine = unsafe extern "C" fn(f32, f32, i32, &Str, i32, i32, i32, i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugDrawScreenTextLine: Option<_DebugDrawScreenTextLine> = None;

/// Draws a debug sphere.
///
/// # Arguments
/// * `center` - (vec3): Center of the sphere.
/// * `color` - (vec3): RGB color vector.
/// * `alpha` - (float): Alpha transparency.
/// * `radius` - (float): Radius of the sphere.
/// * `zTest` - (bool): Whether to perform depth testing.
/// * `duration` - (float): Duration (in seconds) to display the sphere.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugDrawSphere(center: &Vec3, color: &Vec3, alpha: f32, radius: f32, zTest: bool, duration: f32) {
    unsafe { __s2sdk_DebugDrawSphere.expect("DebugDrawSphere function was not found")(center, color, alpha, radius, zTest, duration) }
}
pub type _DebugDrawSphere = unsafe extern "C" fn(&Vec3, &Vec3, f32, f32, bool, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugDrawSphere: Option<_DebugDrawSphere> = None;

/// Draws text in 3D space.
///
/// # Arguments
/// * `origin` - (vec3): World-space position to draw the text at.
/// * `text` - (string): The text string to display.
/// * `viewCheck` - (bool): If true, only draws when visible to camera.
/// * `duration` - (float): Duration (in seconds) to display the text.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugDrawText(origin: &Vec3, text: &Str, viewCheck: bool, duration: f32) {
    unsafe { __s2sdk_DebugDrawText.expect("DebugDrawText function was not found")(origin, text, viewCheck, duration) }
}
pub type _DebugDrawText = unsafe extern "C" fn(&Vec3, &Str, bool, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugDrawText: Option<_DebugDrawText> = None;

/// Draws styled debug text on screen.
///
/// # Arguments
/// * `x` - (float): X coordinate.
/// * `y` - (float): Y coordinate.
/// * `lineOffset` - (int32): Line offset value.
/// * `text` - (string): Text string.
/// * `r` - (int32): Red color value.
/// * `g` - (int32): Green color value.
/// * `b` - (int32): Blue color value.
/// * `a` - (int32): Alpha transparency.
/// * `duration` - (float): Duration (in seconds) to display the text.
/// * `font` - (string): Font name.
/// * `size` - (int32): Font size.
/// * `bold` - (bool): Whether text should be bold.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugScreenTextPretty(x: f32, y: f32, lineOffset: i32, text: &Str, r: i32, g: i32, b: i32, a: i32, duration: f32, font: &Str, size: i32, bold: bool) {
    unsafe { __s2sdk_DebugScreenTextPretty.expect("DebugScreenTextPretty function was not found")(x, y, lineOffset, text, r, g, b, a, duration, font, size, bold) }
}
pub type _DebugScreenTextPretty = unsafe extern "C" fn(f32, f32, i32, &Str, i32, i32, i32, i32, f32, &Str, i32, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugScreenTextPretty: Option<_DebugScreenTextPretty> = None;

/// Performs an assertion and logs a message if the assertion fails.
///
/// # Arguments
/// * `assertion` - (bool): Boolean value to test.
/// * `message` - (string): Message to display if the assertion fails.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DebugScriptAssert(assertion: bool, message: &Str) {
    unsafe { __s2sdk_DebugScriptAssert.expect("DebugScriptAssert function was not found")(assertion, message) }
}
pub type _DebugScriptAssert = unsafe extern "C" fn(bool, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DebugScriptAssert: Option<_DebugScriptAssert> = None;

