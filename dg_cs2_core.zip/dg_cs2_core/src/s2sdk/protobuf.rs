// Generated from s2sdk.pplugin (group: protobuf)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Hooks a user message with a callback.
///
/// # Arguments
/// * `messageId` - (int16): The ID of the message to hook.
/// * `callback` - (function): The callback function to invoke when the message is received.
/// * `mode` - (uint8): Whether to hook the message in the post mode (after processing) or pre mode (before processing).
///
/// # Returns - (bool):
/// True if the hook was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn HookUserMessage(messageId: i16, callback: UserMessageCallback, mode: HookMode) -> bool {
    unsafe { __s2sdk_HookUserMessage.expect("HookUserMessage function was not found")(messageId, callback, mode) }
}
pub type _HookUserMessage = unsafe extern "C" fn(i16, UserMessageCallback, HookMode) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_HookUserMessage: Option<_HookUserMessage> = None;

/// Unhooks a previously hooked user message.
///
/// # Arguments
/// * `messageId` - (int16): The ID of the message to unhook.
/// * `callback` - (function): The callback function to remove.
/// * `mode` - (uint8): Whether the hook was in post mode (after processing) or pre mode (before processing).
///
/// # Returns - (bool):
/// True if the hook was successfully removed, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UnhookUserMessage(messageId: i16, callback: UserMessageCallback, mode: HookMode) -> bool {
    unsafe { __s2sdk_UnhookUserMessage.expect("UnhookUserMessage function was not found")(messageId, callback, mode) }
}
pub type _UnhookUserMessage = unsafe extern "C" fn(i16, UserMessageCallback, HookMode) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UnhookUserMessage: Option<_UnhookUserMessage> = None;

/// Creates a UserMessage from a serializable message.
///
/// # Arguments
/// * `msgSerializable` - (ptr64): The serializable message.
/// * `message` - (ptr64): The network message.
/// * `recipientMask` - (uint64): The recipient mask.
///
/// # Returns - (ptr64):
/// A pointer to the newly created UserMessage.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageCreateFromSerializable(msgSerializable: usize, message: usize, recipientMask: u64) -> usize {
    unsafe { __s2sdk_UserMessageCreateFromSerializable.expect("UserMessageCreateFromSerializable function was not found")(msgSerializable, message, recipientMask) }
}
pub type _UserMessageCreateFromSerializable = unsafe extern "C" fn(usize, usize, u64) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageCreateFromSerializable: Option<_UserMessageCreateFromSerializable> = None;

/// Creates a UserMessage from a message name.
///
/// # Arguments
/// * `messageName` - (string): The name of the message.
///
/// # Returns - (ptr64):
/// A pointer to the newly created UserMessage.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageCreateFromName(messageName: &Str) -> usize {
    unsafe { __s2sdk_UserMessageCreateFromName.expect("UserMessageCreateFromName function was not found")(messageName) }
}
pub type _UserMessageCreateFromName = unsafe extern "C" fn(&Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageCreateFromName: Option<_UserMessageCreateFromName> = None;

/// Creates a UserMessage from a message ID.
///
/// # Arguments
/// * `messageId` - (int16): The ID of the message.
///
/// # Returns - (ptr64):
/// A pointer to the newly created UserMessage.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageCreateFromId(messageId: i16) -> usize {
    unsafe { __s2sdk_UserMessageCreateFromId.expect("UserMessageCreateFromId function was not found")(messageId) }
}
pub type _UserMessageCreateFromId = unsafe extern "C" fn(i16) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageCreateFromId: Option<_UserMessageCreateFromId> = None;

/// Destroys a UserMessage and frees its memory.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage to destroy.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageDestroy(userMessage: usize) {
    unsafe { __s2sdk_UserMessageDestroy.expect("UserMessageDestroy function was not found")(userMessage) }
}
pub type _UserMessageDestroy = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageDestroy: Option<_UserMessageDestroy> = None;

/// Sends a UserMessage to the specified recipients.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage to send.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageSend(userMessage: usize) {
    unsafe { __s2sdk_UserMessageSend.expect("UserMessageSend function was not found")(userMessage) }
}
pub type _UserMessageSend = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageSend: Option<_UserMessageSend> = None;

/// Gets the name of the message.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
///
/// # Returns - (string):
/// The name of the message as a string.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageGetMessageName(userMessage: usize) -> Str {
    unsafe { __s2sdk_UserMessageGetMessageName.expect("UserMessageGetMessageName function was not found")(userMessage) }
}
pub type _UserMessageGetMessageName = unsafe extern "C" fn(usize) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageGetMessageName: Option<_UserMessageGetMessageName> = None;

/// Gets the ID of the message.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
///
/// # Returns - (int16):
/// The ID of the message.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageGetMessageID(userMessage: usize) -> i16 {
    unsafe { __s2sdk_UserMessageGetMessageID.expect("UserMessageGetMessageID function was not found")(userMessage) }
}
pub type _UserMessageGetMessageID = unsafe extern "C" fn(usize) -> i16;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageGetMessageID: Option<_UserMessageGetMessageID> = None;

/// Checks if the message has a specific field.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field to check.
///
/// # Returns - (bool):
/// True if the field exists, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageHasField(userMessage: usize, fieldName: &Str) -> bool {
    unsafe { __s2sdk_UserMessageHasField.expect("UserMessageHasField function was not found")(userMessage, fieldName) }
}
pub type _UserMessageHasField = unsafe extern "C" fn(usize, &Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageHasField: Option<_UserMessageHasField> = None;

/// Gets the protobuf message associated with the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
///
/// # Returns - (ptr64):
/// A pointer to the protobuf message.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageGetProtobufMessage(userMessage: usize) -> usize {
    unsafe { __s2sdk_UserMessageGetProtobufMessage.expect("UserMessageGetProtobufMessage function was not found")(userMessage) }
}
pub type _UserMessageGetProtobufMessage = unsafe extern "C" fn(usize) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageGetProtobufMessage: Option<_UserMessageGetProtobufMessage> = None;

/// Gets the serializable message associated with the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
///
/// # Returns - (ptr64):
/// A pointer to the serializable message.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageGetSerializableMessage(userMessage: usize) -> usize {
    unsafe { __s2sdk_UserMessageGetSerializableMessage.expect("UserMessageGetSerializableMessage function was not found")(userMessage) }
}
pub type _UserMessageGetSerializableMessage = unsafe extern "C" fn(usize) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageGetSerializableMessage: Option<_UserMessageGetSerializableMessage> = None;

/// Finds a message ID by its name.
///
/// # Arguments
/// * `messageName` - (string): The name of the message.
///
/// # Returns - (int16):
/// The ID of the message, or 0 if the message was not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageFindMessageIdByName(messageName: &Str) -> i16 {
    unsafe { __s2sdk_UserMessageFindMessageIdByName.expect("UserMessageFindMessageIdByName function was not found")(messageName) }
}
pub type _UserMessageFindMessageIdByName = unsafe extern "C" fn(&Str) -> i16;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageFindMessageIdByName: Option<_UserMessageFindMessageIdByName> = None;

/// Gets the recipient mask for the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
///
/// # Returns - (uint64):
/// The recipient mask.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageGetRecipientMask(userMessage: usize) -> u64 {
    unsafe { __s2sdk_UserMessageGetRecipientMask.expect("UserMessageGetRecipientMask function was not found")(userMessage) }
}
pub type _UserMessageGetRecipientMask = unsafe extern "C" fn(usize) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageGetRecipientMask: Option<_UserMessageGetRecipientMask> = None;

/// Adds a single recipient (player) to the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `playerSlot` - (int32): The slot index of the player to add as a recipient.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageAddRecipient(userMessage: usize, playerSlot: i32) {
    unsafe { __s2sdk_UserMessageAddRecipient.expect("UserMessageAddRecipient function was not found")(userMessage, playerSlot) }
}
pub type _UserMessageAddRecipient = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageAddRecipient: Option<_UserMessageAddRecipient> = None;

/// Adds all connected players as recipients to the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageAddAllPlayers(userMessage: usize) {
    unsafe { __s2sdk_UserMessageAddAllPlayers.expect("UserMessageAddAllPlayers function was not found")(userMessage) }
}
pub type _UserMessageAddAllPlayers = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageAddAllPlayers: Option<_UserMessageAddAllPlayers> = None;

/// Sets the recipient mask for the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `mask` - (uint64): The recipient mask to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageSetRecipientMask(userMessage: usize, mask: u64) {
    unsafe { __s2sdk_UserMessageSetRecipientMask.expect("UserMessageSetRecipientMask function was not found")(userMessage, mask) }
}
pub type _UserMessageSetRecipientMask = unsafe extern "C" fn(usize, u64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageSetRecipientMask: Option<_UserMessageSetRecipientMask> = None;

/// Remove all players UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageRemoveAllRecipient(userMessage: usize) {
    unsafe { __s2sdk_UserMessageRemoveAllRecipient.expect("UserMessageRemoveAllRecipient function was not found")(userMessage) }
}
pub type _UserMessageRemoveAllRecipient = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageRemoveAllRecipient: Option<_UserMessageRemoveAllRecipient> = None;

/// Gets the count of repeated fields in a field of the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
///
/// # Returns - (int32):
/// The count of repeated fields, or -1 if the field is not repeated or does not exist.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageGetRepeatedFieldCount(userMessage: usize, fieldName: &Str) -> i32 {
    unsafe { __s2sdk_UserMessageGetRepeatedFieldCount.expect("UserMessageGetRepeatedFieldCount function was not found")(userMessage, fieldName) }
}
pub type _UserMessageGetRepeatedFieldCount = unsafe extern "C" fn(usize, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageGetRepeatedFieldCount: Option<_UserMessageGetRepeatedFieldCount> = None;

/// Removes a value from a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the value to remove.
///
/// # Returns - (bool):
/// True if the value was successfully removed, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageRemoveRepeatedFieldValue(userMessage: usize, fieldName: &Str, index: i32) -> bool {
    unsafe { __s2sdk_UserMessageRemoveRepeatedFieldValue.expect("UserMessageRemoveRepeatedFieldValue function was not found")(userMessage, fieldName, index) }
}
pub type _UserMessageRemoveRepeatedFieldValue = unsafe extern "C" fn(usize, &Str, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageRemoveRepeatedFieldValue: Option<_UserMessageRemoveRepeatedFieldValue> = None;

/// Gets the debug string representation of the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
///
/// # Returns - (string):
/// The debug string as a string.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UserMessageGetDebugString(userMessage: usize) -> Str {
    unsafe { __s2sdk_UserMessageGetDebugString.expect("UserMessageGetDebugString function was not found")(userMessage) }
}
pub type _UserMessageGetDebugString = unsafe extern "C" fn(usize) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UserMessageGetDebugString: Option<_UserMessageGetDebugString> = None;

/// Reads an enum value from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (int32):
/// The integer representation of the enum value, or 0 if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadEnum(userMessage: usize, fieldName: &Str, index: i32) -> i32 {
    unsafe { __s2sdk_PbReadEnum.expect("PbReadEnum function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadEnum = unsafe extern "C" fn(usize, &Str, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadEnum: Option<_PbReadEnum> = None;

/// Reads a 32-bit integer from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (int32):
/// The int32_t value read, or 0 if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadInt32(userMessage: usize, fieldName: &Str, index: i32) -> i32 {
    unsafe { __s2sdk_PbReadInt32.expect("PbReadInt32 function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadInt32 = unsafe extern "C" fn(usize, &Str, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadInt32: Option<_PbReadInt32> = None;

/// Reads a 64-bit integer from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (int64):
/// The int64_t value read, or 0 if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadInt64(userMessage: usize, fieldName: &Str, index: i32) -> i64 {
    unsafe { __s2sdk_PbReadInt64.expect("PbReadInt64 function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadInt64 = unsafe extern "C" fn(usize, &Str, i32) -> i64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadInt64: Option<_PbReadInt64> = None;

/// Reads an unsigned 32-bit integer from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (uint32):
/// The uint32_t value read, or 0 if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadUInt32(userMessage: usize, fieldName: &Str, index: i32) -> u32 {
    unsafe { __s2sdk_PbReadUInt32.expect("PbReadUInt32 function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadUInt32 = unsafe extern "C" fn(usize, &Str, i32) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadUInt32: Option<_PbReadUInt32> = None;

/// Reads an unsigned 64-bit integer from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (uint64):
/// The uint64_t value read, or 0 if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadUInt64(userMessage: usize, fieldName: &Str, index: i32) -> u64 {
    unsafe { __s2sdk_PbReadUInt64.expect("PbReadUInt64 function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadUInt64 = unsafe extern "C" fn(usize, &Str, i32) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadUInt64: Option<_PbReadUInt64> = None;

/// Reads a floating-point value from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (float):
/// The float value read, or 0.0 if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadFloat(userMessage: usize, fieldName: &Str, index: i32) -> f32 {
    unsafe { __s2sdk_PbReadFloat.expect("PbReadFloat function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadFloat = unsafe extern "C" fn(usize, &Str, i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadFloat: Option<_PbReadFloat> = None;

/// Reads a double-precision floating-point value from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (double):
/// The double value read, or 0.0 if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadDouble(userMessage: usize, fieldName: &Str, index: i32) -> f64 {
    unsafe { __s2sdk_PbReadDouble.expect("PbReadDouble function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadDouble = unsafe extern "C" fn(usize, &Str, i32) -> f64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadDouble: Option<_PbReadDouble> = None;

/// Reads a boolean value from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (bool):
/// The boolean value read, or false if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadBool(userMessage: usize, fieldName: &Str, index: i32) -> bool {
    unsafe { __s2sdk_PbReadBool.expect("PbReadBool function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadBool = unsafe extern "C" fn(usize, &Str, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadBool: Option<_PbReadBool> = None;

/// Reads a string from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (string):
/// The string value read, or an empty string if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadString(userMessage: usize, fieldName: &Str, index: i32) -> Str {
    unsafe { __s2sdk_PbReadString.expect("PbReadString function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadString = unsafe extern "C" fn(usize, &Str, i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadString: Option<_PbReadString> = None;

/// Reads a color value from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (vec4):
/// The color value read, or an empty value if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadColor(userMessage: usize, fieldName: &Str, index: i32) -> Vec4 {
    unsafe { __s2sdk_PbReadColor.expect("PbReadColor function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadColor = unsafe extern "C" fn(usize, &Str, i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadColor: Option<_PbReadColor> = None;

/// Reads a 2D vector from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (vec2):
/// The 2D vector value read, or an empty value if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadVector2(userMessage: usize, fieldName: &Str, index: i32) -> Vec2 {
    unsafe { __s2sdk_PbReadVector2.expect("PbReadVector2 function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadVector2 = unsafe extern "C" fn(usize, &Str, i32) -> Vec2;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadVector2: Option<_PbReadVector2> = None;

/// Reads a 3D vector from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (vec3):
/// The 3D vector value read, or an empty value if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadVector3(userMessage: usize, fieldName: &Str, index: i32) -> Vec3 {
    unsafe { __s2sdk_PbReadVector3.expect("PbReadVector3 function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadVector3 = unsafe extern "C" fn(usize, &Str, i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadVector3: Option<_PbReadVector3> = None;

/// Reads a 4D vector from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (vec4):
/// The 4D vector value read, or an empty value if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadVector4(userMessage: usize, fieldName: &Str, index: i32) -> Vec4 {
    unsafe { __s2sdk_PbReadVector4.expect("PbReadVector4 function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadVector4 = unsafe extern "C" fn(usize, &Str, i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadVector4: Option<_PbReadVector4> = None;

/// Reads a QAngle (rotation vector) from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (vec3):
/// The QAngle value read, or an empty value if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadQAngle(userMessage: usize, fieldName: &Str, index: i32) -> Vec3 {
    unsafe { __s2sdk_PbReadQAngle.expect("PbReadQAngle function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadQAngle = unsafe extern "C" fn(usize, &Str, i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadQAngle: Option<_PbReadQAngle> = None;

/// Reads a Message from a UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): Pointer to the UserMessage object.
/// * `fieldName` - (string): Name of the field to read.
/// * `index` - (int32): Index of the repeated field (use -1 for non-repeated fields).
///
/// # Returns - (ptr64):
/// The Message value read, or an empty value if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbReadMessage(userMessage: usize, fieldName: &Str, index: i32) -> usize {
    unsafe { __s2sdk_PbReadMessage.expect("PbReadMessage function was not found")(userMessage, fieldName, index) }
}
pub type _PbReadMessage = unsafe extern "C" fn(usize, &Str, i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbReadMessage: Option<_PbReadMessage> = None;

/// Gets a enum value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (int32&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetEnum(userMessage: usize, fieldName: &Str, out: &mut i32) -> bool {
    unsafe { __s2sdk_PbGetEnum.expect("PbGetEnum function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetEnum = unsafe extern "C" fn(usize, &Str, &mut i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetEnum: Option<_PbGetEnum> = None;

/// Sets a enum value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (int32): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetEnum(userMessage: usize, fieldName: &Str, value: i32) -> bool {
    unsafe { __s2sdk_PbSetEnum.expect("PbSetEnum function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetEnum = unsafe extern "C" fn(usize, &Str, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetEnum: Option<_PbSetEnum> = None;

/// Gets a 32-bit integer value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (int32&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetInt32(userMessage: usize, fieldName: &Str, out: &mut i32) -> bool {
    unsafe { __s2sdk_PbGetInt32.expect("PbGetInt32 function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetInt32 = unsafe extern "C" fn(usize, &Str, &mut i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetInt32: Option<_PbGetInt32> = None;

/// Sets a 32-bit integer value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (int32): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetInt32(userMessage: usize, fieldName: &Str, value: i32) -> bool {
    unsafe { __s2sdk_PbSetInt32.expect("PbSetInt32 function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetInt32 = unsafe extern "C" fn(usize, &Str, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetInt32: Option<_PbSetInt32> = None;

/// Gets a 64-bit integer value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (int64&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetInt64(userMessage: usize, fieldName: &Str, out: &mut i64) -> bool {
    unsafe { __s2sdk_PbGetInt64.expect("PbGetInt64 function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetInt64 = unsafe extern "C" fn(usize, &Str, &mut i64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetInt64: Option<_PbGetInt64> = None;

/// Sets a 64-bit integer value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (int64): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetInt64(userMessage: usize, fieldName: &Str, value: i64) -> bool {
    unsafe { __s2sdk_PbSetInt64.expect("PbSetInt64 function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetInt64 = unsafe extern "C" fn(usize, &Str, i64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetInt64: Option<_PbSetInt64> = None;

/// Gets an unsigned 32-bit integer value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (uint32&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetUInt32(userMessage: usize, fieldName: &Str, out: &mut u32) -> bool {
    unsafe { __s2sdk_PbGetUInt32.expect("PbGetUInt32 function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetUInt32 = unsafe extern "C" fn(usize, &Str, &mut u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetUInt32: Option<_PbGetUInt32> = None;

/// Sets an unsigned 32-bit integer value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (uint32): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetUInt32(userMessage: usize, fieldName: &Str, value: u32) -> bool {
    unsafe { __s2sdk_PbSetUInt32.expect("PbSetUInt32 function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetUInt32 = unsafe extern "C" fn(usize, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetUInt32: Option<_PbSetUInt32> = None;

/// Gets an unsigned 64-bit integer value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (uint64&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetUInt64(userMessage: usize, fieldName: &Str, out: &mut u64) -> bool {
    unsafe { __s2sdk_PbGetUInt64.expect("PbGetUInt64 function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetUInt64 = unsafe extern "C" fn(usize, &Str, &mut u64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetUInt64: Option<_PbGetUInt64> = None;

/// Sets an unsigned 64-bit integer value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (uint64): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetUInt64(userMessage: usize, fieldName: &Str, value: u64) -> bool {
    unsafe { __s2sdk_PbSetUInt64.expect("PbSetUInt64 function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetUInt64 = unsafe extern "C" fn(usize, &Str, u64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetUInt64: Option<_PbSetUInt64> = None;

/// Gets a bool value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (bool&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetBool(userMessage: usize, fieldName: &Str, out: &mut bool) -> bool {
    unsafe { __s2sdk_PbGetBool.expect("PbGetBool function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetBool = unsafe extern "C" fn(usize, &Str, &mut bool) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetBool: Option<_PbGetBool> = None;

/// Sets a bool value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (bool): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetBool(userMessage: usize, fieldName: &Str, value: bool) -> bool {
    unsafe { __s2sdk_PbSetBool.expect("PbSetBool function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetBool = unsafe extern "C" fn(usize, &Str, bool) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetBool: Option<_PbSetBool> = None;

/// Gets a float value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (float&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetFloat(userMessage: usize, fieldName: &Str, out: &mut f32) -> bool {
    unsafe { __s2sdk_PbGetFloat.expect("PbGetFloat function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetFloat = unsafe extern "C" fn(usize, &Str, &mut f32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetFloat: Option<_PbGetFloat> = None;

/// Sets a float value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (float): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetFloat(userMessage: usize, fieldName: &Str, value: f32) -> bool {
    unsafe { __s2sdk_PbSetFloat.expect("PbSetFloat function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetFloat = unsafe extern "C" fn(usize, &Str, f32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetFloat: Option<_PbSetFloat> = None;

/// Gets a double value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (double&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetDouble(userMessage: usize, fieldName: &Str, out: &mut f64) -> bool {
    unsafe { __s2sdk_PbGetDouble.expect("PbGetDouble function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetDouble = unsafe extern "C" fn(usize, &Str, &mut f64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetDouble: Option<_PbGetDouble> = None;

/// Sets a double value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (double): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetDouble(userMessage: usize, fieldName: &Str, value: f64) -> bool {
    unsafe { __s2sdk_PbSetDouble.expect("PbSetDouble function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetDouble = unsafe extern "C" fn(usize, &Str, f64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetDouble: Option<_PbSetDouble> = None;

/// Gets a string value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (string&): The output string.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetString(userMessage: usize, fieldName: &Str, out: &mut Str) -> bool {
    unsafe { __s2sdk_PbGetString.expect("PbGetString function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetString = unsafe extern "C" fn(usize, &Str, &mut Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetString: Option<_PbGetString> = None;

/// Sets a string value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (string): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetString(userMessage: usize, fieldName: &Str, value: &Str) -> bool {
    unsafe { __s2sdk_PbSetString.expect("PbSetString function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetString = unsafe extern "C" fn(usize, &Str, &Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetString: Option<_PbSetString> = None;

/// Gets a color value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (vec4&): The output string.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetColor(userMessage: usize, fieldName: &Str, out: &mut Vec4) -> bool {
    unsafe { __s2sdk_PbGetColor.expect("PbGetColor function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetColor = unsafe extern "C" fn(usize, &Str, &mut Vec4) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetColor: Option<_PbGetColor> = None;

/// Sets a color value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (vec4): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetColor(userMessage: usize, fieldName: &Str, value: &Vec4) -> bool {
    unsafe { __s2sdk_PbSetColor.expect("PbSetColor function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetColor = unsafe extern "C" fn(usize, &Str, &Vec4) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetColor: Option<_PbSetColor> = None;

/// Gets a Vector2 value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (vec2&): The output string.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetVector2(userMessage: usize, fieldName: &Str, out: &mut Vec2) -> bool {
    unsafe { __s2sdk_PbGetVector2.expect("PbGetVector2 function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetVector2 = unsafe extern "C" fn(usize, &Str, &mut Vec2) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetVector2: Option<_PbGetVector2> = None;

/// Sets a Vector2 value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (vec2): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetVector2(userMessage: usize, fieldName: &Str, value: &Vec2) -> bool {
    unsafe { __s2sdk_PbSetVector2.expect("PbSetVector2 function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetVector2 = unsafe extern "C" fn(usize, &Str, &Vec2) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetVector2: Option<_PbSetVector2> = None;

/// Gets a Vector3 value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (vec3&): The output string.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetVector3(userMessage: usize, fieldName: &Str, out: &mut Vec3) -> bool {
    unsafe { __s2sdk_PbGetVector3.expect("PbGetVector3 function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetVector3 = unsafe extern "C" fn(usize, &Str, &mut Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetVector3: Option<_PbGetVector3> = None;

/// Sets a Vector3 value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (vec3): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetVector3(userMessage: usize, fieldName: &Str, value: &Vec3) -> bool {
    unsafe { __s2sdk_PbSetVector3.expect("PbSetVector3 function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetVector3 = unsafe extern "C" fn(usize, &Str, &Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetVector3: Option<_PbSetVector3> = None;

/// Gets a Vector4 value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (vec4&): The output string.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetVector4(userMessage: usize, fieldName: &Str, out: &mut Vec4) -> bool {
    unsafe { __s2sdk_PbGetVector4.expect("PbGetVector4 function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetVector4 = unsafe extern "C" fn(usize, &Str, &mut Vec4) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetVector4: Option<_PbGetVector4> = None;

/// Sets a Vector3 value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (vec4): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetVector4(userMessage: usize, fieldName: &Str, value: &Vec4) -> bool {
    unsafe { __s2sdk_PbSetVector4.expect("PbSetVector4 function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetVector4 = unsafe extern "C" fn(usize, &Str, &Vec4) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetVector4: Option<_PbSetVector4> = None;

/// Gets a QAngle value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (vec3&): The output vector.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetQAngle(userMessage: usize, fieldName: &Str, out: &mut Vec3) -> bool {
    unsafe { __s2sdk_PbGetQAngle.expect("PbGetQAngle function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetQAngle = unsafe extern "C" fn(usize, &Str, &mut Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetQAngle: Option<_PbGetQAngle> = None;

/// Sets a QAngle value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (vec3): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetQAngle(userMessage: usize, fieldName: &Str, value: &Vec3) -> bool {
    unsafe { __s2sdk_PbSetQAngle.expect("PbSetQAngle function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetQAngle = unsafe extern "C" fn(usize, &Str, &Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetQAngle: Option<_PbSetQAngle> = None;

/// Gets a Message value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `out` - (ptr64&): The output message.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetMessage(userMessage: usize, fieldName: &Str, out: &mut usize) -> bool {
    unsafe { __s2sdk_PbGetMessage.expect("PbGetMessage function was not found")(userMessage, fieldName, out) }
}
pub type _PbGetMessage = unsafe extern "C" fn(usize, &Str, &mut usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetMessage: Option<_PbGetMessage> = None;

/// Sets a Message value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (ptr64): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetMessage(userMessage: usize, fieldName: &Str, value: usize) -> bool {
    unsafe { __s2sdk_PbSetMessage.expect("PbSetMessage function was not found")(userMessage, fieldName, value) }
}
pub type _PbSetMessage = unsafe extern "C" fn(usize, &Str, usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetMessage: Option<_PbSetMessage> = None;

/// Gets a repeated enum value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (int32&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedEnum(userMessage: usize, fieldName: &Str, index: i32, out: &mut i32) -> bool {
    unsafe { __s2sdk_PbGetRepeatedEnum.expect("PbGetRepeatedEnum function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedEnum = unsafe extern "C" fn(usize, &Str, i32, &mut i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedEnum: Option<_PbGetRepeatedEnum> = None;

/// Sets a repeated enum value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (int32): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedEnum(userMessage: usize, fieldName: &Str, index: i32, value: i32) -> bool {
    unsafe { __s2sdk_PbSetRepeatedEnum.expect("PbSetRepeatedEnum function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedEnum = unsafe extern "C" fn(usize, &Str, i32, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedEnum: Option<_PbSetRepeatedEnum> = None;

/// Adds a enum value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (int32): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddEnum(userMessage: usize, fieldName: &Str, value: i32) -> bool {
    unsafe { __s2sdk_PbAddEnum.expect("PbAddEnum function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddEnum = unsafe extern "C" fn(usize, &Str, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddEnum: Option<_PbAddEnum> = None;

/// Gets a repeated int32_t value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (int32&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedInt32(userMessage: usize, fieldName: &Str, index: i32, out: &mut i32) -> bool {
    unsafe { __s2sdk_PbGetRepeatedInt32.expect("PbGetRepeatedInt32 function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedInt32 = unsafe extern "C" fn(usize, &Str, i32, &mut i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedInt32: Option<_PbGetRepeatedInt32> = None;

/// Sets a repeated int32_t value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (int32): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedInt32(userMessage: usize, fieldName: &Str, index: i32, value: i32) -> bool {
    unsafe { __s2sdk_PbSetRepeatedInt32.expect("PbSetRepeatedInt32 function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedInt32 = unsafe extern "C" fn(usize, &Str, i32, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedInt32: Option<_PbSetRepeatedInt32> = None;

/// Adds a 32-bit integer value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (int32): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddInt32(userMessage: usize, fieldName: &Str, value: i32) -> bool {
    unsafe { __s2sdk_PbAddInt32.expect("PbAddInt32 function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddInt32 = unsafe extern "C" fn(usize, &Str, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddInt32: Option<_PbAddInt32> = None;

/// Gets a repeated int64_t value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (int64&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedInt64(userMessage: usize, fieldName: &Str, index: i32, out: &mut i64) -> bool {
    unsafe { __s2sdk_PbGetRepeatedInt64.expect("PbGetRepeatedInt64 function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedInt64 = unsafe extern "C" fn(usize, &Str, i32, &mut i64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedInt64: Option<_PbGetRepeatedInt64> = None;

/// Sets a repeated int64_t value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (int64): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedInt64(userMessage: usize, fieldName: &Str, index: i32, value: i64) -> bool {
    unsafe { __s2sdk_PbSetRepeatedInt64.expect("PbSetRepeatedInt64 function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedInt64 = unsafe extern "C" fn(usize, &Str, i32, i64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedInt64: Option<_PbSetRepeatedInt64> = None;

/// Adds a 64-bit integer value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (int64): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddInt64(userMessage: usize, fieldName: &Str, value: i64) -> bool {
    unsafe { __s2sdk_PbAddInt64.expect("PbAddInt64 function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddInt64 = unsafe extern "C" fn(usize, &Str, i64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddInt64: Option<_PbAddInt64> = None;

/// Gets a repeated uint32_t value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (uint32&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedUInt32(userMessage: usize, fieldName: &Str, index: i32, out: &mut u32) -> bool {
    unsafe { __s2sdk_PbGetRepeatedUInt32.expect("PbGetRepeatedUInt32 function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedUInt32 = unsafe extern "C" fn(usize, &Str, i32, &mut u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedUInt32: Option<_PbGetRepeatedUInt32> = None;

/// Sets a repeated uint32_t value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (uint32): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedUInt32(userMessage: usize, fieldName: &Str, index: i32, value: u32) -> bool {
    unsafe { __s2sdk_PbSetRepeatedUInt32.expect("PbSetRepeatedUInt32 function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedUInt32 = unsafe extern "C" fn(usize, &Str, i32, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedUInt32: Option<_PbSetRepeatedUInt32> = None;

/// Adds an unsigned 32-bit integer value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (uint32): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddUInt32(userMessage: usize, fieldName: &Str, value: u32) -> bool {
    unsafe { __s2sdk_PbAddUInt32.expect("PbAddUInt32 function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddUInt32 = unsafe extern "C" fn(usize, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddUInt32: Option<_PbAddUInt32> = None;

/// Gets a repeated uint64_t value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (uint64&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedUInt64(userMessage: usize, fieldName: &Str, index: i32, out: &mut u64) -> bool {
    unsafe { __s2sdk_PbGetRepeatedUInt64.expect("PbGetRepeatedUInt64 function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedUInt64 = unsafe extern "C" fn(usize, &Str, i32, &mut u64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedUInt64: Option<_PbGetRepeatedUInt64> = None;

/// Sets a repeated uint64_t value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (uint64): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedUInt64(userMessage: usize, fieldName: &Str, index: i32, value: u64) -> bool {
    unsafe { __s2sdk_PbSetRepeatedUInt64.expect("PbSetRepeatedUInt64 function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedUInt64 = unsafe extern "C" fn(usize, &Str, i32, u64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedUInt64: Option<_PbSetRepeatedUInt64> = None;

/// Adds an unsigned 64-bit integer value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (uint64): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddUInt64(userMessage: usize, fieldName: &Str, value: u64) -> bool {
    unsafe { __s2sdk_PbAddUInt64.expect("PbAddUInt64 function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddUInt64 = unsafe extern "C" fn(usize, &Str, u64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddUInt64: Option<_PbAddUInt64> = None;

/// Gets a repeated bool value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (bool&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedBool(userMessage: usize, fieldName: &Str, index: i32, out: &mut bool) -> bool {
    unsafe { __s2sdk_PbGetRepeatedBool.expect("PbGetRepeatedBool function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedBool = unsafe extern "C" fn(usize, &Str, i32, &mut bool) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedBool: Option<_PbGetRepeatedBool> = None;

/// Sets a repeated bool value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (bool): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedBool(userMessage: usize, fieldName: &Str, index: i32, value: bool) -> bool {
    unsafe { __s2sdk_PbSetRepeatedBool.expect("PbSetRepeatedBool function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedBool = unsafe extern "C" fn(usize, &Str, i32, bool) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedBool: Option<_PbSetRepeatedBool> = None;

/// Adds a bool value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (bool): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddBool(userMessage: usize, fieldName: &Str, value: bool) -> bool {
    unsafe { __s2sdk_PbAddBool.expect("PbAddBool function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddBool = unsafe extern "C" fn(usize, &Str, bool) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddBool: Option<_PbAddBool> = None;

/// Gets a repeated float value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (float&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedFloat(userMessage: usize, fieldName: &Str, index: i32, out: &mut f32) -> bool {
    unsafe { __s2sdk_PbGetRepeatedFloat.expect("PbGetRepeatedFloat function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedFloat = unsafe extern "C" fn(usize, &Str, i32, &mut f32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedFloat: Option<_PbGetRepeatedFloat> = None;

/// Sets a repeated float value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (float): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedFloat(userMessage: usize, fieldName: &Str, index: i32, value: f32) -> bool {
    unsafe { __s2sdk_PbSetRepeatedFloat.expect("PbSetRepeatedFloat function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedFloat = unsafe extern "C" fn(usize, &Str, i32, f32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedFloat: Option<_PbSetRepeatedFloat> = None;

/// Adds a float value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (float): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddFloat(userMessage: usize, fieldName: &Str, value: f32) -> bool {
    unsafe { __s2sdk_PbAddFloat.expect("PbAddFloat function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddFloat = unsafe extern "C" fn(usize, &Str, f32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddFloat: Option<_PbAddFloat> = None;

/// Gets a repeated double value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (double&): The output value.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedDouble(userMessage: usize, fieldName: &Str, index: i32, out: &mut f64) -> bool {
    unsafe { __s2sdk_PbGetRepeatedDouble.expect("PbGetRepeatedDouble function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedDouble = unsafe extern "C" fn(usize, &Str, i32, &mut f64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedDouble: Option<_PbGetRepeatedDouble> = None;

/// Sets a repeated double value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (double): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedDouble(userMessage: usize, fieldName: &Str, index: i32, value: f64) -> bool {
    unsafe { __s2sdk_PbSetRepeatedDouble.expect("PbSetRepeatedDouble function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedDouble = unsafe extern "C" fn(usize, &Str, i32, f64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedDouble: Option<_PbSetRepeatedDouble> = None;

/// Adds a double value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (double): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddDouble(userMessage: usize, fieldName: &Str, value: f64) -> bool {
    unsafe { __s2sdk_PbAddDouble.expect("PbAddDouble function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddDouble = unsafe extern "C" fn(usize, &Str, f64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddDouble: Option<_PbAddDouble> = None;

/// Gets a repeated string value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (string&): The output string.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedString(userMessage: usize, fieldName: &Str, index: i32, out: &mut Str) -> bool {
    unsafe { __s2sdk_PbGetRepeatedString.expect("PbGetRepeatedString function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedString = unsafe extern "C" fn(usize, &Str, i32, &mut Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedString: Option<_PbGetRepeatedString> = None;

/// Sets a repeated string value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (string): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedString(userMessage: usize, fieldName: &Str, index: i32, value: &Str) -> bool {
    unsafe { __s2sdk_PbSetRepeatedString.expect("PbSetRepeatedString function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedString = unsafe extern "C" fn(usize, &Str, i32, &Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedString: Option<_PbSetRepeatedString> = None;

/// Adds a string value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (string): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddString(userMessage: usize, fieldName: &Str, value: &Str) -> bool {
    unsafe { __s2sdk_PbAddString.expect("PbAddString function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddString = unsafe extern "C" fn(usize, &Str, &Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddString: Option<_PbAddString> = None;

/// Gets a repeated color value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (vec4&): The output color.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedColor(userMessage: usize, fieldName: &Str, index: i32, out: &mut Vec4) -> bool {
    unsafe { __s2sdk_PbGetRepeatedColor.expect("PbGetRepeatedColor function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedColor = unsafe extern "C" fn(usize, &Str, i32, &mut Vec4) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedColor: Option<_PbGetRepeatedColor> = None;

/// Sets a repeated color value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (vec4): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedColor(userMessage: usize, fieldName: &Str, index: i32, value: &Vec4) -> bool {
    unsafe { __s2sdk_PbSetRepeatedColor.expect("PbSetRepeatedColor function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedColor = unsafe extern "C" fn(usize, &Str, i32, &Vec4) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedColor: Option<_PbSetRepeatedColor> = None;

/// Adds a color value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (vec4): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddColor(userMessage: usize, fieldName: &Str, value: &Vec4) -> bool {
    unsafe { __s2sdk_PbAddColor.expect("PbAddColor function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddColor = unsafe extern "C" fn(usize, &Str, &Vec4) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddColor: Option<_PbAddColor> = None;

/// Gets a repeated Vector2 value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (vec2&): The output vector.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedVector2(userMessage: usize, fieldName: &Str, index: i32, out: &mut Vec2) -> bool {
    unsafe { __s2sdk_PbGetRepeatedVector2.expect("PbGetRepeatedVector2 function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedVector2 = unsafe extern "C" fn(usize, &Str, i32, &mut Vec2) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedVector2: Option<_PbGetRepeatedVector2> = None;

/// Sets a repeated Vector2 value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (vec2): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedVector2(userMessage: usize, fieldName: &Str, index: i32, value: &Vec2) -> bool {
    unsafe { __s2sdk_PbSetRepeatedVector2.expect("PbSetRepeatedVector2 function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedVector2 = unsafe extern "C" fn(usize, &Str, i32, &Vec2) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedVector2: Option<_PbSetRepeatedVector2> = None;

/// Adds a Vector2 value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (vec2): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddVector2(userMessage: usize, fieldName: &Str, value: &Vec2) -> bool {
    unsafe { __s2sdk_PbAddVector2.expect("PbAddVector2 function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddVector2 = unsafe extern "C" fn(usize, &Str, &Vec2) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddVector2: Option<_PbAddVector2> = None;

/// Gets a repeated Vector3 value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (vec3&): The output vector.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedVector3(userMessage: usize, fieldName: &Str, index: i32, out: &mut Vec3) -> bool {
    unsafe { __s2sdk_PbGetRepeatedVector3.expect("PbGetRepeatedVector3 function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedVector3 = unsafe extern "C" fn(usize, &Str, i32, &mut Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedVector3: Option<_PbGetRepeatedVector3> = None;

/// Sets a repeated Vector3 value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (vec3): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedVector3(userMessage: usize, fieldName: &Str, index: i32, value: &Vec3) -> bool {
    unsafe { __s2sdk_PbSetRepeatedVector3.expect("PbSetRepeatedVector3 function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedVector3 = unsafe extern "C" fn(usize, &Str, i32, &Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedVector3: Option<_PbSetRepeatedVector3> = None;

/// Adds a Vector3 value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (vec3): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddVector3(userMessage: usize, fieldName: &Str, value: &Vec3) -> bool {
    unsafe { __s2sdk_PbAddVector3.expect("PbAddVector3 function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddVector3 = unsafe extern "C" fn(usize, &Str, &Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddVector3: Option<_PbAddVector3> = None;

/// Gets a repeated Vector4 value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (vec4&): The output vector.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedVector4(userMessage: usize, fieldName: &Str, index: i32, out: &mut Vec4) -> bool {
    unsafe { __s2sdk_PbGetRepeatedVector4.expect("PbGetRepeatedVector4 function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedVector4 = unsafe extern "C" fn(usize, &Str, i32, &mut Vec4) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedVector4: Option<_PbGetRepeatedVector4> = None;

/// Sets a repeated Vector4 value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (vec4): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedVector4(userMessage: usize, fieldName: &Str, index: i32, value: &Vec4) -> bool {
    unsafe { __s2sdk_PbSetRepeatedVector4.expect("PbSetRepeatedVector4 function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedVector4 = unsafe extern "C" fn(usize, &Str, i32, &Vec4) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedVector4: Option<_PbSetRepeatedVector4> = None;

/// Adds a Vector4 value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (vec4): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddVector4(userMessage: usize, fieldName: &Str, value: &Vec4) -> bool {
    unsafe { __s2sdk_PbAddVector4.expect("PbAddVector4 function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddVector4 = unsafe extern "C" fn(usize, &Str, &Vec4) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddVector4: Option<_PbAddVector4> = None;

/// Gets a repeated QAngle value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (vec3&): The output vector.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedQAngle(userMessage: usize, fieldName: &Str, index: i32, out: &mut Vec3) -> bool {
    unsafe { __s2sdk_PbGetRepeatedQAngle.expect("PbGetRepeatedQAngle function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedQAngle = unsafe extern "C" fn(usize, &Str, i32, &mut Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedQAngle: Option<_PbGetRepeatedQAngle> = None;

/// Sets a repeated QAngle value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (vec3): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedQAngle(userMessage: usize, fieldName: &Str, index: i32, value: &Vec3) -> bool {
    unsafe { __s2sdk_PbSetRepeatedQAngle.expect("PbSetRepeatedQAngle function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedQAngle = unsafe extern "C" fn(usize, &Str, i32, &Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedQAngle: Option<_PbSetRepeatedQAngle> = None;

/// Adds a QAngle value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (vec3): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddQAngle(userMessage: usize, fieldName: &Str, value: &Vec3) -> bool {
    unsafe { __s2sdk_PbAddQAngle.expect("PbAddQAngle function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddQAngle = unsafe extern "C" fn(usize, &Str, &Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddQAngle: Option<_PbAddQAngle> = None;

/// Gets a repeated Message value from a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `out` - (ptr64&): The output message.
///
/// # Returns - (bool):
/// True if the field was successfully retrieved, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbGetRepeatedMessage(userMessage: usize, fieldName: &Str, index: i32, out: &mut usize) -> bool {
    unsafe { __s2sdk_PbGetRepeatedMessage.expect("PbGetRepeatedMessage function was not found")(userMessage, fieldName, index, out) }
}
pub type _PbGetRepeatedMessage = unsafe extern "C" fn(usize, &Str, i32, &mut usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbGetRepeatedMessage: Option<_PbGetRepeatedMessage> = None;

/// Sets a repeated Message value for a field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `index` - (int32): The index of the repeated field.
/// * `value` - (ptr64): The value to set.
///
/// # Returns - (bool):
/// True if the field was successfully set, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbSetRepeatedMessage(userMessage: usize, fieldName: &Str, index: i32, value: usize) -> bool {
    unsafe { __s2sdk_PbSetRepeatedMessage.expect("PbSetRepeatedMessage function was not found")(userMessage, fieldName, index, value) }
}
pub type _PbSetRepeatedMessage = unsafe extern "C" fn(usize, &Str, i32, usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbSetRepeatedMessage: Option<_PbSetRepeatedMessage> = None;

/// Adds a Message value to a repeated field in the UserMessage.
///
/// # Arguments
/// * `userMessage` - (ptr64): The UserMessage instance.
/// * `fieldName` - (string): The name of the field.
/// * `value` - (ptr64): The value to add.
///
/// # Returns - (bool):
/// True if the value was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PbAddMessage(userMessage: usize, fieldName: &Str, value: usize) -> bool {
    unsafe { __s2sdk_PbAddMessage.expect("PbAddMessage function was not found")(userMessage, fieldName, value) }
}
pub type _PbAddMessage = unsafe extern "C" fn(usize, &Str, usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PbAddMessage: Option<_PbAddMessage> = None;

