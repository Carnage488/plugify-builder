// Generated from s2sdk.pplugin (group: weapons)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Retrieves the weapon VData for a given weapon name.
///
/// # Arguments
/// * `name` - (string): The name of the weapon.
///
/// # Returns - (ptr64):
/// A pointer to the `CCSWeaponBaseVData` if the entity handle is valid and represents a player weapon; otherwise, nullptr.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetWeaponVDataFromKey(name: &Str) -> usize {
    unsafe { __s2sdk_GetWeaponVDataFromKey.expect("GetWeaponVDataFromKey function was not found")(name) }
}
pub type _GetWeaponVDataFromKey = unsafe extern "C" fn(&Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetWeaponVDataFromKey: Option<_GetWeaponVDataFromKey> = None;

/// Retrieves the weapon VData for a given weapon.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which to retrieve the weapon VData.
///
/// # Returns - (ptr64):
/// A pointer to the `CCSWeaponBaseVData` if the entity handle is valid and represents a player weapon; otherwise, nullptr.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetWeaponVData(entityHandle: i32) -> usize {
    unsafe { __s2sdk_GetWeaponVData.expect("GetWeaponVData function was not found")(entityHandle) }
}
pub type _GetWeaponVData = unsafe extern "C" fn(i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetWeaponVData: Option<_GetWeaponVData> = None;

/// Retrieves the weapon type of a given entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity (weapon).
///
/// # Returns - (uint32):
/// The type of the weapon, or WEAPONTYPE_UNKNOWN if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetWeaponType(entityHandle: i32) -> CSWeaponType {
    unsafe { __s2sdk_GetWeaponType.expect("GetWeaponType function was not found")(entityHandle) }
}
pub type _GetWeaponType = unsafe extern "C" fn(i32) -> CSWeaponType;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetWeaponType: Option<_GetWeaponType> = None;

/// Retrieves the weapon category of a given entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity (weapon).
///
/// # Returns - (uint32):
/// The category of the weapon, or WEAPONCATEGORY_OTHER if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetWeaponCategory(entityHandle: i32) -> CSWeaponCategory {
    unsafe { __s2sdk_GetWeaponCategory.expect("GetWeaponCategory function was not found")(entityHandle) }
}
pub type _GetWeaponCategory = unsafe extern "C" fn(i32) -> CSWeaponCategory;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetWeaponCategory: Option<_GetWeaponCategory> = None;

/// Retrieves the gear slot of a given weapon entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity (weapon).
///
/// # Returns - (uint32):
/// The gear slot of the weapon, or GEAR_SLOT_INVALID if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetWeaponGearSlot(entityHandle: i32) -> GearSlot {
    unsafe { __s2sdk_GetWeaponGearSlot.expect("GetWeaponGearSlot function was not found")(entityHandle) }
}
pub type _GetWeaponGearSlot = unsafe extern "C" fn(i32) -> GearSlot;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetWeaponGearSlot: Option<_GetWeaponGearSlot> = None;

/// Retrieves the weapon definition index for a given entity handle.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which to retrieve the weapon def index.
///
/// # Returns - (uint16):
/// The weapon definition index as a `uint16_t`, or 0 if the entity handle is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetWeaponItemDefinition(entityHandle: i32) -> WeaponDefIndex {
    unsafe { __s2sdk_GetWeaponItemDefinition.expect("GetWeaponItemDefinition function was not found")(entityHandle) }
}
pub type _GetWeaponItemDefinition = unsafe extern "C" fn(i32) -> WeaponDefIndex;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetWeaponItemDefinition: Option<_GetWeaponItemDefinition> = None;

/// Retrieves the item definition index associated with a given item name.
///
/// # Arguments
/// * `itemName` - (string): The name of the item.
///
/// # Returns - (uint16):
/// The weapon definition index as a `uint16_t`, or 0 if the entity handle is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetWeaponItemDefinitionByName(itemName: &Str) -> WeaponDefIndex {
    unsafe { __s2sdk_GetWeaponItemDefinitionByName.expect("GetWeaponItemDefinitionByName function was not found")(itemName) }
}
pub type _GetWeaponItemDefinitionByName = unsafe extern "C" fn(&Str) -> WeaponDefIndex;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetWeaponItemDefinitionByName: Option<_GetWeaponItemDefinitionByName> = None;

