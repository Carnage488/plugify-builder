// Generated from s2sdk.pplugin (group: commands)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Creates a console command as an administrative command.
///
/// # Arguments
/// * `name` - (string): The name of the console command.
/// * `adminFlags` - (int64): The admin flags that indicate which admin level can use this command.
/// * `description` - (string): A brief description of what the command does.
/// * `flags` - (int64): Command flags that define the behavior of the command.
/// * `callback` - (function): A callback function that is invoked when the command is executed.
/// * `type_` - (uint8): Whether the hook was in post mode (after processing) or pre mode (before processing).
///
/// # Returns - (bool):
/// true if the command was successfully created; otherwise, false.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AddAdminCommand(name: &Str, adminFlags: i64, description: &Str, flags: ConVarFlag, callback: ConCommandCallback, type_: HookMode) -> bool {
    unsafe { __s2sdk_AddAdminCommand.expect("AddAdminCommand function was not found")(name, adminFlags, description, flags, callback, type_) }
}
pub type _AddAdminCommand = unsafe extern "C" fn(&Str, i64, &Str, ConVarFlag, ConCommandCallback, HookMode) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AddAdminCommand: Option<_AddAdminCommand> = None;

/// Creates a console command or hooks an already existing one.
///
/// # Arguments
/// * `name` - (string): The name of the console command.
/// * `description` - (string): A brief description of what the command does.
/// * `flags` - (int64): Command flags that define the behavior of the command.
/// * `callback` - (function): A callback function that is invoked when the command is executed.
/// * `type_` - (uint8): Whether the hook was in post mode (after processing) or pre mode (before processing).
///
/// # Returns - (bool):
/// true if the command was successfully created; otherwise, false.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AddConsoleCommand(name: &Str, description: &Str, flags: ConVarFlag, callback: ConCommandCallback, type_: HookMode) -> bool {
    unsafe { __s2sdk_AddConsoleCommand.expect("AddConsoleCommand function was not found")(name, description, flags, callback, type_) }
}
pub type _AddConsoleCommand = unsafe extern "C" fn(&Str, &Str, ConVarFlag, ConCommandCallback, HookMode) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AddConsoleCommand: Option<_AddConsoleCommand> = None;

/// Removes a console command from the system.
///
/// # Arguments
/// * `name` - (string): The name of the command to be removed.
/// * `callback` - (function): The callback function associated with the command to be removed.
///
/// # Returns - (bool):
/// true if the command was successfully removed; otherwise, false.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RemoveCommand(name: &Str, callback: ConCommandCallback) -> bool {
    unsafe { __s2sdk_RemoveCommand.expect("RemoveCommand function was not found")(name, callback) }
}
pub type _RemoveCommand = unsafe extern "C" fn(&Str, ConCommandCallback) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RemoveCommand: Option<_RemoveCommand> = None;

/// Adds a callback that will fire when a command is sent to the server.
///
/// # Arguments
/// * `name` - (string): The name of the command.
/// * `callback` - (function): The callback function that will be invoked when the command is executed.
/// * `type_` - (uint8): Whether the hook was in post mode (after processing) or pre mode (before processing).
///
/// # Returns - (bool):
/// Returns true if the callback was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AddCommandListener(name: &Str, callback: ConCommandCallback, type_: HookMode) -> bool {
    unsafe { __s2sdk_AddCommandListener.expect("AddCommandListener function was not found")(name, callback, type_) }
}
pub type _AddCommandListener = unsafe extern "C" fn(&Str, ConCommandCallback, HookMode) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AddCommandListener: Option<_AddCommandListener> = None;

/// Removes a callback that fires when a command is sent to the server.
///
/// # Arguments
/// * `name` - (string): The name of the command.
/// * `callback` - (function): The callback function to be removed.
/// * `type_` - (uint8): Whether the hook was in post mode (after processing) or pre mode (before processing).
///
/// # Returns - (bool):
/// Returns true if the callback was successfully removed, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RemoveCommandListener(name: &Str, callback: ConCommandCallback, type_: HookMode) -> bool {
    unsafe { __s2sdk_RemoveCommandListener.expect("RemoveCommandListener function was not found")(name, callback, type_) }
}
pub type _RemoveCommandListener = unsafe extern "C" fn(&Str, ConCommandCallback, HookMode) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RemoveCommandListener: Option<_RemoveCommandListener> = None;

/// Executes a server command as if it were run on the server console or through RCON.
///
/// # Arguments
/// * `command` - (string): The command to execute on the server.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ServerCommand(command: &Str) {
    unsafe { __s2sdk_ServerCommand.expect("ServerCommand function was not found")(command) }
}
pub type _ServerCommand = unsafe extern "C" fn(&Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ServerCommand: Option<_ServerCommand> = None;

/// Executes a server command as if it were on the server console (or RCON) and stores the printed text into buffer.
///
/// # Arguments
/// * `command` - (string): The command to execute on the server.
///
/// # Returns - (string):
/// String to store command result into.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ServerCommandEx(command: &Str) -> Str {
    unsafe { __s2sdk_ServerCommandEx.expect("ServerCommandEx function was not found")(command) }
}
pub type _ServerCommandEx = unsafe extern "C" fn(&Str) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ServerCommandEx: Option<_ServerCommandEx> = None;

/// Executes a client command.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the client executing the command.
/// * `command` - (string): The command to execute on the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ClientCommand(playerSlot: i32, command: &Str) {
    unsafe { __s2sdk_ClientCommand.expect("ClientCommand function was not found")(playerSlot, command) }
}
pub type _ClientCommand = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ClientCommand: Option<_ClientCommand> = None;

/// Executes a client command on the server without network communication.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the client.
/// * `command` - (string): The command to be executed by the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FakeClientCommand(playerSlot: i32, command: &Str) {
    unsafe { __s2sdk_FakeClientCommand.expect("FakeClientCommand function was not found")(playerSlot, command) }
}
pub type _FakeClientCommand = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FakeClientCommand: Option<_FakeClientCommand> = None;

///  Returns the names of all registered console commands and cvars.
///
/// # Arguments
/// * `flags` - (int64): Additional flags for the console variable.
///
/// # Returns - (string[]):
/// The vector of command/cvar names.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetAllConCommands(flags: ConVarFlag) -> Arr<Str> {
    unsafe { __s2sdk_GetAllConCommands.expect("GetAllConCommands function was not found")(flags) }
}
pub type _GetAllConCommands = unsafe extern "C" fn(ConVarFlag) -> Arr<Str>;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetAllConCommands: Option<_GetAllConCommands> = None;

/// Returns all console commands registered by this plugin.
///
/// # Returns - (string[]):
/// The vector of ConCommand names.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetAllCommands() -> Arr<Str> {
    unsafe { __s2sdk_GetAllCommands.expect("GetAllCommands function was not found")() }
}
pub type _GetAllCommands = unsafe extern "C" fn() -> Arr<Str>;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetAllCommands: Option<_GetAllCommands> = None;

