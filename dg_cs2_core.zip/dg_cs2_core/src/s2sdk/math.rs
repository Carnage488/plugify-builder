// Generated from s2sdk.pplugin (group: math)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Returns angular difference in degrees
///
/// # Arguments
/// * `angle1` - (float): First angle in degrees
/// * `angle2` - (float): Second angle in degrees
///
/// # Returns - (float):
/// Angular difference in degrees
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AnglesDiff(angle1: f32, angle2: f32) -> f32 {
    unsafe { __s2sdk_AnglesDiff.expect("AnglesDiff function was not found")(angle1, angle2) }
}
pub type _AnglesDiff = unsafe extern "C" fn(f32, f32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AnglesDiff: Option<_AnglesDiff> = None;

/// Converts QAngle to directional Vector
///
/// # Arguments
/// * `angles` - (vec3): The QAngle to convert
///
/// # Returns - (vec3):
/// Directional vector
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AnglesToVector(angles: &Vec3) -> Vec3 {
    unsafe { __s2sdk_AnglesToVector.expect("AnglesToVector function was not found")(angles) }
}
pub type _AnglesToVector = unsafe extern "C" fn(&Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AnglesToVector: Option<_AnglesToVector> = None;

/// Converts axis-angle representation to quaternion
///
/// # Arguments
/// * `axis` - (vec3): Rotation axis (should be normalized)
/// * `angle` - (float): Rotation angle in radians
///
/// # Returns - (vec4):
/// Resulting quaternion
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AxisAngleToQuaternion(axis: &Vec3, angle: f32) -> Vec4 {
    unsafe { __s2sdk_AxisAngleToQuaternion.expect("AxisAngleToQuaternion function was not found")(axis, angle) }
}
pub type _AxisAngleToQuaternion = unsafe extern "C" fn(&Vec3, f32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AxisAngleToQuaternion: Option<_AxisAngleToQuaternion> = None;

/// Computes closest point on an entity's oriented bounding box (OBB)
///
/// # Arguments
/// * `entityHandle` - (int32): Handle of the entity
/// * `position` - (vec3): Position to find closest point from
///
/// # Returns - (vec3):
/// Closest point on the entity's OBB, or vec3_origin if entity is invalid
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CalcClosestPointOnEntityOBB(entityHandle: i32, position: &Vec3) -> Vec3 {
    unsafe { __s2sdk_CalcClosestPointOnEntityOBB.expect("CalcClosestPointOnEntityOBB function was not found")(entityHandle, position) }
}
pub type _CalcClosestPointOnEntityOBB = unsafe extern "C" fn(i32, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CalcClosestPointOnEntityOBB: Option<_CalcClosestPointOnEntityOBB> = None;

/// Computes distance between two entities' oriented bounding boxes (OBBs)
///
/// # Arguments
/// * `entityHandle1` - (int32): Handle of the first entity
/// * `entityHandle2` - (int32): Handle of the second entity
///
/// # Returns - (float):
/// Distance between OBBs, or -1.0f if either entity is invalid
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CalcDistanceBetweenEntityOBB(entityHandle1: i32, entityHandle2: i32) -> f32 {
    unsafe { __s2sdk_CalcDistanceBetweenEntityOBB.expect("CalcDistanceBetweenEntityOBB function was not found")(entityHandle1, entityHandle2) }
}
pub type _CalcDistanceBetweenEntityOBB = unsafe extern "C" fn(i32, i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CalcDistanceBetweenEntityOBB: Option<_CalcDistanceBetweenEntityOBB> = None;

/// Computes shortest 2D distance from a point to a line segment
///
/// # Arguments
/// * `p` - (vec3): The point
/// * `vLineA` - (vec3): First endpoint of the line segment
/// * `vLineB` - (vec3): Second endpoint of the line segment
///
/// # Returns - (float):
/// Shortest 2D distance
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CalcDistanceToLineSegment2D(p: &Vec3, vLineA: &Vec3, vLineB: &Vec3) -> f32 {
    unsafe { __s2sdk_CalcDistanceToLineSegment2D.expect("CalcDistanceToLineSegment2D function was not found")(p, vLineA, vLineB) }
}
pub type _CalcDistanceToLineSegment2D = unsafe extern "C" fn(&Vec3, &Vec3, &Vec3) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CalcDistanceToLineSegment2D: Option<_CalcDistanceToLineSegment2D> = None;

/// Computes cross product of two vectors
///
/// # Arguments
/// * `v1` - (vec3): First vector
/// * `v2` - (vec3): Second vector
///
/// # Returns - (vec3):
/// Cross product vector (v1 × v2)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CrossVectors(v1: &Vec3, v2: &Vec3) -> Vec3 {
    unsafe { __s2sdk_CrossVectors.expect("CrossVectors function was not found")(v1, v2) }
}
pub type _CrossVectors = unsafe extern "C" fn(&Vec3, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CrossVectors: Option<_CrossVectors> = None;

/// Smooth exponential decay function
///
/// # Arguments
/// * `decayTo` - (float): Target value to decay towards
/// * `decayTime` - (float): Time constant for decay
/// * `dt` - (float): Delta time
///
/// # Returns - (float):
/// Decay factor
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ExponentDecay(decayTo: f32, decayTime: f32, dt: f32) -> f32 {
    unsafe { __s2sdk_ExponentDecay.expect("ExponentDecay function was not found")(decayTo, decayTime, dt) }
}
pub type _ExponentDecay = unsafe extern "C" fn(f32, f32, f32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ExponentDecay: Option<_ExponentDecay> = None;

/// Linear interpolation between two vectors
///
/// # Arguments
/// * `start` - (vec3): Starting vector
/// * `end` - (vec3): Ending vector
/// * `factor` - (float): Interpolation factor (0.0 to 1.0)
///
/// # Returns - (vec3):
/// Interpolated vector
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn LerpVectors(start: &Vec3, end: &Vec3, factor: f32) -> Vec3 {
    unsafe { __s2sdk_LerpVectors.expect("LerpVectors function was not found")(start, end, factor) }
}
pub type _LerpVectors = unsafe extern "C" fn(&Vec3, &Vec3, f32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_LerpVectors: Option<_LerpVectors> = None;

/// Quaternion spherical linear interpolation for angles
///
/// # Arguments
/// * `fromAngle` - (vec3): Starting angle
/// * `toAngle` - (vec3): Ending angle
/// * `time` - (float): Interpolation time (0.0 to 1.0)
///
/// # Returns - (vec3):
/// Interpolated angle
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn QSlerp(fromAngle: &Vec3, toAngle: &Vec3, time: f32) -> Vec3 {
    unsafe { __s2sdk_QSlerp.expect("QSlerp function was not found")(fromAngle, toAngle, time) }
}
pub type _QSlerp = unsafe extern "C" fn(&Vec3, &Vec3, f32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_QSlerp: Option<_QSlerp> = None;

/// Rotate one QAngle by another
///
/// # Arguments
/// * `a1` - (vec3): Base orientation
/// * `a2` - (vec3): Rotation to apply
///
/// # Returns - (vec3):
/// Rotated orientation
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RotateOrientation(a1: &Vec3, a2: &Vec3) -> Vec3 {
    unsafe { __s2sdk_RotateOrientation.expect("RotateOrientation function was not found")(a1, a2) }
}
pub type _RotateOrientation = unsafe extern "C" fn(&Vec3, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RotateOrientation: Option<_RotateOrientation> = None;

/// Rotate a vector around a point by specified angle
///
/// # Arguments
/// * `rotationOrigin` - (vec3): Origin point of rotation
/// * `rotationAngle` - (vec3): Angle to rotate by
/// * `vectorToRotate` - (vec3): Vector to be rotated
///
/// # Returns - (vec3):
/// Rotated vector
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RotatePosition(rotationOrigin: &Vec3, rotationAngle: &Vec3, vectorToRotate: &Vec3) -> Vec3 {
    unsafe { __s2sdk_RotatePosition.expect("RotatePosition function was not found")(rotationOrigin, rotationAngle, vectorToRotate) }
}
pub type _RotatePosition = unsafe extern "C" fn(&Vec3, &Vec3, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RotatePosition: Option<_RotatePosition> = None;

/// Rotates quaternion by axis-angle representation
///
/// # Arguments
/// * `q` - (vec4): Quaternion to rotate
/// * `axis` - (vec3): Rotation axis
/// * `angle` - (float): Rotation angle in radians
///
/// # Returns - (vec4):
/// Rotated quaternion
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RotateQuaternionByAxisAngle(q: &Vec4, axis: &Vec3, angle: f32) -> Vec4 {
    unsafe { __s2sdk_RotateQuaternionByAxisAngle.expect("RotateQuaternionByAxisAngle function was not found")(q, axis, angle) }
}
pub type _RotateQuaternionByAxisAngle = unsafe extern "C" fn(&Vec4, &Vec3, f32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RotateQuaternionByAxisAngle: Option<_RotateQuaternionByAxisAngle> = None;

/// Finds angular delta between two QAngles
///
/// # Arguments
/// * `src` - (vec3): Source angle
/// * `dest` - (vec3): Destination angle
///
/// # Returns - (vec3):
/// Delta angle from src to dest
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RotationDelta(src: &Vec3, dest: &Vec3) -> Vec3 {
    unsafe { __s2sdk_RotationDelta.expect("RotationDelta function was not found")(src, dest) }
}
pub type _RotationDelta = unsafe extern "C" fn(&Vec3, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RotationDelta: Option<_RotationDelta> = None;

/// Converts delta QAngle to angular velocity vector
///
/// # Arguments
/// * `a1` - (vec3): First angle
/// * `a2` - (vec3): Second angle
///
/// # Returns - (vec3):
/// Angular velocity vector
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RotationDeltaAsAngularVelocity(a1: &Vec3, a2: &Vec3) -> Vec3 {
    unsafe { __s2sdk_RotationDeltaAsAngularVelocity.expect("RotationDeltaAsAngularVelocity function was not found")(a1, a2) }
}
pub type _RotationDeltaAsAngularVelocity = unsafe extern "C" fn(&Vec3, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RotationDeltaAsAngularVelocity: Option<_RotationDeltaAsAngularVelocity> = None;

/// Interpolates between two quaternions using spline
///
/// # Arguments
/// * `q0` - (vec4): Starting quaternion
/// * `q1` - (vec4): Ending quaternion
/// * `t` - (float): Interpolation parameter (0.0 to 1.0)
///
/// # Returns - (vec4):
/// Interpolated quaternion
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SplineQuaternions(q0: &Vec4, q1: &Vec4, t: f32) -> Vec4 {
    unsafe { __s2sdk_SplineQuaternions.expect("SplineQuaternions function was not found")(q0, q1, t) }
}
pub type _SplineQuaternions = unsafe extern "C" fn(&Vec4, &Vec4, f32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SplineQuaternions: Option<_SplineQuaternions> = None;

/// Interpolates between two vectors using spline
///
/// # Arguments
/// * `v0` - (vec3): Starting vector
/// * `v1` - (vec3): Ending vector
/// * `t` - (float): Interpolation parameter (0.0 to 1.0)
///
/// # Returns - (vec3):
/// Interpolated vector
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SplineVectors(v0: &Vec3, v1: &Vec3, t: f32) -> Vec3 {
    unsafe { __s2sdk_SplineVectors.expect("SplineVectors function was not found")(v0, v1, t) }
}
pub type _SplineVectors = unsafe extern "C" fn(&Vec3, &Vec3, f32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SplineVectors: Option<_SplineVectors> = None;

/// Converts directional vector to QAngle (no roll)
///
/// # Arguments
/// * `input` - (vec3): Direction vector
///
/// # Returns - (vec3):
/// Angle representation with pitch and yaw (roll is 0)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn VectorToAngles(input: &Vec3) -> Vec3 {
    unsafe { __s2sdk_VectorToAngles.expect("VectorToAngles function was not found")(input) }
}
pub type _VectorToAngles = unsafe extern "C" fn(&Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_VectorToAngles: Option<_VectorToAngles> = None;

/// Returns random float between min and max
///
/// # Arguments
/// * `min` - (float): Minimum value (inclusive)
/// * `max` - (float): Maximum value (inclusive)
///
/// # Returns - (float):
/// Random float in range [min, max]
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RandomFlt(min: f32, max: f32) -> f32 {
    unsafe { __s2sdk_RandomFlt.expect("RandomFlt function was not found")(min, max) }
}
pub type _RandomFlt = unsafe extern "C" fn(f32, f32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RandomFlt: Option<_RandomFlt> = None;

/// Returns random integer between min and max (inclusive)
///
/// # Arguments
/// * `min` - (int32): Minimum value (inclusive)
/// * `max` - (int32): Maximum value (inclusive)
///
/// # Returns - (int32):
/// Random integer in range [min, max]
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RandomInt(min: i32, max: i32) -> i32 {
    unsafe { __s2sdk_RandomInt.expect("RandomInt function was not found")(min, max) }
}
pub type _RandomInt = unsafe extern "C" fn(i32, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RandomInt: Option<_RandomInt> = None;

