// Generated from s2sdk.pplugin (group: cvars)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Creates a new console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (any): The default value of the console variable.
/// * `description` - (string): A description of the console variable's purpose.
/// * `flags` - (int64): Additional flags for the console variable.
///
/// # Returns - (uint64):
/// A handle to the created console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVar(name: &Str, defaultValue: &Var, description: &Str, flags: ConVarFlag) -> u64 {
    unsafe { __s2sdk_CreateConVar.expect("CreateConVar function was not found")(name, defaultValue, description, flags) }
}
pub type _CreateConVar = unsafe extern "C" fn(&Str, &Var, &Str, ConVarFlag) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVar: Option<_CreateConVar> = None;

/// Creates a new boolean console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (bool): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (bool): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (bool): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarBool(name: &Str, defaultValue: bool, description: &Str, flags: ConVarFlag, hasMin: bool, min: bool, hasMax: bool, max: bool) -> u64 {
    unsafe { __s2sdk_CreateConVarBool.expect("CreateConVarBool function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarBool = unsafe extern "C" fn(&Str, bool, &Str, ConVarFlag, bool, bool, bool, bool) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarBool: Option<_CreateConVarBool> = None;

/// Creates a new 16-bit signed integer console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (int16): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (int16): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (int16): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarInt16(name: &Str, defaultValue: i16, description: &Str, flags: ConVarFlag, hasMin: bool, min: i16, hasMax: bool, max: i16) -> u64 {
    unsafe { __s2sdk_CreateConVarInt16.expect("CreateConVarInt16 function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarInt16 = unsafe extern "C" fn(&Str, i16, &Str, ConVarFlag, bool, i16, bool, i16) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarInt16: Option<_CreateConVarInt16> = None;

/// Creates a new 16-bit unsigned integer console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (uint16): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (uint16): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (uint16): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarUInt16(name: &Str, defaultValue: u16, description: &Str, flags: ConVarFlag, hasMin: bool, min: u16, hasMax: bool, max: u16) -> u64 {
    unsafe { __s2sdk_CreateConVarUInt16.expect("CreateConVarUInt16 function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarUInt16 = unsafe extern "C" fn(&Str, u16, &Str, ConVarFlag, bool, u16, bool, u16) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarUInt16: Option<_CreateConVarUInt16> = None;

/// Creates a new 32-bit signed integer console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (int32): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (int32): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (int32): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarInt32(name: &Str, defaultValue: i32, description: &Str, flags: ConVarFlag, hasMin: bool, min: i32, hasMax: bool, max: i32) -> u64 {
    unsafe { __s2sdk_CreateConVarInt32.expect("CreateConVarInt32 function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarInt32 = unsafe extern "C" fn(&Str, i32, &Str, ConVarFlag, bool, i32, bool, i32) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarInt32: Option<_CreateConVarInt32> = None;

/// Creates a new 32-bit unsigned integer console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (uint32): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (uint32): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (uint32): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarUInt32(name: &Str, defaultValue: u32, description: &Str, flags: ConVarFlag, hasMin: bool, min: u32, hasMax: bool, max: u32) -> u64 {
    unsafe { __s2sdk_CreateConVarUInt32.expect("CreateConVarUInt32 function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarUInt32 = unsafe extern "C" fn(&Str, u32, &Str, ConVarFlag, bool, u32, bool, u32) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarUInt32: Option<_CreateConVarUInt32> = None;

/// Creates a new 64-bit signed integer console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (int64): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (int64): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (int64): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarInt64(name: &Str, defaultValue: i64, description: &Str, flags: ConVarFlag, hasMin: bool, min: i64, hasMax: bool, max: i64) -> u64 {
    unsafe { __s2sdk_CreateConVarInt64.expect("CreateConVarInt64 function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarInt64 = unsafe extern "C" fn(&Str, i64, &Str, ConVarFlag, bool, i64, bool, i64) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarInt64: Option<_CreateConVarInt64> = None;

/// Creates a new 64-bit unsigned integer console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (uint64): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (uint64): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (uint64): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarUInt64(name: &Str, defaultValue: u64, description: &Str, flags: ConVarFlag, hasMin: bool, min: u64, hasMax: bool, max: u64) -> u64 {
    unsafe { __s2sdk_CreateConVarUInt64.expect("CreateConVarUInt64 function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarUInt64 = unsafe extern "C" fn(&Str, u64, &Str, ConVarFlag, bool, u64, bool, u64) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarUInt64: Option<_CreateConVarUInt64> = None;

/// Creates a new floating-point console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (float): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (float): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (float): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarFloat(name: &Str, defaultValue: f32, description: &Str, flags: ConVarFlag, hasMin: bool, min: f32, hasMax: bool, max: f32) -> u64 {
    unsafe { __s2sdk_CreateConVarFloat.expect("CreateConVarFloat function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarFloat = unsafe extern "C" fn(&Str, f32, &Str, ConVarFlag, bool, f32, bool, f32) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarFloat: Option<_CreateConVarFloat> = None;

/// Creates a new double-precision console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (double): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (double): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (double): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarDouble(name: &Str, defaultValue: f64, description: &Str, flags: ConVarFlag, hasMin: bool, min: f64, hasMax: bool, max: f64) -> u64 {
    unsafe { __s2sdk_CreateConVarDouble.expect("CreateConVarDouble function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarDouble = unsafe extern "C" fn(&Str, f64, &Str, ConVarFlag, bool, f64, bool, f64) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarDouble: Option<_CreateConVarDouble> = None;

/// Creates a new color console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (vec4): The default color value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (vec4): The minimum color value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (vec4): The maximum color value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarColor(name: &Str, defaultValue: &Vec4, description: &Str, flags: ConVarFlag, hasMin: bool, min: &Vec4, hasMax: bool, max: &Vec4) -> u64 {
    unsafe { __s2sdk_CreateConVarColor.expect("CreateConVarColor function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarColor = unsafe extern "C" fn(&Str, &Vec4, &Str, ConVarFlag, bool, &Vec4, bool, &Vec4) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarColor: Option<_CreateConVarColor> = None;

/// Creates a new 2D vector console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (vec2): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (vec2): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (vec2): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarVector2(name: &Str, defaultValue: &Vec2, description: &Str, flags: ConVarFlag, hasMin: bool, min: &Vec2, hasMax: bool, max: &Vec2) -> u64 {
    unsafe { __s2sdk_CreateConVarVector2.expect("CreateConVarVector2 function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarVector2 = unsafe extern "C" fn(&Str, &Vec2, &Str, ConVarFlag, bool, &Vec2, bool, &Vec2) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarVector2: Option<_CreateConVarVector2> = None;

/// Creates a new 3D vector console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (vec3): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (vec3): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (vec3): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarVector3(name: &Str, defaultValue: &Vec3, description: &Str, flags: ConVarFlag, hasMin: bool, min: &Vec3, hasMax: bool, max: &Vec3) -> u64 {
    unsafe { __s2sdk_CreateConVarVector3.expect("CreateConVarVector3 function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarVector3 = unsafe extern "C" fn(&Str, &Vec3, &Str, ConVarFlag, bool, &Vec3, bool, &Vec3) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarVector3: Option<_CreateConVarVector3> = None;

/// Creates a new 4D vector console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (vec4): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (vec4): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (vec4): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarVector4(name: &Str, defaultValue: &Vec4, description: &Str, flags: ConVarFlag, hasMin: bool, min: &Vec4, hasMax: bool, max: &Vec4) -> u64 {
    unsafe { __s2sdk_CreateConVarVector4.expect("CreateConVarVector4 function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarVector4 = unsafe extern "C" fn(&Str, &Vec4, &Str, ConVarFlag, bool, &Vec4, bool, &Vec4) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarVector4: Option<_CreateConVarVector4> = None;

/// Creates a new quaternion angle console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (vec3): The default value for the console variable.
/// * `description` - (string): A brief description of the console variable.
/// * `flags` - (int64): Flags that define the behavior of the console variable.
/// * `hasMin` - (bool): Indicates if a minimum value is provided.
/// * `min` - (vec3): The minimum value if hasMin is true.
/// * `hasMax` - (bool): Indicates if a maximum value is provided.
/// * `max` - (vec3): The maximum value if hasMax is true.
///
/// # Returns - (uint64):
/// A handle to the created console variable data.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarQAngle(name: &Str, defaultValue: &Vec3, description: &Str, flags: ConVarFlag, hasMin: bool, min: &Vec3, hasMax: bool, max: &Vec3) -> u64 {
    unsafe { __s2sdk_CreateConVarQAngle.expect("CreateConVarQAngle function was not found")(name, defaultValue, description, flags, hasMin, min, hasMax, max) }
}
pub type _CreateConVarQAngle = unsafe extern "C" fn(&Str, &Vec3, &Str, ConVarFlag, bool, &Vec3, bool, &Vec3) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarQAngle: Option<_CreateConVarQAngle> = None;

/// Creates a new string console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable.
/// * `defaultValue` - (string): The default value of the console variable.
/// * `description` - (string): A description of the console variable's purpose.
/// * `flags` - (int64): Additional flags for the console variable.
///
/// # Returns - (uint64):
/// A handle to the created console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateConVarString(name: &Str, defaultValue: &Str, description: &Str, flags: ConVarFlag) -> u64 {
    unsafe { __s2sdk_CreateConVarString.expect("CreateConVarString function was not found")(name, defaultValue, description, flags) }
}
pub type _CreateConVarString = unsafe extern "C" fn(&Str, &Str, &Str, ConVarFlag) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateConVarString: Option<_CreateConVarString> = None;

/// Searches for a console variable.
///
/// # Arguments
/// * `name` - (string): The name of the console variable to search for.
///
/// # Returns - (uint64):
/// A handle to the console variable data if found; otherwise, nullptr.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FindConVar(name: &Str) -> u64 {
    unsafe { __s2sdk_FindConVar.expect("FindConVar function was not found")(name) }
}
pub type _FindConVar = unsafe extern "C" fn(&Str) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FindConVar: Option<_FindConVar> = None;

/// Searches for a console variable of a specific type.
///
/// # Arguments
/// * `name` - (string): The name of the console variable to search for.
/// * `type_` - (int16): The type of the console variable to search for.
///
/// # Returns - (uint64):
/// A handle to the console variable data if found; otherwise, nullptr.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FindConVar2(name: &Str, type_: ConVarType) -> u64 {
    unsafe { __s2sdk_FindConVar2.expect("FindConVar2 function was not found")(name, type_) }
}
pub type _FindConVar2 = unsafe extern "C" fn(&Str, ConVarType) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FindConVar2: Option<_FindConVar2> = None;

/// Creates a hook for when a console variable's value is changed.
///
/// # Arguments
/// * `conVarHandle` - (uint64): TThe handle to the console variable data.
/// * `callback` - (function): The callback function to be executed when the variable's value changes.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn HookConVarChange(conVarHandle: u64, callback: ConVarCallback) {
    unsafe { __s2sdk_HookConVarChange.expect("HookConVarChange function was not found")(conVarHandle, callback) }
}
pub type _HookConVarChange = unsafe extern "C" fn(u64, ConVarCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_HookConVarChange: Option<_HookConVarChange> = None;

/// Removes a hook for when a console variable's value is changed.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `callback` - (function): The callback function to be removed.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UnhookConVarChange(conVarHandle: u64, callback: ConVarCallback) {
    unsafe { __s2sdk_UnhookConVarChange.expect("UnhookConVarChange function was not found")(conVarHandle, callback) }
}
pub type _UnhookConVarChange = unsafe extern "C" fn(u64, ConVarCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UnhookConVarChange: Option<_UnhookConVarChange> = None;

/// Checks if a specific flag is set for a console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `flag` - (int64): The flag to check against the console variable.
///
/// # Returns - (bool):
/// True if the flag is set; otherwise, false.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsConVarFlagSet(conVarHandle: u64, flag: i64) -> bool {
    unsafe { __s2sdk_IsConVarFlagSet.expect("IsConVarFlagSet function was not found")(conVarHandle, flag) }
}
pub type _IsConVarFlagSet = unsafe extern "C" fn(u64, i64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsConVarFlagSet: Option<_IsConVarFlagSet> = None;

/// Adds flags to a console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `flags` - (int64): The flags to be added.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AddConVarFlags(conVarHandle: u64, flags: ConVarFlag) {
    unsafe { __s2sdk_AddConVarFlags.expect("AddConVarFlags function was not found")(conVarHandle, flags) }
}
pub type _AddConVarFlags = unsafe extern "C" fn(u64, ConVarFlag);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AddConVarFlags: Option<_AddConVarFlags> = None;

/// Removes flags from a console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `flags` - (int64): The flags to be removed.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RemoveConVarFlags(conVarHandle: u64, flags: ConVarFlag) {
    unsafe { __s2sdk_RemoveConVarFlags.expect("RemoveConVarFlags function was not found")(conVarHandle, flags) }
}
pub type _RemoveConVarFlags = unsafe extern "C" fn(u64, ConVarFlag);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RemoveConVarFlags: Option<_RemoveConVarFlags> = None;

/// Retrieves the current flags of a console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (int64):
/// The current flags set on the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarFlags(conVarHandle: u64) -> ConVarFlag {
    unsafe { __s2sdk_GetConVarFlags.expect("GetConVarFlags function was not found")(conVarHandle) }
}
pub type _GetConVarFlags = unsafe extern "C" fn(u64) -> ConVarFlag;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarFlags: Option<_GetConVarFlags> = None;

/// Gets the specified bound (max or min) of a console variable and stores it in the output string.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `max` - (bool): Indicates whether to get the maximum (true) or minimum (false) bound.
///
/// # Returns - (string):
/// The bound value.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarBounds(conVarHandle: u64, max: bool) -> Str {
    unsafe { __s2sdk_GetConVarBounds.expect("GetConVarBounds function was not found")(conVarHandle, max) }
}
pub type _GetConVarBounds = unsafe extern "C" fn(u64, bool) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarBounds: Option<_GetConVarBounds> = None;

/// Sets the specified bound (max or min) for a console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `max` - (bool): Indicates whether to set the maximum (true) or minimum (false) bound.
/// * `value` - (string): The value to set as the bound.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarBounds(conVarHandle: u64, max: bool, value: &Str) {
    unsafe { __s2sdk_SetConVarBounds.expect("SetConVarBounds function was not found")(conVarHandle, max, value) }
}
pub type _SetConVarBounds = unsafe extern "C" fn(u64, bool, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarBounds: Option<_SetConVarBounds> = None;

/// Retrieves the default value of a console variable and stores it in the output string.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (string):
/// The output value in string format.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarDefault(conVarHandle: u64) -> Str {
    unsafe { __s2sdk_GetConVarDefault.expect("GetConVarDefault function was not found")(conVarHandle) }
}
pub type _GetConVarDefault = unsafe extern "C" fn(u64) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarDefault: Option<_GetConVarDefault> = None;

/// Retrieves the current value of a console variable and stores it in the output string.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (string):
/// The output value in string format.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarValue(conVarHandle: u64) -> Str {
    unsafe { __s2sdk_GetConVarValue.expect("GetConVarValue function was not found")(conVarHandle) }
}
pub type _GetConVarValue = unsafe extern "C" fn(u64) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarValue: Option<_GetConVarValue> = None;

/// Retrieves the current value of a console variable and stores it in the output.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (any):
/// The output value.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVar(conVarHandle: u64) -> Var {
    unsafe { __s2sdk_GetConVar.expect("GetConVar function was not found")(conVarHandle) }
}
pub type _GetConVar = unsafe extern "C" fn(u64) -> Var;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVar: Option<_GetConVar> = None;

/// Retrieves the current value of a boolean console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (bool):
/// The current boolean value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarBool(conVarHandle: u64) -> bool {
    unsafe { __s2sdk_GetConVarBool.expect("GetConVarBool function was not found")(conVarHandle) }
}
pub type _GetConVarBool = unsafe extern "C" fn(u64) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarBool: Option<_GetConVarBool> = None;

/// Retrieves the current value of a signed 16-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (int16):
/// The current int16_t value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarInt16(conVarHandle: u64) -> i16 {
    unsafe { __s2sdk_GetConVarInt16.expect("GetConVarInt16 function was not found")(conVarHandle) }
}
pub type _GetConVarInt16 = unsafe extern "C" fn(u64) -> i16;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarInt16: Option<_GetConVarInt16> = None;

/// Retrieves the current value of an unsigned 16-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (uint16):
/// The current uint16_t value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarUInt16(conVarHandle: u64) -> u16 {
    unsafe { __s2sdk_GetConVarUInt16.expect("GetConVarUInt16 function was not found")(conVarHandle) }
}
pub type _GetConVarUInt16 = unsafe extern "C" fn(u64) -> u16;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarUInt16: Option<_GetConVarUInt16> = None;

/// Retrieves the current value of a signed 32-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (int32):
/// The current int32_t value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarInt32(conVarHandle: u64) -> i32 {
    unsafe { __s2sdk_GetConVarInt32.expect("GetConVarInt32 function was not found")(conVarHandle) }
}
pub type _GetConVarInt32 = unsafe extern "C" fn(u64) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarInt32: Option<_GetConVarInt32> = None;

/// Retrieves the current value of an unsigned 32-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (uint32):
/// The current uint32_t value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarUInt32(conVarHandle: u64) -> u32 {
    unsafe { __s2sdk_GetConVarUInt32.expect("GetConVarUInt32 function was not found")(conVarHandle) }
}
pub type _GetConVarUInt32 = unsafe extern "C" fn(u64) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarUInt32: Option<_GetConVarUInt32> = None;

/// Retrieves the current value of a signed 64-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (int64):
/// The current int64_t value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarInt64(conVarHandle: u64) -> i64 {
    unsafe { __s2sdk_GetConVarInt64.expect("GetConVarInt64 function was not found")(conVarHandle) }
}
pub type _GetConVarInt64 = unsafe extern "C" fn(u64) -> i64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarInt64: Option<_GetConVarInt64> = None;

/// Retrieves the current value of an unsigned 64-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (uint64):
/// The current uint64_t value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarUInt64(conVarHandle: u64) -> u64 {
    unsafe { __s2sdk_GetConVarUInt64.expect("GetConVarUInt64 function was not found")(conVarHandle) }
}
pub type _GetConVarUInt64 = unsafe extern "C" fn(u64) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarUInt64: Option<_GetConVarUInt64> = None;

/// Retrieves the current value of a float console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (float):
/// The current float value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarFloat(conVarHandle: u64) -> f32 {
    unsafe { __s2sdk_GetConVarFloat.expect("GetConVarFloat function was not found")(conVarHandle) }
}
pub type _GetConVarFloat = unsafe extern "C" fn(u64) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarFloat: Option<_GetConVarFloat> = None;

/// Retrieves the current value of a double console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (double):
/// The current double value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarDouble(conVarHandle: u64) -> f64 {
    unsafe { __s2sdk_GetConVarDouble.expect("GetConVarDouble function was not found")(conVarHandle) }
}
pub type _GetConVarDouble = unsafe extern "C" fn(u64) -> f64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarDouble: Option<_GetConVarDouble> = None;

/// Retrieves the current value of a string console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (string):
/// The current string value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarString(conVarHandle: u64) -> Str {
    unsafe { __s2sdk_GetConVarString.expect("GetConVarString function was not found")(conVarHandle) }
}
pub type _GetConVarString = unsafe extern "C" fn(u64) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarString: Option<_GetConVarString> = None;

/// Retrieves the current value of a Color console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (vec4):
/// The current Color value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarColor(conVarHandle: u64) -> Vec4 {
    unsafe { __s2sdk_GetConVarColor.expect("GetConVarColor function was not found")(conVarHandle) }
}
pub type _GetConVarColor = unsafe extern "C" fn(u64) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarColor: Option<_GetConVarColor> = None;

/// Retrieves the current value of a Vector2D console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (vec2):
/// The current Vector2D value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarVector2(conVarHandle: u64) -> Vec2 {
    unsafe { __s2sdk_GetConVarVector2.expect("GetConVarVector2 function was not found")(conVarHandle) }
}
pub type _GetConVarVector2 = unsafe extern "C" fn(u64) -> Vec2;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarVector2: Option<_GetConVarVector2> = None;

/// Retrieves the current value of a Vector console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (vec3):
/// The current Vector value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarVector(conVarHandle: u64) -> Vec3 {
    unsafe { __s2sdk_GetConVarVector.expect("GetConVarVector function was not found")(conVarHandle) }
}
pub type _GetConVarVector = unsafe extern "C" fn(u64) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarVector: Option<_GetConVarVector> = None;

/// Retrieves the current value of a Vector4D console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (vec4):
/// The current Vector4D value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarVector4(conVarHandle: u64) -> Vec4 {
    unsafe { __s2sdk_GetConVarVector4.expect("GetConVarVector4 function was not found")(conVarHandle) }
}
pub type _GetConVarVector4 = unsafe extern "C" fn(u64) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarVector4: Option<_GetConVarVector4> = None;

/// Retrieves the current value of a QAngle console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
///
/// # Returns - (vec3):
/// The current QAngle value of the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetConVarQAngle(conVarHandle: u64) -> Vec3 {
    unsafe { __s2sdk_GetConVarQAngle.expect("GetConVarQAngle function was not found")(conVarHandle) }
}
pub type _GetConVarQAngle = unsafe extern "C" fn(u64) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetConVarQAngle: Option<_GetConVarQAngle> = None;

/// Sets the value of a console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (string): The string value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarValue(conVarHandle: u64, value: &Str, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarValue.expect("SetConVarValue function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarValue = unsafe extern "C" fn(u64, &Str, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarValue: Option<_SetConVarValue> = None;

/// Sets the value of a console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (any): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVar(conVarHandle: u64, value: &Var, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVar.expect("SetConVar function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVar = unsafe extern "C" fn(u64, &Var, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVar: Option<_SetConVar> = None;

/// Sets the value of a boolean console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (bool): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarBool(conVarHandle: u64, value: bool, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarBool.expect("SetConVarBool function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarBool = unsafe extern "C" fn(u64, bool, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarBool: Option<_SetConVarBool> = None;

/// Sets the value of a signed 16-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (int16): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarInt16(conVarHandle: u64, value: i16, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarInt16.expect("SetConVarInt16 function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarInt16 = unsafe extern "C" fn(u64, i16, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarInt16: Option<_SetConVarInt16> = None;

/// Sets the value of an unsigned 16-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (uint16): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarUInt16(conVarHandle: u64, value: u16, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarUInt16.expect("SetConVarUInt16 function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarUInt16 = unsafe extern "C" fn(u64, u16, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarUInt16: Option<_SetConVarUInt16> = None;

/// Sets the value of a signed 32-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (int32): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarInt32(conVarHandle: u64, value: i32, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarInt32.expect("SetConVarInt32 function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarInt32 = unsafe extern "C" fn(u64, i32, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarInt32: Option<_SetConVarInt32> = None;

/// Sets the value of an unsigned 32-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (uint32): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarUInt32(conVarHandle: u64, value: u32, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarUInt32.expect("SetConVarUInt32 function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarUInt32 = unsafe extern "C" fn(u64, u32, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarUInt32: Option<_SetConVarUInt32> = None;

/// Sets the value of a signed 64-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (int64): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarInt64(conVarHandle: u64, value: i64, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarInt64.expect("SetConVarInt64 function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarInt64 = unsafe extern "C" fn(u64, i64, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarInt64: Option<_SetConVarInt64> = None;

/// Sets the value of an unsigned 64-bit integer console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (uint64): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarUInt64(conVarHandle: u64, value: u64, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarUInt64.expect("SetConVarUInt64 function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarUInt64 = unsafe extern "C" fn(u64, u64, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarUInt64: Option<_SetConVarUInt64> = None;

/// Sets the value of a floating-point console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (float): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarFloat(conVarHandle: u64, value: f32, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarFloat.expect("SetConVarFloat function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarFloat = unsafe extern "C" fn(u64, f32, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarFloat: Option<_SetConVarFloat> = None;

/// Sets the value of a double-precision floating-point console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (double): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarDouble(conVarHandle: u64, value: f64, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarDouble.expect("SetConVarDouble function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarDouble = unsafe extern "C" fn(u64, f64, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarDouble: Option<_SetConVarDouble> = None;

/// Sets the value of a string console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (string): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarString(conVarHandle: u64, value: &Str, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarString.expect("SetConVarString function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarString = unsafe extern "C" fn(u64, &Str, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarString: Option<_SetConVarString> = None;

/// Sets the value of a color console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (vec4): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarColor(conVarHandle: u64, value: &Vec4, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarColor.expect("SetConVarColor function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarColor = unsafe extern "C" fn(u64, &Vec4, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarColor: Option<_SetConVarColor> = None;

/// Sets the value of a 2D vector console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (vec2): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarVector2(conVarHandle: u64, value: &Vec2, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarVector2.expect("SetConVarVector2 function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarVector2 = unsafe extern "C" fn(u64, &Vec2, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarVector2: Option<_SetConVarVector2> = None;

/// Sets the value of a 3D vector console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (vec3): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarVector3(conVarHandle: u64, value: &Vec3, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarVector3.expect("SetConVarVector3 function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarVector3 = unsafe extern "C" fn(u64, &Vec3, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarVector3: Option<_SetConVarVector3> = None;

/// Sets the value of a 4D vector console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (vec4): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarVector4(conVarHandle: u64, value: &Vec4, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarVector4.expect("SetConVarVector4 function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarVector4 = unsafe extern "C" fn(u64, &Vec4, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarVector4: Option<_SetConVarVector4> = None;

/// Sets the value of a quaternion angle console variable.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (vec3): The value to set for the console variable.
/// * `replicate` - (bool): If set to true, the new convar value will be set on all clients. This will only work if the convar has the FCVAR_REPLICATED flag and actually exists on clients.
/// * `notify` - (bool): If set to true, clients will be notified that the convar has changed. This will only work if the convar has the FCVAR_NOTIFY flag.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetConVarQAngle(conVarHandle: u64, value: &Vec3, replicate: bool, notify: bool) {
    unsafe { __s2sdk_SetConVarQAngle.expect("SetConVarQAngle function was not found")(conVarHandle, value, replicate, notify) }
}
pub type _SetConVarQAngle = unsafe extern "C" fn(u64, &Vec3, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetConVarQAngle: Option<_SetConVarQAngle> = None;

/// Replicates a console variable value to a specific client. This does not change the actual console variable value.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the client to replicate the value to.
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `value` - (string): The value to send to the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SendConVarValue(playerSlot: i32, conVarHandle: u64, value: &Str) {
    unsafe { __s2sdk_SendConVarValue.expect("SendConVarValue function was not found")(playerSlot, conVarHandle, value) }
}
pub type _SendConVarValue = unsafe extern "C" fn(i32, u64, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SendConVarValue: Option<_SendConVarValue> = None;

/// Replicates a console variable value to a specific client. This does not change the actual console variable value.
///
/// # Arguments
/// * `conVarHandle` - (uint64): The handle to the console variable data.
/// * `playerSlot` - (int32): The index of the client to replicate the value to.
/// * `value` - (string): The value to send to the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SendConVarValue2(conVarHandle: u64, playerSlot: i32, value: &Str) {
    unsafe { __s2sdk_SendConVarValue2.expect("SendConVarValue2 function was not found")(conVarHandle, playerSlot, value) }
}
pub type _SendConVarValue2 = unsafe extern "C" fn(u64, i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SendConVarValue2: Option<_SendConVarValue2> = None;

/// Retrieves the value of a client's console variable and stores it in the output string.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the client whose console variable value is being retrieved.
/// * `convarName` - (string): The name of the console variable to retrieve.
///
/// # Returns - (string):
/// The output string to store the client's console variable value.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientConVarValue(playerSlot: i32, convarName: &Str) -> Str {
    unsafe { __s2sdk_GetClientConVarValue.expect("GetClientConVarValue function was not found")(playerSlot, convarName) }
}
pub type _GetClientConVarValue = unsafe extern "C" fn(i32, &Str) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientConVarValue: Option<_GetClientConVarValue> = None;

/// Replicates a console variable value to a specific fake client. This does not change the actual console variable value.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the fake client to replicate the value to.
/// * `convarName` - (string): The name of the console variable.
/// * `convarValue` - (string): The value to set for the console variable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetFakeClientConVarValue(playerSlot: i32, convarName: &Str, convarValue: &Str) {
    unsafe { __s2sdk_SetFakeClientConVarValue.expect("SetFakeClientConVarValue function was not found")(playerSlot, convarName, convarValue) }
}
pub type _SetFakeClientConVarValue = unsafe extern "C" fn(i32, &Str, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetFakeClientConVarValue: Option<_SetFakeClientConVarValue> = None;

/// Starts a query to retrieve the value of a client's console variable.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to query the value from.
/// * `convarName` - (string): The name of client convar to query.
/// * `callback` - (function): A function to use as a callback when the query has finished.
/// * `data` - (any[]): Optional values to pass to the callback function.
///
/// # Returns - (int32):
/// A cookie that uniquely identifies the query. Returns -1 on failure, such as when used on a bot.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn QueryClientConVar(playerSlot: i32, convarName: &Str, callback: CvarValueCallback, data: &Arr<Var>) -> i32 {
    unsafe { __s2sdk_QueryClientConVar.expect("QueryClientConVar function was not found")(playerSlot, convarName, callback, data) }
}
pub type _QueryClientConVar = unsafe extern "C" fn(i32, &Str, CvarValueCallback, &Arr<Var>) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_QueryClientConVar: Option<_QueryClientConVar> = None;

///  Specifies that the given config file should be executed.
///
/// # Arguments
/// * `conVarHandles` - (uint64[]): List of handles to the console variable data.
/// * `autoCreate` - (bool): If true, and the config file does not exist, such a config file will be automatically created and populated with information from the plugin's registered cvars.
/// * `name` - (string): Name of the config file, excluding the .cfg extension. Cannot be empty.
/// * `folder` - (string): Folder under cfg/ to use. By default this is "plugify." Can be empty.
///
/// # Returns - (bool):
/// True on success, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AutoExecConfig(conVarHandles: &Arr<u64>, autoCreate: bool, name: &Str, folder: &Str) -> bool {
    unsafe { __s2sdk_AutoExecConfig.expect("AutoExecConfig function was not found")(conVarHandles, autoCreate, name, folder) }
}
pub type _AutoExecConfig = unsafe extern "C" fn(&Arr<u64>, bool, &Str, &Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AutoExecConfig: Option<_AutoExecConfig> = None;

/// Returns the current server language.
///
/// # Returns - (string):
/// The server language as a string.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetServerLanguage() -> Str {
    unsafe { __s2sdk_GetServerLanguage.expect("GetServerLanguage function was not found")() }
}
pub type _GetServerLanguage = unsafe extern "C" fn() -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetServerLanguage: Option<_GetServerLanguage> = None;

/// Returns all console variables registered by this plugin
///
/// # Returns - (string[]):
/// The vector of ConVar names.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetAllConVars() -> Arr<Str> {
    unsafe { __s2sdk_GetAllConVars.expect("GetAllConVars function was not found")() }
}
pub type _GetAllConVars = unsafe extern "C" fn() -> Arr<Str>;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetAllConVars: Option<_GetAllConVars> = None;

