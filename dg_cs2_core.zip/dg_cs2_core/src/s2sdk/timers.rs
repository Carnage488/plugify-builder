// Generated from s2sdk.pplugin (group: timers)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Creates a new timer that executes a callback function at specified delays.
///
/// # Arguments
/// * `delay` - (double): The time delay in seconds between each callback execution.
/// * `callback` - (function): The function to be called when the timer expires.
/// * `flags` - (int32): Flags that modify the behavior of the timer (e.g., no-map change, repeating).
/// * `userData` - (any[]): An array intended to hold user-related data, allowing for elements of any type.
///
/// # Returns - (uint32):
/// A id to the newly created Timer object, or -1 if the timer could not be created.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateTimer(delay: f64, callback: TimerCallback, flags: TimerFlag, userData: &Arr<Var>) -> u32 {
    unsafe { __s2sdk_CreateTimer.expect("CreateTimer function was not found")(delay, callback, flags, userData) }
}
pub type _CreateTimer = unsafe extern "C" fn(f64, TimerCallback, TimerFlag, &Arr<Var>) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateTimer: Option<_CreateTimer> = None;

/// Stops and removes an existing timer.
///
/// # Arguments
/// * `timer` - (uint32): A id of the Timer object to be stopped and removed.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn KillsTimer(timer: u32) {
    unsafe { __s2sdk_KillsTimer.expect("KillsTimer function was not found")(timer) }
}
pub type _KillsTimer = unsafe extern "C" fn(u32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_KillsTimer: Option<_KillsTimer> = None;

/// Reschedules an existing timer with a new delay.
///
/// # Arguments
/// * `timer` - (uint32): A id of the Timer object to be stopped and removed.
/// * `newDaly` - (double): The new delay in seconds between each callback execution.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RescheduleTimer(timer: u32, newDaly: f64) {
    unsafe { __s2sdk_RescheduleTimer.expect("RescheduleTimer function was not found")(timer, newDaly) }
}
pub type _RescheduleTimer = unsafe extern "C" fn(u32, f64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RescheduleTimer: Option<_RescheduleTimer> = None;

/// Returns the number of seconds in between game server ticks.
///
/// # Returns - (double):
/// The tick interval value.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetTickInterval() -> f64 {
    unsafe { __s2sdk_GetTickInterval.expect("GetTickInterval function was not found")() }
}
pub type _GetTickInterval = unsafe extern "C" fn() -> f64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetTickInterval: Option<_GetTickInterval> = None;

/// Returns the simulated game time.
///
/// # Returns - (double):
/// The ticked time value.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetTickedTime() -> f64 {
    unsafe { __s2sdk_GetTickedTime.expect("GetTickedTime function was not found")() }
}
pub type _GetTickedTime = unsafe extern "C" fn() -> f64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetTickedTime: Option<_GetTickedTime> = None;

