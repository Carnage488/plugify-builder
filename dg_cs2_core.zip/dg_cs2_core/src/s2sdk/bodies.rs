// Generated from s2sdk.pplugin (group: bodies)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Applies an impulse to an entity at a specific world position.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `position` - (vec3): The world position where the impulse will be applied.
/// * `impulse` - (vec3): The impulse vector to apply.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AddBodyImpulseAtPosition(entityHandle: i32, position: &Vec3, impulse: &Vec3) {
    unsafe { __s2sdk_AddBodyImpulseAtPosition.expect("AddBodyImpulseAtPosition function was not found")(entityHandle, position, impulse) }
}
pub type _AddBodyImpulseAtPosition = unsafe extern "C" fn(i32, &Vec3, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AddBodyImpulseAtPosition: Option<_AddBodyImpulseAtPosition> = None;

/// Adds linear and angular velocity to the entity's physics object.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `linearVelocity` - (vec3): The linear velocity vector to add.
/// * `angularVelocity` - (vec3): The angular velocity vector to add.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AddBodyVelocity(entityHandle: i32, linearVelocity: &Vec3, angularVelocity: &Vec3) {
    unsafe { __s2sdk_AddBodyVelocity.expect("AddBodyVelocity function was not found")(entityHandle, linearVelocity, angularVelocity) }
}
pub type _AddBodyVelocity = unsafe extern "C" fn(i32, &Vec3, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AddBodyVelocity: Option<_AddBodyVelocity> = None;

/// Detaches the entity from its parent.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DetachBodyFromParent(entityHandle: i32) {
    unsafe { __s2sdk_DetachBodyFromParent.expect("DetachBodyFromParent function was not found")(entityHandle) }
}
pub type _DetachBodyFromParent = unsafe extern "C" fn(i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DetachBodyFromParent: Option<_DetachBodyFromParent> = None;

/// Retrieves the currently active sequence of the entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
///
/// # Returns - (int32):
/// The sequence ID of the active sequence, or -1 if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetBodySequence(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetBodySequence.expect("GetBodySequence function was not found")(entityHandle) }
}
pub type _GetBodySequence = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetBodySequence: Option<_GetBodySequence> = None;

/// Checks whether the entity is attached to a parent.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
///
/// # Returns - (bool):
/// True if attached to a parent, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsBodyAttachedToParent(entityHandle: i32) -> bool {
    unsafe { __s2sdk_IsBodyAttachedToParent.expect("IsBodyAttachedToParent function was not found")(entityHandle) }
}
pub type _IsBodyAttachedToParent = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsBodyAttachedToParent: Option<_IsBodyAttachedToParent> = None;

/// Looks up a sequence ID by its name.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `name` - (string): The name of the sequence.
///
/// # Returns - (int32):
/// The sequence ID, or -1 if not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn LookupBodySequence(entityHandle: i32, name: &Str) -> i32 {
    unsafe { __s2sdk_LookupBodySequence.expect("LookupBodySequence function was not found")(entityHandle, name) }
}
pub type _LookupBodySequence = unsafe extern "C" fn(i32, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_LookupBodySequence: Option<_LookupBodySequence> = None;

/// Retrieves the duration of a specified sequence.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `sequenceName` - (string): The name of the sequence.
///
/// # Returns - (float):
/// The duration of the sequence in seconds, or 0 if invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetBodySequenceDuration(entityHandle: i32, sequenceName: &Str) -> f32 {
    unsafe { __s2sdk_SetBodySequenceDuration.expect("SetBodySequenceDuration function was not found")(entityHandle, sequenceName) }
}
pub type _SetBodySequenceDuration = unsafe extern "C" fn(i32, &Str) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetBodySequenceDuration: Option<_SetBodySequenceDuration> = None;

/// Sets the angular velocity of the entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `angVelocity` - (vec3): The new angular velocity vector.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetBodyAngularVelocity(entityHandle: i32, angVelocity: &Vec3) {
    unsafe { __s2sdk_SetBodyAngularVelocity.expect("SetBodyAngularVelocity function was not found")(entityHandle, angVelocity) }
}
pub type _SetBodyAngularVelocity = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetBodyAngularVelocity: Option<_SetBodyAngularVelocity> = None;

/// Sets the material group of the entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `materialGroup` - (string): The material group token to assign.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetBodyMaterialGroup(entityHandle: i32, materialGroup: &Str) {
    unsafe { __s2sdk_SetBodyMaterialGroup.expect("SetBodyMaterialGroup function was not found")(entityHandle, materialGroup) }
}
pub type _SetBodyMaterialGroup = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetBodyMaterialGroup: Option<_SetBodyMaterialGroup> = None;

/// Sets the linear velocity of the entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `velocity` - (vec3): The new velocity vector.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetBodyVelocity(entityHandle: i32, velocity: &Vec3) {
    unsafe { __s2sdk_SetBodyVelocity.expect("SetBodyVelocity function was not found")(entityHandle, velocity) }
}
pub type _SetBodyVelocity = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetBodyVelocity: Option<_SetBodyVelocity> = None;

