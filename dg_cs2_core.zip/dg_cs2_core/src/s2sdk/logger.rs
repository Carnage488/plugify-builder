// Generated from s2sdk.pplugin (group: logger)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Registers a new logging channel with specified properties.
///
/// # Arguments
/// * `name` - (string): The name of the logging channel.
/// * `flags` - (int32): Flags associated with the logging channel.
/// * `verbosity` - (int32): The verbosity level for the logging channel.
/// * `color` - (vec4): The color for messages logged to this channel.
///
/// # Returns - (int32):
/// The ID of the newly created logging channel.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RegisterLoggingChannel(name: &Str, flags: i32, verbosity: LoggingVerbosity, color: &Vec4) -> i32 {
    unsafe { __s2sdk_RegisterLoggingChannel.expect("RegisterLoggingChannel function was not found")(name, flags, verbosity, color) }
}
pub type _RegisterLoggingChannel = unsafe extern "C" fn(&Str, i32, LoggingVerbosity, &Vec4) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RegisterLoggingChannel: Option<_RegisterLoggingChannel> = None;

/// Adds a tag to a specified logging channel.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel to which the tag will be added.
/// * `tagName` - (string): The name of the tag to add to the channel.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AddLoggerTagToChannel(channelID: i32, tagName: &Str) {
    unsafe { __s2sdk_AddLoggerTagToChannel.expect("AddLoggerTagToChannel function was not found")(channelID, tagName) }
}
pub type _AddLoggerTagToChannel = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AddLoggerTagToChannel: Option<_AddLoggerTagToChannel> = None;

/// Checks if a specified tag exists in a logging channel.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `tag` - (string): The name of the tag to check for.
///
/// # Returns - (bool):
/// True if the tag exists in the channel, otherwise false.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn HasLoggerTag(channelID: i32, tag: &Str) -> bool {
    unsafe { __s2sdk_HasLoggerTag.expect("HasLoggerTag function was not found")(channelID, tag) }
}
pub type _HasLoggerTag = unsafe extern "C" fn(i32, &Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_HasLoggerTag: Option<_HasLoggerTag> = None;

/// Checks if a logging channel is enabled based on severity.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `severity` - (int32): The severity of a logging operation.
///
/// # Returns - (bool):
/// True if the channel is enabled for the specified severity, otherwise false.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsLoggerChannelEnabledBySeverity(channelID: i32, severity: LoggingSeverity) -> bool {
    unsafe { __s2sdk_IsLoggerChannelEnabledBySeverity.expect("IsLoggerChannelEnabledBySeverity function was not found")(channelID, severity) }
}
pub type _IsLoggerChannelEnabledBySeverity = unsafe extern "C" fn(i32, LoggingSeverity) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsLoggerChannelEnabledBySeverity: Option<_IsLoggerChannelEnabledBySeverity> = None;

/// Checks if a logging channel is enabled based on verbosity.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `verbosity` - (int32): The verbosity level to check.
///
/// # Returns - (bool):
/// True if the channel is enabled for the specified verbosity, otherwise false.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsLoggerChannelEnabledByVerbosity(channelID: i32, verbosity: LoggingVerbosity) -> bool {
    unsafe { __s2sdk_IsLoggerChannelEnabledByVerbosity.expect("IsLoggerChannelEnabledByVerbosity function was not found")(channelID, verbosity) }
}
pub type _IsLoggerChannelEnabledByVerbosity = unsafe extern "C" fn(i32, LoggingVerbosity) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsLoggerChannelEnabledByVerbosity: Option<_IsLoggerChannelEnabledByVerbosity> = None;

/// Retrieves the verbosity level of a logging channel.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
///
/// # Returns - (int32):
/// The verbosity level of the specified logging channel.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetLoggerChannelVerbosity(channelID: i32) -> i32 {
    unsafe { __s2sdk_GetLoggerChannelVerbosity.expect("GetLoggerChannelVerbosity function was not found")(channelID) }
}
pub type _GetLoggerChannelVerbosity = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetLoggerChannelVerbosity: Option<_GetLoggerChannelVerbosity> = None;

/// Sets the verbosity level of a logging channel.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `verbosity` - (int32): The new verbosity level to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetLoggerChannelVerbosity(channelID: i32, verbosity: LoggingVerbosity) {
    unsafe { __s2sdk_SetLoggerChannelVerbosity.expect("SetLoggerChannelVerbosity function was not found")(channelID, verbosity) }
}
pub type _SetLoggerChannelVerbosity = unsafe extern "C" fn(i32, LoggingVerbosity);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetLoggerChannelVerbosity: Option<_SetLoggerChannelVerbosity> = None;

/// Sets the verbosity level of a logging channel by name.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `name` - (string): The name of the logging channel.
/// * `verbosity` - (int32): The new verbosity level to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetLoggerChannelVerbosityByName(channelID: i32, name: &Str, verbosity: LoggingVerbosity) {
    unsafe { __s2sdk_SetLoggerChannelVerbosityByName.expect("SetLoggerChannelVerbosityByName function was not found")(channelID, name, verbosity) }
}
pub type _SetLoggerChannelVerbosityByName = unsafe extern "C" fn(i32, &Str, LoggingVerbosity);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetLoggerChannelVerbosityByName: Option<_SetLoggerChannelVerbosityByName> = None;

/// Sets the verbosity level of a logging channel by tag.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `tag` - (string): The name of the tag.
/// * `verbosity` - (int32): The new verbosity level to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetLoggerChannelVerbosityByTag(channelID: i32, tag: &Str, verbosity: LoggingVerbosity) {
    unsafe { __s2sdk_SetLoggerChannelVerbosityByTag.expect("SetLoggerChannelVerbosityByTag function was not found")(channelID, tag, verbosity) }
}
pub type _SetLoggerChannelVerbosityByTag = unsafe extern "C" fn(i32, &Str, LoggingVerbosity);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetLoggerChannelVerbosityByTag: Option<_SetLoggerChannelVerbosityByTag> = None;

/// Retrieves the color setting of a logging channel.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
///
/// # Returns - (vec4):
/// The color value of the specified logging channel.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetLoggerChannelColor(channelID: i32) -> Vec4 {
    unsafe { __s2sdk_GetLoggerChannelColor.expect("GetLoggerChannelColor function was not found")(channelID) }
}
pub type _GetLoggerChannelColor = unsafe extern "C" fn(i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetLoggerChannelColor: Option<_GetLoggerChannelColor> = None;

/// Sets the color setting of a logging channel.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `color` - (vec4): The new color value to set for the channel.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetLoggerChannelColor(channelID: i32, color: &Vec4) {
    unsafe { __s2sdk_SetLoggerChannelColor.expect("SetLoggerChannelColor function was not found")(channelID, color) }
}
pub type _SetLoggerChannelColor = unsafe extern "C" fn(i32, &Vec4);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetLoggerChannelColor: Option<_SetLoggerChannelColor> = None;

/// Retrieves the flags of a logging channel.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
///
/// # Returns - (int32):
/// The flags of the specified logging channel.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetLoggerChannelFlags(channelID: i32) -> i32 {
    unsafe { __s2sdk_GetLoggerChannelFlags.expect("GetLoggerChannelFlags function was not found")(channelID) }
}
pub type _GetLoggerChannelFlags = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetLoggerChannelFlags: Option<_GetLoggerChannelFlags> = None;

/// Sets the flags of a logging channel.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `eFlags` - (int32): The new flags to set for the channel.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetLoggerChannelFlags(channelID: i32, eFlags: LoggingChannelFlags) {
    unsafe { __s2sdk_SetLoggerChannelFlags.expect("SetLoggerChannelFlags function was not found")(channelID, eFlags) }
}
pub type _SetLoggerChannelFlags = unsafe extern "C" fn(i32, LoggingChannelFlags);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetLoggerChannelFlags: Option<_SetLoggerChannelFlags> = None;

/// Logs a message to a specified channel with a severity level.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `severity` - (int32): The severity level for the log message.
/// * `message` - (string): The message to log.
///
/// # Returns - (int32):
/// An integer indicating the result of the logging operation.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Log(channelID: i32, severity: LoggingSeverity, message: &Str) -> i32 {
    unsafe { __s2sdk_Log.expect("Log function was not found")(channelID, severity, message) }
}
pub type _Log = unsafe extern "C" fn(i32, LoggingSeverity, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Log: Option<_Log> = None;

/// Logs a colored message to a specified channel with a severity level.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `severity` - (int32): The severity level for the log message.
/// * `color` - (vec4): The color for the log message.
/// * `message` - (string): The message to log.
///
/// # Returns - (int32):
/// An integer indicating the result of the logging operation.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn LogColored(channelID: i32, severity: LoggingSeverity, color: &Vec4, message: &Str) -> i32 {
    unsafe { __s2sdk_LogColored.expect("LogColored function was not found")(channelID, severity, color, message) }
}
pub type _LogColored = unsafe extern "C" fn(i32, LoggingSeverity, &Vec4, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_LogColored: Option<_LogColored> = None;

/// Logs a detailed message to a specified channel, including source code info.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `severity` - (int32): The severity level for the log message.
/// * `file` - (string): The file name where the log call occurred.
/// * `line` - (int32): The line number where the log call occurred.
/// * `function` - (string): The name of the function where the log call occurred.
/// * `message` - (string): The message to log.
///
/// # Returns - (int32):
/// An integer indicating the result of the logging operation.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn LogFull(channelID: i32, severity: LoggingSeverity, file: &Str, line: i32, function: &Str, message: &Str) -> i32 {
    unsafe { __s2sdk_LogFull.expect("LogFull function was not found")(channelID, severity, file, line, function, message) }
}
pub type _LogFull = unsafe extern "C" fn(i32, LoggingSeverity, &Str, i32, &Str, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_LogFull: Option<_LogFull> = None;

/// Logs a detailed colored message to a specified channel, including source code info.
///
/// # Arguments
/// * `channelID` - (int32): The ID of the logging channel.
/// * `severity` - (int32): The severity level for the log message.
/// * `file` - (string): The file name where the log call occurred.
/// * `line` - (int32): The line number where the log call occurred.
/// * `function` - (string): The name of the function where the log call occurred.
/// * `color` - (vec4): The color for the log message.
/// * `message` - (string): The message to log.
///
/// # Returns - (int32):
/// An integer indicating the result of the logging operation.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn LogFullColored(channelID: i32, severity: LoggingSeverity, file: &Str, line: i32, function: &Str, color: &Vec4, message: &Str) -> i32 {
    unsafe { __s2sdk_LogFullColored.expect("LogFullColored function was not found")(channelID, severity, file, line, function, color, message) }
}
pub type _LogFullColored = unsafe extern "C" fn(i32, LoggingSeverity, &Str, i32, &Str, &Vec4, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_LogFullColored: Option<_LogFullColored> = None;

