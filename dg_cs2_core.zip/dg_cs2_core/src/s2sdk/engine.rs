// Generated from s2sdk.pplugin (group: engine)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Queries an interface from a specified module.
///
/// # Arguments
/// * `module` - (string): The name of the module to query the interface from.
/// * `name` - (string): The name of the interface to find.
///
/// # Returns - (ptr64):
/// A pointer to the queried interface.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn QueryInterface(module: &Str, name: &Str) -> usize {
    unsafe { __s2sdk_QueryInterface.expect("QueryInterface function was not found")(module, name) }
}
pub type _QueryInterface = unsafe extern "C" fn(&Str, &Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_QueryInterface: Option<_QueryInterface> = None;

/// Returns the path of the game's directory.
///
/// # Returns - (string):
/// A reference to a string where the game directory path will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameDirectory() -> Str {
    unsafe { __s2sdk_GetGameDirectory.expect("GetGameDirectory function was not found")() }
}
pub type _GetGameDirectory = unsafe extern "C" fn() -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameDirectory: Option<_GetGameDirectory> = None;

/// Returns the current map name.
///
/// # Returns - (string):
/// A reference to a string where the current map name will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetCurrentMap() -> Str {
    unsafe { __s2sdk_GetCurrentMap.expect("GetCurrentMap function was not found")() }
}
pub type _GetCurrentMap = unsafe extern "C" fn() -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetCurrentMap: Option<_GetCurrentMap> = None;

/// Returns whether a specified map is valid or not.
///
/// # Arguments
/// * `mapname` - (string): The name of the map to check for validity.
///
/// # Returns - (bool):
/// True if the map is valid, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsMapValid(mapname: &Str) -> bool {
    unsafe { __s2sdk_IsMapValid.expect("IsMapValid function was not found")(mapname) }
}
pub type _IsMapValid = unsafe extern "C" fn(&Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsMapValid: Option<_IsMapValid> = None;

/// Returns the game time based on the game tick.
///
/// # Returns - (float):
/// The current game time.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameTime() -> f32 {
    unsafe { __s2sdk_GetGameTime.expect("GetGameTime function was not found")() }
}
pub type _GetGameTime = unsafe extern "C" fn() -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameTime: Option<_GetGameTime> = None;

/// Returns the game's internal tick count.
///
/// # Returns - (int32):
/// The current tick count of the game.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameTickCount() -> i32 {
    unsafe { __s2sdk_GetGameTickCount.expect("GetGameTickCount function was not found")() }
}
pub type _GetGameTickCount = unsafe extern "C" fn() -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameTickCount: Option<_GetGameTickCount> = None;

/// Returns the time the game took processing the last frame.
///
/// # Returns - (float):
/// The frame time of the last processed frame.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameFrameTime() -> f32 {
    unsafe { __s2sdk_GetGameFrameTime.expect("GetGameFrameTime function was not found")() }
}
pub type _GetGameFrameTime = unsafe extern "C" fn() -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameFrameTime: Option<_GetGameFrameTime> = None;

/// Returns a high-precision time value for profiling the engine.
///
/// # Returns - (double):
/// A high-precision time value.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEngineTime() -> f64 {
    unsafe { __s2sdk_GetEngineTime.expect("GetEngineTime function was not found")() }
}
pub type _GetEngineTime = unsafe extern "C" fn() -> f64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEngineTime: Option<_GetEngineTime> = None;

/// Returns the maximum number of clients that can connect to the server.
///
/// # Returns - (int32):
/// The maximum client count, or -1 if global variables are not initialized.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetMaxClients() -> i32 {
    unsafe { __s2sdk_GetMaxClients.expect("GetMaxClients function was not found")() }
}
pub type _GetMaxClients = unsafe extern "C" fn() -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetMaxClients: Option<_GetMaxClients> = None;

/// Precaches a given file.
///
/// # Arguments
/// * `resource` - (string): The name of the resource to be precached.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Precache(resource: &Str) {
    unsafe { __s2sdk_Precache.expect("Precache function was not found")(resource) }
}
pub type _Precache = unsafe extern "C" fn(&Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Precache: Option<_Precache> = None;

/// Checks if a specified file is precached.
///
/// # Arguments
/// * `resource` - (string): The name of the file to check.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsPrecached(resource: &Str) -> bool {
    unsafe { __s2sdk_IsPrecached.expect("IsPrecached function was not found")(resource) }
}
pub type _IsPrecached = unsafe extern "C" fn(&Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsPrecached: Option<_IsPrecached> = None;

/// Returns a pointer to the Economy Item System.
///
/// # Returns - (ptr64):
/// A pointer to the Econ Item System.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEconItemSystem() -> usize {
    unsafe { __s2sdk_GetEconItemSystem.expect("GetEconItemSystem function was not found")() }
}
pub type _GetEconItemSystem = unsafe extern "C" fn() -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEconItemSystem: Option<_GetEconItemSystem> = None;

/// Checks if the server is currently paused.
///
/// # Returns - (bool):
/// True if the server is paused, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsServerPaused() -> bool {
    unsafe { __s2sdk_IsServerPaused.expect("IsServerPaused function was not found")() }
}
pub type _IsServerPaused = unsafe extern "C" fn() -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsServerPaused: Option<_IsServerPaused> = None;

/// Queues a task to be executed on the next frame.
///
/// # Arguments
/// * `callback` - (function): A callback function to be executed on the next frame.
/// * `userData` - (any[]): An array intended to hold user-related data, allowing for elements of any type.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn QueueTaskForNextFrame(callback: TaskCallback, userData: &Arr<Var>) {
    unsafe { __s2sdk_QueueTaskForNextFrame.expect("QueueTaskForNextFrame function was not found")(callback, userData) }
}
pub type _QueueTaskForNextFrame = unsafe extern "C" fn(TaskCallback, &Arr<Var>);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_QueueTaskForNextFrame: Option<_QueueTaskForNextFrame> = None;

/// Queues a task to be executed on the next world update.
///
/// # Arguments
/// * `callback` - (function): A callback function to be executed on the next world update.
/// * `userData` - (any[]): An array intended to hold user-related data, allowing for elements of any type.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn QueueTaskForNextWorldUpdate(callback: TaskCallback, userData: &Arr<Var>) {
    unsafe { __s2sdk_QueueTaskForNextWorldUpdate.expect("QueueTaskForNextWorldUpdate function was not found")(callback, userData) }
}
pub type _QueueTaskForNextWorldUpdate = unsafe extern "C" fn(TaskCallback, &Arr<Var>);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_QueueTaskForNextWorldUpdate: Option<_QueueTaskForNextWorldUpdate> = None;

/// Returns the duration of a specified sound.
///
/// # Arguments
/// * `name` - (string): The name of the sound to check.
///
/// # Returns - (float):
/// The duration of the sound in seconds.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetSoundDuration(name: &Str) -> f32 {
    unsafe { __s2sdk_GetSoundDuration.expect("GetSoundDuration function was not found")(name) }
}
pub type _GetSoundDuration = unsafe extern "C" fn(&Str) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetSoundDuration: Option<_GetSoundDuration> = None;

/// Emits a sound from a specified entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity that will emit the sound.
/// * `sound` - (string): The name of the sound to emit.
/// * `pitch` - (int32): The pitch of the sound.
/// * `volume` - (float): The volume of the sound.
/// * `delay` - (float): The delay before the sound is played.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn EmitSound(entityHandle: i32, sound: &Str, pitch: i32, volume: f32, delay: f32) {
    unsafe { __s2sdk_EmitSound.expect("EmitSound function was not found")(entityHandle, sound, pitch, volume, delay) }
}
pub type _EmitSound = unsafe extern "C" fn(i32, &Str, i32, f32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_EmitSound: Option<_EmitSound> = None;

/// Stops a sound from a specified entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity that will stop the sound.
/// * `sound` - (string): The name of the sound to stop.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn StopSound(entityHandle: i32, sound: &Str) {
    unsafe { __s2sdk_StopSound.expect("StopSound function was not found")(entityHandle, sound) }
}
pub type _StopSound = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_StopSound: Option<_StopSound> = None;

/// Emits a sound to one or more clients.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity that emits the sound.
/// * `playersSlot` - (int32[]): Player slot indices that will hear the sound.
/// * `sound` - (string): The name of the sound to emit.
/// * `volume` - (float): The volume of the sound.
/// * `pitch` - (float): The pitch of the sound.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn EmitSoundToClient(entityHandle: i32, playersSlot: &Arr<i32>, sound: &Str, volume: f32, pitch: f32) {
    unsafe { __s2sdk_EmitSoundToClient.expect("EmitSoundToClient function was not found")(entityHandle, playersSlot, sound, volume, pitch) }
}
pub type _EmitSoundToClient = unsafe extern "C" fn(i32, &Arr<i32>, &Str, f32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_EmitSoundToClient: Option<_EmitSoundToClient> = None;

