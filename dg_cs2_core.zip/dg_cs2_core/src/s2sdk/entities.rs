// Generated from s2sdk.pplugin (group: entities)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Returns the public network address of the host.
///
/// # Arguments
/// * `onlyBase` - (bool): If true, omits port, otherwise returning only the base address.
///
/// # Returns - (string):
/// A string representation of the public address.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetPublicAddress(onlyBase: bool) -> Str {
    unsafe { __s2sdk_GetPublicAddress.expect("GetPublicAddress function was not found")(onlyBase) }
}
pub type _GetPublicAddress = unsafe extern "C" fn(bool) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetPublicAddress: Option<_GetPublicAddress> = None;

/// Returns the local network address of the host.
///
/// # Arguments
/// * `onlyBase` - (bool): If true, omits port, otherwise returning only the base address.
///
/// # Returns - (string):
/// A string representation of the local address.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetLocalAddress(onlyBase: bool) -> Str {
    unsafe { __s2sdk_GetLocalAddress.expect("GetLocalAddress function was not found")(onlyBase) }
}
pub type _GetLocalAddress = unsafe extern "C" fn(bool) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetLocalAddress: Option<_GetLocalAddress> = None;

/// Converts an entity index into an entity pointer.
///
/// # Arguments
/// * `entityIndex` - (int32): The index of the entity to convert.
///
/// # Returns - (ptr64):
/// A pointer to the entity instance, or nullptr if the entity does not exist.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn EntIndexToEntPointer(entityIndex: i32) -> usize {
    unsafe { __s2sdk_EntIndexToEntPointer.expect("EntIndexToEntPointer function was not found")(entityIndex) }
}
pub type _EntIndexToEntPointer = unsafe extern "C" fn(i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_EntIndexToEntPointer: Option<_EntIndexToEntPointer> = None;

/// Retrieves the entity index from an entity pointer.
///
/// # Arguments
/// * `entity` - (ptr64): A pointer to the entity whose index is to be retrieved.
///
/// # Returns - (int32):
/// The index of the entity, or -1 if the entity is nullptr.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn EntPointerToEntIndex(entity: usize) -> i32 {
    unsafe { __s2sdk_EntPointerToEntIndex.expect("EntPointerToEntIndex function was not found")(entity) }
}
pub type _EntPointerToEntIndex = unsafe extern "C" fn(usize) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_EntPointerToEntIndex: Option<_EntPointerToEntIndex> = None;

/// Converts an entity pointer into an entity handle.
///
/// # Arguments
/// * `entity` - (ptr64): A pointer to the entity to convert.
///
/// # Returns - (int32):
/// The entity handle as an integer, or INVALID_EHANDLE_INDEX if the entity is nullptr.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn EntPointerToEntHandle(entity: usize) -> i32 {
    unsafe { __s2sdk_EntPointerToEntHandle.expect("EntPointerToEntHandle function was not found")(entity) }
}
pub type _EntPointerToEntHandle = unsafe extern "C" fn(usize) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_EntPointerToEntHandle: Option<_EntPointerToEntHandle> = None;

/// Retrieves the entity pointer from an entity handle.
///
/// # Arguments
/// * `entityHandle` - (int32): The entity handle to convert.
///
/// # Returns - (ptr64):
/// A pointer to the entity instance, or nullptr if the handle is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn EntHandleToEntPointer(entityHandle: i32) -> usize {
    unsafe { __s2sdk_EntHandleToEntPointer.expect("EntHandleToEntPointer function was not found")(entityHandle) }
}
pub type _EntHandleToEntPointer = unsafe extern "C" fn(i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_EntHandleToEntPointer: Option<_EntHandleToEntPointer> = None;

/// Converts an entity index into an entity handle.
///
/// # Arguments
/// * `entityIndex` - (int32): The index of the entity to convert.
///
/// # Returns - (int32):
/// The entity handle as an integer, or -1 if the entity index is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn EntIndexToEntHandle(entityIndex: i32) -> i32 {
    unsafe { __s2sdk_EntIndexToEntHandle.expect("EntIndexToEntHandle function was not found")(entityIndex) }
}
pub type _EntIndexToEntHandle = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_EntIndexToEntHandle: Option<_EntIndexToEntHandle> = None;

/// Retrieves the entity index from an entity handle.
///
/// # Arguments
/// * `entityHandle` - (int32): The entity handle from which to retrieve the index.
///
/// # Returns - (int32):
/// The index of the entity, or -1 if the handle is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn EntHandleToEntIndex(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_EntHandleToEntIndex.expect("EntHandleToEntIndex function was not found")(entityHandle) }
}
pub type _EntHandleToEntIndex = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_EntHandleToEntIndex: Option<_EntHandleToEntIndex> = None;

/// Checks if the provided entity handle is valid.
///
/// # Arguments
/// * `entityHandle` - (int32): The entity handle to check.
///
/// # Returns - (bool):
/// True if the entity handle is valid, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsValidEntHandle(entityHandle: i32) -> bool {
    unsafe { __s2sdk_IsValidEntHandle.expect("IsValidEntHandle function was not found")(entityHandle) }
}
pub type _IsValidEntHandle = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsValidEntHandle: Option<_IsValidEntHandle> = None;

/// Checks if the provided entity pointer is valid.
///
/// # Arguments
/// * `entity` - (ptr64): The entity pointer to check.
///
/// # Returns - (bool):
/// True if the entity pointer is valid, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsValidEntPointer(entity: usize) -> bool {
    unsafe { __s2sdk_IsValidEntPointer.expect("IsValidEntPointer function was not found")(entity) }
}
pub type _IsValidEntPointer = unsafe extern "C" fn(usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsValidEntPointer: Option<_IsValidEntPointer> = None;

/// Retrieves the pointer to the first active entity.
///
/// # Returns - (int32):
/// A handle to the first active entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetFirstActiveEntity() -> i32 {
    unsafe { __s2sdk_GetFirstActiveEntity.expect("GetFirstActiveEntity function was not found")() }
}
pub type _GetFirstActiveEntity = unsafe extern "C" fn() -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetFirstActiveEntity: Option<_GetFirstActiveEntity> = None;

/// Retrieves the previous active entity.
///
/// # Arguments
/// * `entityHandle` - (int32)
///
/// # Returns - (int32):
/// Handle to the previous entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetPrevActiveEntity(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetPrevActiveEntity.expect("GetPrevActiveEntity function was not found")(entityHandle) }
}
pub type _GetPrevActiveEntity = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetPrevActiveEntity: Option<_GetPrevActiveEntity> = None;

/// Retrieves the next active entity.
///
/// # Arguments
/// * `entityHandle` - (int32)
///
/// # Returns - (int32):
/// Handle to the next entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetNextActiveEntity(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetNextActiveEntity.expect("GetNextActiveEntity function was not found")(entityHandle) }
}
pub type _GetNextActiveEntity = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetNextActiveEntity: Option<_GetNextActiveEntity> = None;

/// Adds an entity output hook on a specified entity class name.
///
/// # Arguments
/// * `classname` - (string): The class name of the entity to hook the output for.
/// * `output` - (string): The output event name to hook.
/// * `callback` - (function): The callback function to invoke when the output is fired.
/// * `type_` - (uint8): Whether the hook was in post mode (after processing) or pre mode (before processing).
///
/// # Returns - (bool):
/// True if the hook was successfully added, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn HookEntityOutput(classname: &Str, output: &Str, callback: HookEntityOutputCallback, type_: HookMode) -> bool {
    unsafe { __s2sdk_HookEntityOutput.expect("HookEntityOutput function was not found")(classname, output, callback, type_) }
}
pub type _HookEntityOutput = unsafe extern "C" fn(&Str, &Str, HookEntityOutputCallback, HookMode) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_HookEntityOutput: Option<_HookEntityOutput> = None;

/// Removes an entity output hook.
///
/// # Arguments
/// * `classname` - (string): The class name of the entity from which to unhook the output.
/// * `output` - (string): The output event name to unhook.
/// * `callback` - (function): The callback function that was previously hooked.
/// * `type_` - (uint8): Whether the hook was in post mode (after processing) or pre mode (before processing).
///
/// # Returns - (bool):
/// True if the hook was successfully removed, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn UnhookEntityOutput(classname: &Str, output: &Str, callback: HookEntityOutputCallback, type_: HookMode) -> bool {
    unsafe { __s2sdk_UnhookEntityOutput.expect("UnhookEntityOutput function was not found")(classname, output, callback, type_) }
}
pub type _UnhookEntityOutput = unsafe extern "C" fn(&Str, &Str, HookEntityOutputCallback, HookMode) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_UnhookEntityOutput: Option<_UnhookEntityOutput> = None;

/// Finds an entity by classname with iteration.
///
/// # Arguments
/// * `startFrom` - (int32): The handle of the entity to start from, or INVALID_EHANDLE_INDEX to start fresh.
/// * `classname` - (string): The class name to search for.
///
/// # Returns - (int32):
/// The handle of the found entity, or INVALID_EHANDLE_INDEX if none found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FindEntityByClassname(startFrom: i32, classname: &Str) -> i32 {
    unsafe { __s2sdk_FindEntityByClassname.expect("FindEntityByClassname function was not found")(startFrom, classname) }
}
pub type _FindEntityByClassname = unsafe extern "C" fn(i32, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FindEntityByClassname: Option<_FindEntityByClassname> = None;

/// Finds the nearest entity by classname to a point.
///
/// # Arguments
/// * `startFrom` - (int32): The handle of the entity to start from, or INVALID_EHANDLE_INDEX to start fresh.
/// * `classname` - (string): The class name to search for.
/// * `origin` - (vec3): The center point to search around.
/// * `maxRadius` - (float): Maximum search radius.
///
/// # Returns - (int32):
/// The handle of the found entity, or INVALID_EHANDLE_INDEX if none found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FindEntityByClassnameNearest(startFrom: i32, classname: &Str, origin: &Vec3, maxRadius: f32) -> i32 {
    unsafe { __s2sdk_FindEntityByClassnameNearest.expect("FindEntityByClassnameNearest function was not found")(startFrom, classname, origin, maxRadius) }
}
pub type _FindEntityByClassnameNearest = unsafe extern "C" fn(i32, &Str, &Vec3, f32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FindEntityByClassnameNearest: Option<_FindEntityByClassnameNearest> = None;

/// Finds an entity by classname within a radius with iteration.
///
/// # Arguments
/// * `startFrom` - (int32): The handle of the entity to start from, or INVALID_EHANDLE_INDEX to start fresh.
/// * `classname` - (string): The class name to search for.
/// * `origin` - (vec3): The center of the search sphere.
/// * `radius` - (float): The search radius.
///
/// # Returns - (int32):
/// The handle of the found entity, or INVALID_EHANDLE_INDEX if none found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FindEntityByClassnameWithin(startFrom: i32, classname: &Str, origin: &Vec3, radius: f32) -> i32 {
    unsafe { __s2sdk_FindEntityByClassnameWithin.expect("FindEntityByClassnameWithin function was not found")(startFrom, classname, origin, radius) }
}
pub type _FindEntityByClassnameWithin = unsafe extern "C" fn(i32, &Str, &Vec3, f32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FindEntityByClassnameWithin: Option<_FindEntityByClassnameWithin> = None;

/// Finds an entity by name with iteration.
///
/// # Arguments
/// * `startFrom` - (int32): The handle of the entity to start from, or INVALID_EHANDLE_INDEX to start fresh.
/// * `name` - (string): The targetname to search for.
///
/// # Returns - (int32):
/// The handle of the found entity, or INVALID_EHANDLE_INDEX if none found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FindEntityByName(startFrom: i32, name: &Str) -> i32 {
    unsafe { __s2sdk_FindEntityByName.expect("FindEntityByName function was not found")(startFrom, name) }
}
pub type _FindEntityByName = unsafe extern "C" fn(i32, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FindEntityByName: Option<_FindEntityByName> = None;

/// Finds the nearest entity by name to a point.
///
/// # Arguments
/// * `name` - (string): The targetname to search for.
/// * `origin` - (vec3): The point to search around.
/// * `maxRadius` - (float): Maximum search radius.
///
/// # Returns - (int32):
/// The handle of the nearest entity, or INVALID_EHANDLE_INDEX if none found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FindEntityByNameNearest(name: &Str, origin: &Vec3, maxRadius: f32) -> i32 {
    unsafe { __s2sdk_FindEntityByNameNearest.expect("FindEntityByNameNearest function was not found")(name, origin, maxRadius) }
}
pub type _FindEntityByNameNearest = unsafe extern "C" fn(&Str, &Vec3, f32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FindEntityByNameNearest: Option<_FindEntityByNameNearest> = None;

/// Finds an entity by name within a radius with iteration.
///
/// # Arguments
/// * `startFrom` - (int32): The handle of the entity to start from, or INVALID_EHANDLE_INDEX to start fresh.
/// * `name` - (string): The targetname to search for.
/// * `origin` - (vec3): The center of the search sphere.
/// * `radius` - (float): The search radius.
///
/// # Returns - (int32):
/// The handle of the found entity, or INVALID_EHANDLE_INDEX if none found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FindEntityByNameWithin(startFrom: i32, name: &Str, origin: &Vec3, radius: f32) -> i32 {
    unsafe { __s2sdk_FindEntityByNameWithin.expect("FindEntityByNameWithin function was not found")(startFrom, name, origin, radius) }
}
pub type _FindEntityByNameWithin = unsafe extern "C" fn(i32, &Str, &Vec3, f32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FindEntityByNameWithin: Option<_FindEntityByNameWithin> = None;

/// Finds an entity by targetname with iteration.
///
/// # Arguments
/// * `startFrom` - (int32): The handle of the entity to start from, or INVALID_EHANDLE_INDEX to start fresh.
/// * `name` - (string): The targetname to search for.
///
/// # Returns - (int32):
/// The handle of the found entity, or INVALID_EHANDLE_INDEX if none found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FindEntityByTarget(startFrom: i32, name: &Str) -> i32 {
    unsafe { __s2sdk_FindEntityByTarget.expect("FindEntityByTarget function was not found")(startFrom, name) }
}
pub type _FindEntityByTarget = unsafe extern "C" fn(i32, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FindEntityByTarget: Option<_FindEntityByTarget> = None;

/// Finds an entity within a sphere with iteration.
///
/// # Arguments
/// * `startFrom` - (int32): The handle of the entity to start from, or INVALID_EHANDLE_INDEX to start fresh.
/// * `origin` - (vec3): The center of the search sphere.
/// * `radius` - (float): The search radius.
///
/// # Returns - (int32):
/// The handle of the found entity, or INVALID_EHANDLE_INDEX if none found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FindEntityInSphere(startFrom: i32, origin: &Vec3, radius: f32) -> i32 {
    unsafe { __s2sdk_FindEntityInSphere.expect("FindEntityInSphere function was not found")(startFrom, origin, radius) }
}
pub type _FindEntityInSphere = unsafe extern "C" fn(i32, &Vec3, f32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FindEntityInSphere: Option<_FindEntityInSphere> = None;

/// Creates an entity by classname.
///
/// # Arguments
/// * `className` - (string): The class name of the entity to create.
///
/// # Returns - (int32):
/// The handle of the created entity, or INVALID_EHANDLE_INDEX if creation failed.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SpawnEntityByName(className: &Str) -> i32 {
    unsafe { __s2sdk_SpawnEntityByName.expect("SpawnEntityByName function was not found")(className) }
}
pub type _SpawnEntityByName = unsafe extern "C" fn(&Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SpawnEntityByName: Option<_SpawnEntityByName> = None;

/// Creates an entity by string name but does not spawn it.
///
/// # Arguments
/// * `className` - (string): The class name of the entity to create.
///
/// # Returns - (int32):
/// The entity handle of the created entity, or INVALID_EHANDLE_INDEX if the entity could not be created.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CreateEntityByName(className: &Str) -> i32 {
    unsafe { __s2sdk_CreateEntityByName.expect("CreateEntityByName function was not found")(className) }
}
pub type _CreateEntityByName = unsafe extern "C" fn(&Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CreateEntityByName: Option<_CreateEntityByName> = None;

/// Spawns an entity into the game.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to spawn.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DispatchSpawn(entityHandle: i32) {
    unsafe { __s2sdk_DispatchSpawn.expect("DispatchSpawn function was not found")(entityHandle) }
}
pub type _DispatchSpawn = unsafe extern "C" fn(i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DispatchSpawn: Option<_DispatchSpawn> = None;

/// Spawns an entity into the game with key-value properties.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to spawn.
/// * `keys` - (string[]): A vector of keys representing the property names to set on the entity.
/// * `values` - (any[]): A vector of values corresponding to the keys, representing the property values to set on the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DispatchSpawn2(entityHandle: i32, keys: &Arr<Str>, values: &Arr<Var>) {
    unsafe { __s2sdk_DispatchSpawn2.expect("DispatchSpawn2 function was not found")(entityHandle, keys, values) }
}
pub type _DispatchSpawn2 = unsafe extern "C" fn(i32, &Arr<Str>, &Arr<Var>);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DispatchSpawn2: Option<_DispatchSpawn2> = None;

/// Marks an entity for deletion.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to be deleted.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RemoveEntity(entityHandle: i32) {
    unsafe { __s2sdk_RemoveEntity.expect("RemoveEntity function was not found")(entityHandle) }
}
pub type _RemoveEntity = unsafe extern "C" fn(i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RemoveEntity: Option<_RemoveEntity> = None;

/// Checks if an entity is a player controller.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
///
/// # Returns - (bool):
/// True if the entity is a player controller, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsEntityPlayerController(entityHandle: i32) -> bool {
    unsafe { __s2sdk_IsEntityPlayerController.expect("IsEntityPlayerController function was not found")(entityHandle) }
}
pub type _IsEntityPlayerController = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsEntityPlayerController: Option<_IsEntityPlayerController> = None;

/// Checks if an entity is a player pawn.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
///
/// # Returns - (bool):
/// True if the entity is a player pawn, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsEntityPlayerPawn(entityHandle: i32) -> bool {
    unsafe { __s2sdk_IsEntityPlayerPawn.expect("IsEntityPlayerPawn function was not found")(entityHandle) }
}
pub type _IsEntityPlayerPawn = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsEntityPlayerPawn: Option<_IsEntityPlayerPawn> = None;

/// Retrieves the class name of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose class name is to be retrieved.
///
/// # Returns - (string):
/// A string where the class name will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityClassname(entityHandle: i32) -> Str {
    unsafe { __s2sdk_GetEntityClassname.expect("GetEntityClassname function was not found")(entityHandle) }
}
pub type _GetEntityClassname = unsafe extern "C" fn(i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityClassname: Option<_GetEntityClassname> = None;

/// Retrieves the name of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose name is to be retrieved.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityName(entityHandle: i32) -> Str {
    unsafe { __s2sdk_GetEntityName.expect("GetEntityName function was not found")(entityHandle) }
}
pub type _GetEntityName = unsafe extern "C" fn(i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityName: Option<_GetEntityName> = None;

/// Sets the name of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose name is to be set.
/// * `name` - (string): The new name to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityName(entityHandle: i32, name: &Str) {
    unsafe { __s2sdk_SetEntityName.expect("SetEntityName function was not found")(entityHandle, name) }
}
pub type _SetEntityName = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityName: Option<_SetEntityName> = None;

/// Retrieves the movement type of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose movement type is to be retrieved.
///
/// # Returns - (int32):
/// The movement type of the entity, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityMoveType(entityHandle: i32) -> MoveType {
    unsafe { __s2sdk_GetEntityMoveType.expect("GetEntityMoveType function was not found")(entityHandle) }
}
pub type _GetEntityMoveType = unsafe extern "C" fn(i32) -> MoveType;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityMoveType: Option<_GetEntityMoveType> = None;

/// Sets the movement type of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose movement type is to be set.
/// * `moveType` - (int32): The new movement type to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityMoveType(entityHandle: i32, moveType: MoveType) {
    unsafe { __s2sdk_SetEntityMoveType.expect("SetEntityMoveType function was not found")(entityHandle, moveType) }
}
pub type _SetEntityMoveType = unsafe extern "C" fn(i32, MoveType);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityMoveType: Option<_SetEntityMoveType> = None;

/// Retrieves the gravity scale of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose gravity scale is to be retrieved.
///
/// # Returns - (float):
/// The gravity scale of the entity, or 0.0f if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityGravity(entityHandle: i32) -> f32 {
    unsafe { __s2sdk_GetEntityGravity.expect("GetEntityGravity function was not found")(entityHandle) }
}
pub type _GetEntityGravity = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityGravity: Option<_GetEntityGravity> = None;

/// Sets the gravity scale of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose gravity scale is to be set.
/// * `gravity` - (float): The new gravity scale to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityGravity(entityHandle: i32, gravity: f32) {
    unsafe { __s2sdk_SetEntityGravity.expect("SetEntityGravity function was not found")(entityHandle, gravity) }
}
pub type _SetEntityGravity = unsafe extern "C" fn(i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityGravity: Option<_SetEntityGravity> = None;

/// Retrieves the flags of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose flags are to be retrieved.
///
/// # Returns - (int32):
/// The flags of the entity, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityFlags(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetEntityFlags.expect("GetEntityFlags function was not found")(entityHandle) }
}
pub type _GetEntityFlags = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityFlags: Option<_GetEntityFlags> = None;

/// Sets the flags of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose flags are to be set.
/// * `flags` - (int32): The new flags to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityFlags(entityHandle: i32, flags: i32) {
    unsafe { __s2sdk_SetEntityFlags.expect("SetEntityFlags function was not found")(entityHandle, flags) }
}
pub type _SetEntityFlags = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityFlags: Option<_SetEntityFlags> = None;

/// Retrieves the render color of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose render color is to be retrieved.
///
/// # Returns - (vec4):
/// The raw color value of the entity's render color, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityRenderColor(entityHandle: i32) -> Vec4 {
    unsafe { __s2sdk_GetEntityRenderColor.expect("GetEntityRenderColor function was not found")(entityHandle) }
}
pub type _GetEntityRenderColor = unsafe extern "C" fn(i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityRenderColor: Option<_GetEntityRenderColor> = None;

/// Sets the render color of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose render color is to be set.
/// * `color` - (vec4): The new raw color value to set for the entity's render color.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityRenderColor(entityHandle: i32, color: &Vec4) {
    unsafe { __s2sdk_SetEntityRenderColor.expect("SetEntityRenderColor function was not found")(entityHandle, color) }
}
pub type _SetEntityRenderColor = unsafe extern "C" fn(i32, &Vec4);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityRenderColor: Option<_SetEntityRenderColor> = None;

/// Retrieves the render mode of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose render mode is to be retrieved.
///
/// # Returns - (uint8):
/// The render mode of the entity, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityRenderMode(entityHandle: i32) -> RenderMode {
    unsafe { __s2sdk_GetEntityRenderMode.expect("GetEntityRenderMode function was not found")(entityHandle) }
}
pub type _GetEntityRenderMode = unsafe extern "C" fn(i32) -> RenderMode;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityRenderMode: Option<_GetEntityRenderMode> = None;

/// Sets the render mode of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose render mode is to be set.
/// * `renderMode` - (uint8): The new render mode to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityRenderMode(entityHandle: i32, renderMode: RenderMode) {
    unsafe { __s2sdk_SetEntityRenderMode.expect("SetEntityRenderMode function was not found")(entityHandle, renderMode) }
}
pub type _SetEntityRenderMode = unsafe extern "C" fn(i32, RenderMode);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityRenderMode: Option<_SetEntityRenderMode> = None;

/// Retrieves the mass of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose mass is to be retrieved.
///
/// # Returns - (int32):
/// The mass of the entity, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityMass(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetEntityMass.expect("GetEntityMass function was not found")(entityHandle) }
}
pub type _GetEntityMass = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityMass: Option<_GetEntityMass> = None;

/// Sets the mass of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose mass is to be set.
/// * `mass` - (int32): The new mass value to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityMass(entityHandle: i32, mass: i32) {
    unsafe { __s2sdk_SetEntityMass.expect("SetEntityMass function was not found")(entityHandle, mass) }
}
pub type _SetEntityMass = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityMass: Option<_SetEntityMass> = None;

/// Retrieves the friction of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose friction is to be retrieved.
///
/// # Returns - (float):
/// The friction of the entity, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityFriction(entityHandle: i32) -> f32 {
    unsafe { __s2sdk_GetEntityFriction.expect("GetEntityFriction function was not found")(entityHandle) }
}
pub type _GetEntityFriction = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityFriction: Option<_GetEntityFriction> = None;

/// Sets the friction of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose friction is to be set.
/// * `friction` - (float): The new friction value to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityFriction(entityHandle: i32, friction: f32) {
    unsafe { __s2sdk_SetEntityFriction.expect("SetEntityFriction function was not found")(entityHandle, friction) }
}
pub type _SetEntityFriction = unsafe extern "C" fn(i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityFriction: Option<_SetEntityFriction> = None;

/// Retrieves the health of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose health is to be retrieved.
///
/// # Returns - (int32):
/// The health of the entity, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityHealth(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetEntityHealth.expect("GetEntityHealth function was not found")(entityHandle) }
}
pub type _GetEntityHealth = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityHealth: Option<_GetEntityHealth> = None;

/// Sets the health of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose health is to be set.
/// * `health` - (int32): The new health value to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityHealth(entityHandle: i32, health: i32) {
    unsafe { __s2sdk_SetEntityHealth.expect("SetEntityHealth function was not found")(entityHandle, health) }
}
pub type _SetEntityHealth = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityHealth: Option<_SetEntityHealth> = None;

/// Retrieves the max health of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose max health is to be retrieved.
///
/// # Returns - (int32):
/// The max health of the entity, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityMaxHealth(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetEntityMaxHealth.expect("GetEntityMaxHealth function was not found")(entityHandle) }
}
pub type _GetEntityMaxHealth = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityMaxHealth: Option<_GetEntityMaxHealth> = None;

/// Sets the max health of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose max health is to be set.
/// * `maxHealth` - (int32): The new max health value to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityMaxHealth(entityHandle: i32, maxHealth: i32) {
    unsafe { __s2sdk_SetEntityMaxHealth.expect("SetEntityMaxHealth function was not found")(entityHandle, maxHealth) }
}
pub type _SetEntityMaxHealth = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityMaxHealth: Option<_SetEntityMaxHealth> = None;

/// Retrieves the team number of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose team number is to be retrieved.
///
/// # Returns - (int32):
/// The team number of the entity, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityTeam(entityHandle: i32) -> CSTeam {
    unsafe { __s2sdk_GetEntityTeam.expect("GetEntityTeam function was not found")(entityHandle) }
}
pub type _GetEntityTeam = unsafe extern "C" fn(i32) -> CSTeam;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityTeam: Option<_GetEntityTeam> = None;

/// Sets the team number of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose team number is to be set.
/// * `team` - (int32): The new team number to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityTeam(entityHandle: i32, team: CSTeam) {
    unsafe { __s2sdk_SetEntityTeam.expect("SetEntityTeam function was not found")(entityHandle, team) }
}
pub type _SetEntityTeam = unsafe extern "C" fn(i32, CSTeam);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityTeam: Option<_SetEntityTeam> = None;

/// Retrieves the owner of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose owner is to be retrieved.
///
/// # Returns - (int32):
/// The handle of the owner entity, or INVALID_EHANDLE_INDEX if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityOwner(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetEntityOwner.expect("GetEntityOwner function was not found")(entityHandle) }
}
pub type _GetEntityOwner = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityOwner: Option<_GetEntityOwner> = None;

/// Sets the owner of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose owner is to be set.
/// * `ownerHandle` - (int32): The handle of the new owner entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityOwner(entityHandle: i32, ownerHandle: i32) {
    unsafe { __s2sdk_SetEntityOwner.expect("SetEntityOwner function was not found")(entityHandle, ownerHandle) }
}
pub type _SetEntityOwner = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityOwner: Option<_SetEntityOwner> = None;

/// Retrieves the parent of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose parent is to be retrieved.
///
/// # Returns - (int32):
/// The handle of the parent entity, or INVALID_EHANDLE_INDEX if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityParent(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetEntityParent.expect("GetEntityParent function was not found")(entityHandle) }
}
pub type _GetEntityParent = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityParent: Option<_GetEntityParent> = None;

/// Sets the parent of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose parent is to be set.
/// * `parentHandle` - (int32): The handle of the new parent entity. (Can be invalid to clean parent)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityParent(entityHandle: i32, parentHandle: i32) {
    unsafe { __s2sdk_SetEntityParent.expect("SetEntityParent function was not found")(entityHandle, parentHandle) }
}
pub type _SetEntityParent = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityParent: Option<_SetEntityParent> = None;

/// Sets the parent of an entity to attachment by name.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose parent is to be set.
/// * `parentHandle` - (int32): The handle of the new parent entity.
/// * `attachmentName` - (string): The name of the entity's attachment.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityParentAttachment(entityHandle: i32, parentHandle: i32, attachmentName: &Str) {
    unsafe { __s2sdk_SetEntityParentAttachment.expect("SetEntityParentAttachment function was not found")(entityHandle, parentHandle, attachmentName) }
}
pub type _SetEntityParentAttachment = unsafe extern "C" fn(i32, i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityParentAttachment: Option<_SetEntityParentAttachment> = None;

/// Retrieves the absolute origin of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose absolute origin is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the absolute origin will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityAbsOrigin(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityAbsOrigin.expect("GetEntityAbsOrigin function was not found")(entityHandle) }
}
pub type _GetEntityAbsOrigin = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityAbsOrigin: Option<_GetEntityAbsOrigin> = None;

/// Sets the absolute origin of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose absolute origin is to be set.
/// * `origin` - (vec3): The new absolute origin to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityAbsOrigin(entityHandle: i32, origin: &Vec3) {
    unsafe { __s2sdk_SetEntityAbsOrigin.expect("SetEntityAbsOrigin function was not found")(entityHandle, origin) }
}
pub type _SetEntityAbsOrigin = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityAbsOrigin: Option<_SetEntityAbsOrigin> = None;

/// Retrieves the absolute scale of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose absolute scale is to be retrieved.
///
/// # Returns - (float):
/// A vector where the absolute scale will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityAbsScale(entityHandle: i32) -> f32 {
    unsafe { __s2sdk_GetEntityAbsScale.expect("GetEntityAbsScale function was not found")(entityHandle) }
}
pub type _GetEntityAbsScale = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityAbsScale: Option<_GetEntityAbsScale> = None;

/// Sets the absolute scale of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose absolute scale is to be set.
/// * `scale` - (float): The new absolute scale to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityAbsScale(entityHandle: i32, scale: f32) {
    unsafe { __s2sdk_SetEntityAbsScale.expect("SetEntityAbsScale function was not found")(entityHandle, scale) }
}
pub type _SetEntityAbsScale = unsafe extern "C" fn(i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityAbsScale: Option<_SetEntityAbsScale> = None;

/// Retrieves the angular rotation of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose angular rotation is to be retrieved.
///
/// # Returns - (vec3):
/// A QAngle where the angular rotation will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityAbsAngles(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityAbsAngles.expect("GetEntityAbsAngles function was not found")(entityHandle) }
}
pub type _GetEntityAbsAngles = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityAbsAngles: Option<_GetEntityAbsAngles> = None;

/// Sets the angular rotation of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose angular rotation is to be set.
/// * `angle` - (vec3): The new angular rotation to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityAbsAngles(entityHandle: i32, angle: &Vec3) {
    unsafe { __s2sdk_SetEntityAbsAngles.expect("SetEntityAbsAngles function was not found")(entityHandle, angle) }
}
pub type _SetEntityAbsAngles = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityAbsAngles: Option<_SetEntityAbsAngles> = None;

/// Retrieves the local origin of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose local origin is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the local origin will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityLocalOrigin(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityLocalOrigin.expect("GetEntityLocalOrigin function was not found")(entityHandle) }
}
pub type _GetEntityLocalOrigin = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityLocalOrigin: Option<_GetEntityLocalOrigin> = None;

/// Sets the local origin of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose local origin is to be set.
/// * `origin` - (vec3): The new local origin to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityLocalOrigin(entityHandle: i32, origin: &Vec3) {
    unsafe { __s2sdk_SetEntityLocalOrigin.expect("SetEntityLocalOrigin function was not found")(entityHandle, origin) }
}
pub type _SetEntityLocalOrigin = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityLocalOrigin: Option<_SetEntityLocalOrigin> = None;

/// Retrieves the local scale of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose local scale is to be retrieved.
///
/// # Returns - (float):
/// A vector where the local scale will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityLocalScale(entityHandle: i32) -> f32 {
    unsafe { __s2sdk_GetEntityLocalScale.expect("GetEntityLocalScale function was not found")(entityHandle) }
}
pub type _GetEntityLocalScale = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityLocalScale: Option<_GetEntityLocalScale> = None;

/// Sets the local scale of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose local scale is to be set.
/// * `scale` - (float): The new local scale to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityLocalScale(entityHandle: i32, scale: f32) {
    unsafe { __s2sdk_SetEntityLocalScale.expect("SetEntityLocalScale function was not found")(entityHandle, scale) }
}
pub type _SetEntityLocalScale = unsafe extern "C" fn(i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityLocalScale: Option<_SetEntityLocalScale> = None;

/// Retrieves the angular rotation of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose angular rotation is to be retrieved.
///
/// # Returns - (vec3):
/// A QAngle where the angular rotation will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityLocalAngles(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityLocalAngles.expect("GetEntityLocalAngles function was not found")(entityHandle) }
}
pub type _GetEntityLocalAngles = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityLocalAngles: Option<_GetEntityLocalAngles> = None;

/// Sets the angular rotation of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose angular rotation is to be set.
/// * `angle` - (vec3): The new angular rotation to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityLocalAngles(entityHandle: i32, angle: &Vec3) {
    unsafe { __s2sdk_SetEntityLocalAngles.expect("SetEntityLocalAngles function was not found")(entityHandle, angle) }
}
pub type _SetEntityLocalAngles = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityLocalAngles: Option<_SetEntityLocalAngles> = None;

/// Retrieves the absolute velocity of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose absolute velocity is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the absolute velocity will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityAbsVelocity(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityAbsVelocity.expect("GetEntityAbsVelocity function was not found")(entityHandle) }
}
pub type _GetEntityAbsVelocity = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityAbsVelocity: Option<_GetEntityAbsVelocity> = None;

/// Sets the absolute velocity of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose absolute velocity is to be set.
/// * `velocity` - (vec3): The new absolute velocity to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityAbsVelocity(entityHandle: i32, velocity: &Vec3) {
    unsafe { __s2sdk_SetEntityAbsVelocity.expect("SetEntityAbsVelocity function was not found")(entityHandle, velocity) }
}
pub type _SetEntityAbsVelocity = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityAbsVelocity: Option<_SetEntityAbsVelocity> = None;

/// Retrieves the base velocity of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose base velocity is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the base velocity will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityBaseVelocity(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityBaseVelocity.expect("GetEntityBaseVelocity function was not found")(entityHandle) }
}
pub type _GetEntityBaseVelocity = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityBaseVelocity: Option<_GetEntityBaseVelocity> = None;

/// Retrieves the local angular velocity of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose local angular velocity is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the local angular velocity will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityLocalAngVelocity(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityLocalAngVelocity.expect("GetEntityLocalAngVelocity function was not found")(entityHandle) }
}
pub type _GetEntityLocalAngVelocity = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityLocalAngVelocity: Option<_GetEntityLocalAngVelocity> = None;

/// Retrieves the angular velocity of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose angular velocity is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the angular velocity will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityAngVelocity(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityAngVelocity.expect("GetEntityAngVelocity function was not found")(entityHandle) }
}
pub type _GetEntityAngVelocity = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityAngVelocity: Option<_GetEntityAngVelocity> = None;

/// Sets the angular velocity of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose angular velocity is to be set.
/// * `velocity` - (vec3): The new angular velocity to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityAngVelocity(entityHandle: i32, velocity: &Vec3) {
    unsafe { __s2sdk_SetEntityAngVelocity.expect("SetEntityAngVelocity function was not found")(entityHandle, velocity) }
}
pub type _SetEntityAngVelocity = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityAngVelocity: Option<_SetEntityAngVelocity> = None;

/// Retrieves the local velocity of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose local velocity is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the local velocity will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityLocalVelocity(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityLocalVelocity.expect("GetEntityLocalVelocity function was not found")(entityHandle) }
}
pub type _GetEntityLocalVelocity = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityLocalVelocity: Option<_GetEntityLocalVelocity> = None;

/// Retrieves the angular rotation of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose angular rotation is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the angular rotation will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityAngRotation(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityAngRotation.expect("GetEntityAngRotation function was not found")(entityHandle) }
}
pub type _GetEntityAngRotation = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityAngRotation: Option<_GetEntityAngRotation> = None;

/// Sets the angular rotation of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose angular rotation is to be set.
/// * `rotation` - (vec3): The new angular rotation to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityAngRotation(entityHandle: i32, rotation: &Vec3) {
    unsafe { __s2sdk_SetEntityAngRotation.expect("SetEntityAngRotation function was not found")(entityHandle, rotation) }
}
pub type _SetEntityAngRotation = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityAngRotation: Option<_SetEntityAngRotation> = None;

/// Returns the input Vector transformed from entity to world space.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity
/// * `point` - (vec3): Point in entity local space to transform
///
/// # Returns - (vec3):
/// The point transformed to world space coordinates
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TransformPointEntityToWorld(entityHandle: i32, point: &Vec3) -> Vec3 {
    unsafe { __s2sdk_TransformPointEntityToWorld.expect("TransformPointEntityToWorld function was not found")(entityHandle, point) }
}
pub type _TransformPointEntityToWorld = unsafe extern "C" fn(i32, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TransformPointEntityToWorld: Option<_TransformPointEntityToWorld> = None;

/// Returns the input Vector transformed from world to entity space.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity
/// * `point` - (vec3): Point in world space to transform
///
/// # Returns - (vec3):
/// The point transformed to entity local space coordinates
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TransformPointWorldToEntity(entityHandle: i32, point: &Vec3) -> Vec3 {
    unsafe { __s2sdk_TransformPointWorldToEntity.expect("TransformPointWorldToEntity function was not found")(entityHandle, point) }
}
pub type _TransformPointWorldToEntity = unsafe extern "C" fn(i32, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TransformPointWorldToEntity: Option<_TransformPointWorldToEntity> = None;

/// Get vector to eye position - absolute coords.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity
///
/// # Returns - (vec3):
/// Eye position in absolute/world coordinates
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityEyePosition(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityEyePosition.expect("GetEntityEyePosition function was not found")(entityHandle) }
}
pub type _GetEntityEyePosition = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityEyePosition: Option<_GetEntityEyePosition> = None;

/// Get the qangles that this entity is looking at.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity
///
/// # Returns - (vec3):
/// Eye angles as a vector (pitch, yaw, roll)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityEyeAngles(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityEyeAngles.expect("GetEntityEyeAngles function was not found")(entityHandle) }
}
pub type _GetEntityEyeAngles = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityEyeAngles: Option<_GetEntityEyeAngles> = None;

/// Sets the forward velocity of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose forward velocity is to be set.
/// * `forward` - (vec3)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityForwardVector(entityHandle: i32, forward: &Vec3) {
    unsafe { __s2sdk_SetEntityForwardVector.expect("SetEntityForwardVector function was not found")(entityHandle, forward) }
}
pub type _SetEntityForwardVector = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityForwardVector: Option<_SetEntityForwardVector> = None;

/// Get the forward vector of the entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to query
///
/// # Returns - (vec3):
/// Forward-facing direction vector of the entity
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityForwardVector(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityForwardVector.expect("GetEntityForwardVector function was not found")(entityHandle) }
}
pub type _GetEntityForwardVector = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityForwardVector: Option<_GetEntityForwardVector> = None;

/// Get the left vector of the entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to query
///
/// # Returns - (vec3):
/// Left-facing direction vector of the entity (aligned with the y axis)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityLeftVector(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityLeftVector.expect("GetEntityLeftVector function was not found")(entityHandle) }
}
pub type _GetEntityLeftVector = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityLeftVector: Option<_GetEntityLeftVector> = None;

/// Get the right vector of the entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to query
///
/// # Returns - (vec3):
/// Right-facing direction vector of the entity
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityRightVector(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityRightVector.expect("GetEntityRightVector function was not found")(entityHandle) }
}
pub type _GetEntityRightVector = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityRightVector: Option<_GetEntityRightVector> = None;

/// Get the up vector of the entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to query
///
/// # Returns - (vec3):
/// Up-facing direction vector of the entity
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityUpVector(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityUpVector.expect("GetEntityUpVector function was not found")(entityHandle) }
}
pub type _GetEntityUpVector = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityUpVector: Option<_GetEntityUpVector> = None;

/// Get the entity-to-world transformation matrix.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to query
///
/// # Returns - (mat4x4):
/// 4x4 transformation matrix representing entity's position, rotation, and scale in world space
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityTransform(entityHandle: i32) -> Mat4x4 {
    unsafe { __s2sdk_GetEntityTransform.expect("GetEntityTransform function was not found")(entityHandle) }
}
pub type _GetEntityTransform = unsafe extern "C" fn(i32) -> Mat4x4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityTransform: Option<_GetEntityTransform> = None;

/// Retrieves the model name of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose model name is to be retrieved.
///
/// # Returns - (string):
/// A string where the model name will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityModel(entityHandle: i32) -> Str {
    unsafe { __s2sdk_GetEntityModel.expect("GetEntityModel function was not found")(entityHandle) }
}
pub type _GetEntityModel = unsafe extern "C" fn(i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityModel: Option<_GetEntityModel> = None;

/// Sets the model name of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose model name is to be set.
/// * `model` - (string): The new model name to set for the entity.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityModel(entityHandle: i32, model: &Str) {
    unsafe { __s2sdk_SetEntityModel.expect("SetEntityModel function was not found")(entityHandle, model) }
}
pub type _SetEntityModel = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityModel: Option<_SetEntityModel> = None;

/// Retrieves the water level of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose water level is to be retrieved.
///
/// # Returns - (float):
/// The water level of the entity, or 0.0f if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityWaterLevel(entityHandle: i32) -> f32 {
    unsafe { __s2sdk_GetEntityWaterLevel.expect("GetEntityWaterLevel function was not found")(entityHandle) }
}
pub type _GetEntityWaterLevel = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityWaterLevel: Option<_GetEntityWaterLevel> = None;

/// Retrieves the ground entity of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose ground entity is to be retrieved.
///
/// # Returns - (int32):
/// The handle of the ground entity, or INVALID_EHANDLE_INDEX if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityGroundEntity(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetEntityGroundEntity.expect("GetEntityGroundEntity function was not found")(entityHandle) }
}
pub type _GetEntityGroundEntity = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityGroundEntity: Option<_GetEntityGroundEntity> = None;

/// Retrieves the effects of an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose effects are to be retrieved.
///
/// # Returns - (int32):
/// The effect flags of the entity, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityEffects(entityHandle: i32) -> i32 {
    unsafe { __s2sdk_GetEntityEffects.expect("GetEntityEffects function was not found")(entityHandle) }
}
pub type _GetEntityEffects = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityEffects: Option<_GetEntityEffects> = None;

/// Adds the render effect flag to an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to modify
/// * `effects` - (int32): Render effect flags to add
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AddEntityEffects(entityHandle: i32, effects: i32) {
    unsafe { __s2sdk_AddEntityEffects.expect("AddEntityEffects function was not found")(entityHandle, effects) }
}
pub type _AddEntityEffects = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AddEntityEffects: Option<_AddEntityEffects> = None;

/// Removes the render effect flag from an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to modify
/// * `effects` - (int32): Render effect flags to remove
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RemoveEntityEffects(entityHandle: i32, effects: i32) {
    unsafe { __s2sdk_RemoveEntityEffects.expect("RemoveEntityEffects function was not found")(entityHandle, effects) }
}
pub type _RemoveEntityEffects = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RemoveEntityEffects: Option<_RemoveEntityEffects> = None;

/// Get a vector containing max bounds, centered on object.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to query
///
/// # Returns - (vec3):
/// Vector containing the maximum bounds of the entity's bounding box
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityBoundingMaxs(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityBoundingMaxs.expect("GetEntityBoundingMaxs function was not found")(entityHandle) }
}
pub type _GetEntityBoundingMaxs = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityBoundingMaxs: Option<_GetEntityBoundingMaxs> = None;

/// Get a vector containing min bounds, centered on object.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to query
///
/// # Returns - (vec3):
/// Vector containing the minimum bounds of the entity's bounding box
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityBoundingMins(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityBoundingMins.expect("GetEntityBoundingMins function was not found")(entityHandle) }
}
pub type _GetEntityBoundingMins = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityBoundingMins: Option<_GetEntityBoundingMins> = None;

/// Get vector to center of object - absolute coords.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to query
///
/// # Returns - (vec3):
/// Vector pointing to the center of the entity in absolute/world coordinates
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityCenter(entityHandle: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntityCenter.expect("GetEntityCenter function was not found")(entityHandle) }
}
pub type _GetEntityCenter = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityCenter: Option<_GetEntityCenter> = None;

/// Teleports an entity to a specified location and orientation.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to teleport.
/// * `origin` - (vec3): A pointer to a Vector representing the new absolute position. Use nan vector to not set.
/// * `angles` - (vec3): A pointer to a QAngle representing the new orientation. Use nan vector to not set.
/// * `velocity` - (vec3): A pointer to a Vector representing the new velocity. Use nan vector to not set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TeleportEntity(entityHandle: i32, origin: &Vec3, angles: &Vec3, velocity: &Vec3) {
    unsafe { __s2sdk_TeleportEntity.expect("TeleportEntity function was not found")(entityHandle, origin, angles, velocity) }
}
pub type _TeleportEntity = unsafe extern "C" fn(i32, &Vec3, &Vec3, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TeleportEntity: Option<_TeleportEntity> = None;

/// Apply an absolute velocity impulse to an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to apply impulse to
/// * `vecImpulse` - (vec3): Velocity impulse vector to apply
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ApplyAbsVelocityImpulseToEntity(entityHandle: i32, vecImpulse: &Vec3) {
    unsafe { __s2sdk_ApplyAbsVelocityImpulseToEntity.expect("ApplyAbsVelocityImpulseToEntity function was not found")(entityHandle, vecImpulse) }
}
pub type _ApplyAbsVelocityImpulseToEntity = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ApplyAbsVelocityImpulseToEntity: Option<_ApplyAbsVelocityImpulseToEntity> = None;

/// Apply a local angular velocity impulse to an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity to apply impulse to
/// * `angImpulse` - (vec3): Angular velocity impulse vector to apply
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ApplyLocalAngularVelocityImpulseToEntity(entityHandle: i32, angImpulse: &Vec3) {
    unsafe { __s2sdk_ApplyLocalAngularVelocityImpulseToEntity.expect("ApplyLocalAngularVelocityImpulseToEntity function was not found")(entityHandle, angImpulse) }
}
pub type _ApplyLocalAngularVelocityImpulseToEntity = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ApplyLocalAngularVelocityImpulseToEntity: Option<_ApplyLocalAngularVelocityImpulseToEntity> = None;

/// Invokes a named input method on a specified entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the target entity that will receive the input.
/// * `inputName` - (string): The name of the input action to invoke.
/// * `activatorHandle` - (int32): The handle of the entity that initiated the sequence of actions.
/// * `callerHandle` - (int32): The handle of the entity sending this event.
/// * `value` - (any): The value associated with the input action.
/// * `type_` - (int32): The type or classification of the value.
/// * `outputId` - (int32): An identifier for tracking the output of this operation.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AcceptEntityInput(entityHandle: i32, inputName: &Str, activatorHandle: i32, callerHandle: i32, value: &Var, type_: FieldType, outputId: i32) {
    unsafe { __s2sdk_AcceptEntityInput.expect("AcceptEntityInput function was not found")(entityHandle, inputName, activatorHandle, callerHandle, value, type_, outputId) }
}
pub type _AcceptEntityInput = unsafe extern "C" fn(i32, &Str, i32, i32, &Var, FieldType, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AcceptEntityInput: Option<_AcceptEntityInput> = None;

/// Connects a script function to an entity output.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `output` - (string): The name of the output to connect to.
/// * `functionName` - (string): The name of the script function to call.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ConnectEntityOutput(entityHandle: i32, output: &Str, functionName: &Str) {
    unsafe { __s2sdk_ConnectEntityOutput.expect("ConnectEntityOutput function was not found")(entityHandle, output, functionName) }
}
pub type _ConnectEntityOutput = unsafe extern "C" fn(i32, &Str, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ConnectEntityOutput: Option<_ConnectEntityOutput> = None;

/// Disconnects a script function from an entity output.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `output` - (string): The name of the output.
/// * `functionName` - (string): The name of the script function to disconnect.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DisconnectEntityOutput(entityHandle: i32, output: &Str, functionName: &Str) {
    unsafe { __s2sdk_DisconnectEntityOutput.expect("DisconnectEntityOutput function was not found")(entityHandle, output, functionName) }
}
pub type _DisconnectEntityOutput = unsafe extern "C" fn(i32, &Str, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DisconnectEntityOutput: Option<_DisconnectEntityOutput> = None;

/// Disconnects a script function from an I/O event on a different entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the calling entity.
/// * `output` - (string): The name of the output.
/// * `functionName` - (string): The function name to disconnect.
/// * `targetHandle` - (int32): The handle of the entity whose output is being disconnected.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DisconnectEntityRedirectedOutput(entityHandle: i32, output: &Str, functionName: &Str, targetHandle: i32) {
    unsafe { __s2sdk_DisconnectEntityRedirectedOutput.expect("DisconnectEntityRedirectedOutput function was not found")(entityHandle, output, functionName, targetHandle) }
}
pub type _DisconnectEntityRedirectedOutput = unsafe extern "C" fn(i32, &Str, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DisconnectEntityRedirectedOutput: Option<_DisconnectEntityRedirectedOutput> = None;

/// Fires an entity output.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity firing the output.
/// * `outputName` - (string): The name of the output to fire.
/// * `activatorHandle` - (int32): The entity activating the output.
/// * `callerHandle` - (int32): The entity that called the output.
/// * `value` - (any): The value associated with the input action.
/// * `type_` - (int32): The type or classification of the value.
/// * `delay` - (float): Delay in seconds before firing the output.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FireEntityOutput(entityHandle: i32, outputName: &Str, activatorHandle: i32, callerHandle: i32, value: &Var, type_: FieldType, delay: f32) {
    unsafe { __s2sdk_FireEntityOutput.expect("FireEntityOutput function was not found")(entityHandle, outputName, activatorHandle, callerHandle, value, type_, delay) }
}
pub type _FireEntityOutput = unsafe extern "C" fn(i32, &Str, i32, i32, &Var, FieldType, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FireEntityOutput: Option<_FireEntityOutput> = None;

/// Redirects an entity output to call a function on another entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose output is being redirected.
/// * `output` - (string): The name of the output to redirect.
/// * `functionName` - (string): The function name to call on the target entity.
/// * `targetHandle` - (int32): The handle of the entity that will receive the output call.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RedirectEntityOutput(entityHandle: i32, output: &Str, functionName: &Str, targetHandle: i32) {
    unsafe { __s2sdk_RedirectEntityOutput.expect("RedirectEntityOutput function was not found")(entityHandle, output, functionName, targetHandle) }
}
pub type _RedirectEntityOutput = unsafe extern "C" fn(i32, &Str, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RedirectEntityOutput: Option<_RedirectEntityOutput> = None;

/// Makes an entity follow another entity with optional bone merging.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity that will follow
/// * `attachmentHandle` - (int32): The handle of the entity to follow
/// * `boneMerge` - (bool): If true, bones will be merged between entities
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FollowEntity(entityHandle: i32, attachmentHandle: i32, boneMerge: bool) {
    unsafe { __s2sdk_FollowEntity.expect("FollowEntity function was not found")(entityHandle, attachmentHandle, boneMerge) }
}
pub type _FollowEntity = unsafe extern "C" fn(i32, i32, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FollowEntity: Option<_FollowEntity> = None;

/// Makes an entity follow another entity and merge with a specific bone or attachment.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity that will follow
/// * `attachmentHandle` - (int32): The handle of the entity to follow
/// * `boneOrAttachName` - (string): Name of the bone or attachment point to merge with
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FollowEntityMerge(entityHandle: i32, attachmentHandle: i32, boneOrAttachName: &Str) {
    unsafe { __s2sdk_FollowEntityMerge.expect("FollowEntityMerge function was not found")(entityHandle, attachmentHandle, boneOrAttachName) }
}
pub type _FollowEntityMerge = unsafe extern "C" fn(i32, i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FollowEntityMerge: Option<_FollowEntityMerge> = None;

/// Apply damage to an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity receiving damage
/// * `inflictorHandle` - (int32): The handle of the entity inflicting damage (e.g., projectile)
/// * `attackerHandle` - (int32): The handle of the attacking entity
/// * `force` - (vec3): Direction and magnitude of force to apply
/// * `hitPos` - (vec3): Position where the damage hit occurred
/// * `damage` - (float): Amount of damage to apply
/// * `damageTypes` - (int32): Bitfield of damage type flags
///
/// # Returns - (int32):
/// Amount of damage actually applied to the entity
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TakeEntityDamage(entityHandle: i32, inflictorHandle: i32, attackerHandle: i32, force: &Vec3, hitPos: &Vec3, damage: f32, damageTypes: DamageTypes) -> i32 {
    unsafe { __s2sdk_TakeEntityDamage.expect("TakeEntityDamage function was not found")(entityHandle, inflictorHandle, attackerHandle, force, hitPos, damage, damageTypes) }
}
pub type _TakeEntityDamage = unsafe extern "C" fn(i32, i32, i32, &Vec3, &Vec3, f32, DamageTypes) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TakeEntityDamage: Option<_TakeEntityDamage> = None;

/// Retrieves a float attribute value from an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `name` - (string): The name of the attribute.
/// * `defaultValue` - (float): The default value to return if the attribute does not exist.
///
/// # Returns - (float):
/// The float value of the attribute, or the default value if missing or invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityAttributeFloatValue(entityHandle: i32, name: &Str, defaultValue: f32) -> f32 {
    unsafe { __s2sdk_GetEntityAttributeFloatValue.expect("GetEntityAttributeFloatValue function was not found")(entityHandle, name, defaultValue) }
}
pub type _GetEntityAttributeFloatValue = unsafe extern "C" fn(i32, &Str, f32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityAttributeFloatValue: Option<_GetEntityAttributeFloatValue> = None;

/// Retrieves an integer attribute value from an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `name` - (string): The name of the attribute.
/// * `defaultValue` - (int32): The default value to return if the attribute does not exist.
///
/// # Returns - (int32):
/// The integer value of the attribute, or the default value if missing or invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntityAttributeIntValue(entityHandle: i32, name: &Str, defaultValue: i32) -> i32 {
    unsafe { __s2sdk_GetEntityAttributeIntValue.expect("GetEntityAttributeIntValue function was not found")(entityHandle, name, defaultValue) }
}
pub type _GetEntityAttributeIntValue = unsafe extern "C" fn(i32, &Str, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntityAttributeIntValue: Option<_GetEntityAttributeIntValue> = None;

/// Sets a float attribute value on an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `name` - (string): The name of the attribute.
/// * `value` - (float): The float value to assign to the attribute.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityAttributeFloatValue(entityHandle: i32, name: &Str, value: f32) {
    unsafe { __s2sdk_SetEntityAttributeFloatValue.expect("SetEntityAttributeFloatValue function was not found")(entityHandle, name, value) }
}
pub type _SetEntityAttributeFloatValue = unsafe extern "C" fn(i32, &Str, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityAttributeFloatValue: Option<_SetEntityAttributeFloatValue> = None;

/// Sets an integer attribute value on an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `name` - (string): The name of the attribute.
/// * `value` - (int32): The integer value to assign to the attribute.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntityAttributeIntValue(entityHandle: i32, name: &Str, value: i32) {
    unsafe { __s2sdk_SetEntityAttributeIntValue.expect("SetEntityAttributeIntValue function was not found")(entityHandle, name, value) }
}
pub type _SetEntityAttributeIntValue = unsafe extern "C" fn(i32, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntityAttributeIntValue: Option<_SetEntityAttributeIntValue> = None;

/// Deletes an attribute from an entity.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `name` - (string): The name of the attribute to delete.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DeleteEntityAttribute(entityHandle: i32, name: &Str) {
    unsafe { __s2sdk_DeleteEntityAttribute.expect("DeleteEntityAttribute function was not found")(entityHandle, name) }
}
pub type _DeleteEntityAttribute = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DeleteEntityAttribute: Option<_DeleteEntityAttribute> = None;

/// Checks if an entity has a specific attribute.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity.
/// * `name` - (string): The name of the attribute to check.
///
/// # Returns - (bool):
/// True if the attribute exists, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn HasEntityAttribute(entityHandle: i32, name: &Str) -> bool {
    unsafe { __s2sdk_HasEntityAttribute.expect("HasEntityAttribute function was not found")(entityHandle, name) }
}
pub type _HasEntityAttribute = unsafe extern "C" fn(i32, &Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_HasEntityAttribute: Option<_HasEntityAttribute> = None;

