// Generated from s2sdk.pplugin

#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use plugify::{Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Handles the execution of a command triggered by a caller. This function processes the command, interprets its context, and handles any provided arguments.
#[allow(unused)]
pub type ConCommandCallback = unsafe extern "C" fn(i32, ConCommandContext, &Arr<Str>) -> ResultType;


/// Handles changes to a console variable's value. This function is called whenever the value of a specific console variable is modified.
#[allow(unused)]
pub type ConVarCallback = unsafe extern "C" fn(u64, &Str, &Str);


/// Handles changes to a console variable's value. This function is called whenever the value of a specific console variable is modified.
#[allow(unused)]
pub type CvarValueCallback = unsafe extern "C" fn(i32, i32, CvarValueStatus, &Str, &Str, &Arr<Var>);


/// Defines a QueueTask Callback.
#[allow(unused)]
pub type TaskCallback = unsafe extern "C" fn(&Arr<Var>);


/// This function is a callback handler for entity output events. It is triggered when a specific output event is activated, and it handles the process by passing the activator, the caller, and a delay parameter for the output.
#[allow(unused)]
pub type HookEntityOutputCallback = unsafe extern "C" fn(i32, i32, f32) -> ResultType;


/// Handles events triggered by the game event system. This function processes the event data, determines the necessary action, and optionally prevents event broadcasting.
#[allow(unused)]
pub type EventCallback = unsafe extern "C" fn(&Str, usize, bool) -> ResultType;


/// Handles the final result of a Yes/No vote. This function is called when a vote concludes, and is responsible for determining whether the vote passed based on the number of 'yes' and 'no' votes. Also receives context about the clients who participated in the vote.
#[allow(unused)]
pub type YesNoVoteResult = unsafe extern "C" fn(i32, i32, i32, i32, &Arr<i32>, &Arr<i32>) -> bool;


#[allow(unused)]
pub type YesNoVoteHandler = unsafe extern "C" fn(VoteAction, i32, i32);


/// This function is invoked when a timer event occurs. It handles the timer-related logic and performs necessary actions based on the event.
#[allow(unused)]
pub type TimerCallback = unsafe extern "C" fn(u32, &Arr<Var>);


/// Called on client connection. If you return true, the client will be allowed in the server. If you return false (or return nothing), the client will be rejected. If the client is rejected by this forward or any other, OnClientDisconnect will not be called.<br>Note: Do not write to rejectmsg if you plan on returning true. If multiple plugins write to the string buffer, it is not defined which plugin's string will be shown to the client, but it is guaranteed one of them will.
#[allow(unused)]
pub type OnClientConnectCallback = unsafe extern "C" fn(i32, &Str, &Str) -> bool;


/// Called on client connection.
#[allow(unused)]
pub type OnClientConnect_PostCallback = unsafe extern "C" fn(i32);


/// Called once a client successfully connects. This callback is paired with OnClientDisconnect.
#[allow(unused)]
pub type OnClientConnectedCallback = unsafe extern "C" fn(i32);


/// Called when a client is entering the game.
#[allow(unused)]
pub type OnClientPutInServerCallback = unsafe extern "C" fn(i32);


/// Called when a client is disconnecting from the server.
#[allow(unused)]
pub type OnClientDisconnectCallback = unsafe extern "C" fn(i32);


/// Called when a client is disconnected from the server.
#[allow(unused)]
pub type OnClientDisconnect_PostCallback = unsafe extern "C" fn(i32, NetworkDisconnectionReason);


/// Called when a client is activated by the game.
#[allow(unused)]
pub type OnClientActiveCallback = unsafe extern "C" fn(i32, bool);


/// Called when a client is fully connected to the game.
#[allow(unused)]
pub type OnClientFullyConnectCallback = unsafe extern "C" fn(i32);


/// Called whenever the client's settings are changed.
#[allow(unused)]
pub type OnClientSettingsChangedCallback = unsafe extern "C" fn(i32);


/// Called when a client is fully connected to the game.
#[allow(unused)]
pub type OnClientAuthenticatedCallback = unsafe extern "C" fn(i32, u64);


/// Called right before a round terminates.
#[allow(unused)]
pub type OnRoundTerminatedCallback = unsafe extern "C" fn(f32, CSRoundEndReason);


/// Called when an entity is created.
#[allow(unused)]
pub type OnEntityCreatedCallback = unsafe extern "C" fn(i32);


/// Called when when an entity is destroyed.
#[allow(unused)]
pub type OnEntityDeletedCallback = unsafe extern "C" fn(i32);


/// When an entity is reparented to another entity.
#[allow(unused)]
pub type OnEntityParentChangedCallback = unsafe extern "C" fn(i32, i32);


/// When entities is transmitted to another entities.
#[allow(unused)]
pub type OnServerCheckTransmitCallback = unsafe extern "C" fn(&Arr<usize>);


/// Called on every server startup.
#[allow(unused)]
pub type OnServerStartupCallback = unsafe extern "C" fn();


/// Called before server activation to build game session manifest.
#[allow(unused)]
pub type OnBuildGameSessionManifestCallback = unsafe extern "C" fn();


/// Called on every server activate.
#[allow(unused)]
pub type OnServerActivateCallback = unsafe extern "C" fn();


/// Called on every server spawn.
#[allow(unused)]
pub type OnServerSpawnCallback = unsafe extern "C" fn();


/// Called on every server started only once.
#[allow(unused)]
pub type OnServerStartedCallback = unsafe extern "C" fn();


/// Called on every map start.
#[allow(unused)]
pub type OnMapStartCallback = unsafe extern "C" fn();


/// Called on every map end.
#[allow(unused)]
pub type OnMapEndCallback = unsafe extern "C" fn();


/// Called before every server frame. Note that you should avoid doing expensive computations or declaring large local arrays.
#[allow(unused)]
pub type OnGameFrameCallback = unsafe extern "C" fn(bool, bool, bool);


/// Called when the server is not in game.
#[allow(unused)]
pub type OnUpdateWhenNotInGameCallback = unsafe extern "C" fn(f32);


/// Called before every server frame, before entities are updated.
#[allow(unused)]
pub type OnPreWorldUpdateCallback = unsafe extern "C" fn(bool);


/// Callback function for user messages.
#[allow(unused)]
pub type UserMessageCallback = unsafe extern "C" fn(usize) -> ResultType;


