// Generated from s2sdk.pplugin (group: clients)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Retrieves the player slot from a given entity pointer.
///
/// # Arguments
/// * `entity` - (ptr64): A pointer to the entity (CBaseEntity*).
///
/// # Returns - (int32):
/// The player slot if valid, otherwise -1.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn EntPointerToPlayerSlot(entity: usize) -> i32 {
    unsafe { __s2sdk_EntPointerToPlayerSlot.expect("EntPointerToPlayerSlot function was not found")(entity) }
}
pub type _EntPointerToPlayerSlot = unsafe extern "C" fn(usize) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_EntPointerToPlayerSlot: Option<_EntPointerToPlayerSlot> = None;

/// Returns a pointer to the entity instance by player slot index.
///
/// # Arguments
/// * `playerSlot` - (int32): Index of the player slot.
///
/// # Returns - (ptr64):
/// Pointer to the entity instance, or nullptr if the slot is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PlayerSlotToEntPointer(playerSlot: i32) -> usize {
    unsafe { __s2sdk_PlayerSlotToEntPointer.expect("PlayerSlotToEntPointer function was not found")(playerSlot) }
}
pub type _PlayerSlotToEntPointer = unsafe extern "C" fn(i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PlayerSlotToEntPointer: Option<_PlayerSlotToEntPointer> = None;

/// Returns the entity handle associated with a player slot index.
///
/// # Arguments
/// * `playerSlot` - (int32): Index of the player slot.
///
/// # Returns - (int32):
/// The index of the entity, or -1 if the handle is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PlayerSlotToEntHandle(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_PlayerSlotToEntHandle.expect("PlayerSlotToEntHandle function was not found")(playerSlot) }
}
pub type _PlayerSlotToEntHandle = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PlayerSlotToEntHandle: Option<_PlayerSlotToEntHandle> = None;

/// Retrieves the client object from a given player slot.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot (0-based).
///
/// # Returns - (ptr64):
/// A pointer to the client object if found, otherwise nullptr.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PlayerSlotToClientPtr(playerSlot: i32) -> usize {
    unsafe { __s2sdk_PlayerSlotToClientPtr.expect("PlayerSlotToClientPtr function was not found")(playerSlot) }
}
pub type _PlayerSlotToClientPtr = unsafe extern "C" fn(i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PlayerSlotToClientPtr: Option<_PlayerSlotToClientPtr> = None;

/// Retrieves the index of a given client object.
///
/// # Arguments
/// * `client` - (ptr64): A pointer to the client object (CServerSideClient*).
///
/// # Returns - (int32):
/// The player slot if found, otherwise -1.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ClientPtrToPlayerSlot(client: usize) -> i32 {
    unsafe { __s2sdk_ClientPtrToPlayerSlot.expect("ClientPtrToPlayerSlot function was not found")(client) }
}
pub type _ClientPtrToPlayerSlot = unsafe extern "C" fn(usize) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ClientPtrToPlayerSlot: Option<_ClientPtrToPlayerSlot> = None;

/// Returns the entity index for a given player slot.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (int32):
/// The entity index if valid, otherwise 0.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PlayerSlotToClientIndex(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_PlayerSlotToClientIndex.expect("PlayerSlotToClientIndex function was not found")(playerSlot) }
}
pub type _PlayerSlotToClientIndex = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PlayerSlotToClientIndex: Option<_PlayerSlotToClientIndex> = None;

/// Retrieves the player slot from a given client index.
///
/// # Arguments
/// * `clientIndex` - (int32): The index of the client.
///
/// # Returns - (int32):
/// The player slot if valid, otherwise -1.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ClientIndexToPlayerSlot(clientIndex: i32) -> i32 {
    unsafe { __s2sdk_ClientIndexToPlayerSlot.expect("ClientIndexToPlayerSlot function was not found")(clientIndex) }
}
pub type _ClientIndexToPlayerSlot = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ClientIndexToPlayerSlot: Option<_ClientIndexToPlayerSlot> = None;

/// Retrieves the player slot from a given player service.
///
/// # Arguments
/// * `service` - (ptr64): The service pointer. Like CCSPlayer_ItemServices, CCSPlayer_WeaponServices ect.
///
/// # Returns - (int32):
/// The player slot if valid, otherwise -1.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PlayerServicesToPlayerSlot(service: usize) -> i32 {
    unsafe { __s2sdk_PlayerServicesToPlayerSlot.expect("PlayerServicesToPlayerSlot function was not found")(service) }
}
pub type _PlayerServicesToPlayerSlot = unsafe extern "C" fn(usize) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PlayerServicesToPlayerSlot: Option<_PlayerServicesToPlayerSlot> = None;

/// Retrieves a client's authentication string (SteamID).
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose authentication string is being retrieved.
///
/// # Returns - (string):
/// The authentication string.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientAuthId(playerSlot: i32) -> Str {
    unsafe { __s2sdk_GetClientAuthId.expect("GetClientAuthId function was not found")(playerSlot) }
}
pub type _GetClientAuthId = unsafe extern "C" fn(i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientAuthId: Option<_GetClientAuthId> = None;

/// Returns the client's Steam account ID, a unique number identifying a given Steam account.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (uint32):
/// uint32_t The client's steam account ID.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientAccountId(playerSlot: i32) -> u32 {
    unsafe { __s2sdk_GetClientAccountId.expect("GetClientAccountId function was not found")(playerSlot) }
}
pub type _GetClientAccountId = unsafe extern "C" fn(i32) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientAccountId: Option<_GetClientAccountId> = None;

/// Returns the client's SteamID64 - a unique 64-bit identifier of a Steam account.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (uint64):
/// uint64_t The client's SteamID64.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientSteamID64(playerSlot: i32) -> u64 {
    unsafe { __s2sdk_GetClientSteamID64.expect("GetClientSteamID64 function was not found")(playerSlot) }
}
pub type _GetClientSteamID64 = unsafe extern "C" fn(i32) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientSteamID64: Option<_GetClientSteamID64> = None;

/// Retrieves a client's IP address.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (string):
/// The client's IP address.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientIp(playerSlot: i32) -> Str {
    unsafe { __s2sdk_GetClientIp.expect("GetClientIp function was not found")(playerSlot) }
}
pub type _GetClientIp = unsafe extern "C" fn(i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientIp: Option<_GetClientIp> = None;

/// Retrieves a client's language.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (string):
/// The client's language.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientLanguage(playerSlot: i32) -> Str {
    unsafe { __s2sdk_GetClientLanguage.expect("GetClientLanguage function was not found")(playerSlot) }
}
pub type _GetClientLanguage = unsafe extern "C" fn(i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientLanguage: Option<_GetClientLanguage> = None;

/// Retrieves a client's operating system.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (string):
/// The client's operating system.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientOS(playerSlot: i32) -> Str {
    unsafe { __s2sdk_GetClientOS.expect("GetClientOS function was not found")(playerSlot) }
}
pub type _GetClientOS = unsafe extern "C" fn(i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientOS: Option<_GetClientOS> = None;

/// Returns the client's name.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (string):
/// The client's name.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientName(playerSlot: i32) -> Str {
    unsafe { __s2sdk_GetClientName.expect("GetClientName function was not found")(playerSlot) }
}
pub type _GetClientName = unsafe extern "C" fn(i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientName: Option<_GetClientName> = None;

/// Returns the client's connection time in seconds.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (float):
/// float Connection time in seconds.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientTime(playerSlot: i32) -> f32 {
    unsafe { __s2sdk_GetClientTime.expect("GetClientTime function was not found")(playerSlot) }
}
pub type _GetClientTime = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientTime: Option<_GetClientTime> = None;

/// Returns the client's current latency (RTT).
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (float):
/// float Latency value.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientLatency(playerSlot: i32) -> f32 {
    unsafe { __s2sdk_GetClientLatency.expect("GetClientLatency function was not found")(playerSlot) }
}
pub type _GetClientLatency = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientLatency: Option<_GetClientLatency> = None;

/// Returns the client's access flags.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (uint64):
/// uint64 Access flags as a bitmask.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetUserFlagBits(playerSlot: i32) -> u64 {
    unsafe { __s2sdk_GetUserFlagBits.expect("GetUserFlagBits function was not found")(playerSlot) }
}
pub type _GetUserFlagBits = unsafe extern "C" fn(i32) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetUserFlagBits: Option<_GetUserFlagBits> = None;

/// Sets the access flags on a client using a bitmask.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `flags` - (uint64): Bitmask representing the flags to be set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetUserFlagBits(playerSlot: i32, flags: u64) {
    unsafe { __s2sdk_SetUserFlagBits.expect("SetUserFlagBits function was not found")(playerSlot, flags) }
}
pub type _SetUserFlagBits = unsafe extern "C" fn(i32, u64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetUserFlagBits: Option<_SetUserFlagBits> = None;

/// Adds access flags to a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `flags` - (uint64): Bitmask representing the flags to be added.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AddUserFlags(playerSlot: i32, flags: u64) {
    unsafe { __s2sdk_AddUserFlags.expect("AddUserFlags function was not found")(playerSlot, flags) }
}
pub type _AddUserFlags = unsafe extern "C" fn(i32, u64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AddUserFlags: Option<_AddUserFlags> = None;

/// Removes access flags from a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `flags` - (uint64): Bitmask representing the flags to be removed.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RemoveUserFlags(playerSlot: i32, flags: u64) {
    unsafe { __s2sdk_RemoveUserFlags.expect("RemoveUserFlags function was not found")(playerSlot, flags) }
}
pub type _RemoveUserFlags = unsafe extern "C" fn(i32, u64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RemoveUserFlags: Option<_RemoveUserFlags> = None;

/// Checks if a certain player has been authenticated.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (bool):
/// true if the player is authenticated, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsClientAuthorized(playerSlot: i32) -> bool {
    unsafe { __s2sdk_IsClientAuthorized.expect("IsClientAuthorized function was not found")(playerSlot) }
}
pub type _IsClientAuthorized = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsClientAuthorized: Option<_IsClientAuthorized> = None;

/// Checks if a certain player is connected.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (bool):
/// true if the player is connected, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsClientConnected(playerSlot: i32) -> bool {
    unsafe { __s2sdk_IsClientConnected.expect("IsClientConnected function was not found")(playerSlot) }
}
pub type _IsClientConnected = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsClientConnected: Option<_IsClientConnected> = None;

/// Checks if a certain player has entered the game.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (bool):
/// true if the player is in the game, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsClientInGame(playerSlot: i32) -> bool {
    unsafe { __s2sdk_IsClientInGame.expect("IsClientInGame function was not found")(playerSlot) }
}
pub type _IsClientInGame = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsClientInGame: Option<_IsClientInGame> = None;

/// Checks if a certain player is the SourceTV bot.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (bool):
/// true if the client is the SourceTV bot, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsClientSourceTV(playerSlot: i32) -> bool {
    unsafe { __s2sdk_IsClientSourceTV.expect("IsClientSourceTV function was not found")(playerSlot) }
}
pub type _IsClientSourceTV = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsClientSourceTV: Option<_IsClientSourceTV> = None;

/// Checks if the client is alive or dead.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (bool):
/// true if the client is alive, false if dead.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsClientAlive(playerSlot: i32) -> bool {
    unsafe { __s2sdk_IsClientAlive.expect("IsClientAlive function was not found")(playerSlot) }
}
pub type _IsClientAlive = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsClientAlive: Option<_IsClientAlive> = None;

/// Checks if a certain player is a fake client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (bool):
/// true if the client is a fake client, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsFakeClient(playerSlot: i32) -> bool {
    unsafe { __s2sdk_IsFakeClient.expect("IsFakeClient function was not found")(playerSlot) }
}
pub type _IsFakeClient = unsafe extern "C" fn(i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsFakeClient: Option<_IsFakeClient> = None;

/// Retrieves the movement type of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose movement type is to be retrieved.
///
/// # Returns - (int32):
/// The movement type of the entity, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientMoveType(playerSlot: i32) -> MoveType {
    unsafe { __s2sdk_GetClientMoveType.expect("GetClientMoveType function was not found")(playerSlot) }
}
pub type _GetClientMoveType = unsafe extern "C" fn(i32) -> MoveType;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientMoveType: Option<_GetClientMoveType> = None;

/// Sets the movement type of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose movement type is to be set.
/// * `moveType` - (int32): The movement type of the entity, or 0 if the entity is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientMoveType(playerSlot: i32, moveType: MoveType) {
    unsafe { __s2sdk_SetClientMoveType.expect("SetClientMoveType function was not found")(playerSlot, moveType) }
}
pub type _SetClientMoveType = unsafe extern "C" fn(i32, MoveType);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientMoveType: Option<_SetClientMoveType> = None;

/// Retrieves the gravity scale of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose gravity scale is to be retrieved.
///
/// # Returns - (float):
/// The gravity scale of the client, or 0.0f if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientGravity(playerSlot: i32) -> f32 {
    unsafe { __s2sdk_GetClientGravity.expect("GetClientGravity function was not found")(playerSlot) }
}
pub type _GetClientGravity = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientGravity: Option<_GetClientGravity> = None;

/// Sets the gravity scale of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose gravity scale is to be set.
/// * `gravity` - (float): The new gravity scale to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientGravity(playerSlot: i32, gravity: f32) {
    unsafe { __s2sdk_SetClientGravity.expect("SetClientGravity function was not found")(playerSlot, gravity) }
}
pub type _SetClientGravity = unsafe extern "C" fn(i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientGravity: Option<_SetClientGravity> = None;

/// Retrieves the flags of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose flags are to be retrieved.
///
/// # Returns - (int32):
/// The flags of the client, or 0 if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientFlags(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientFlags.expect("GetClientFlags function was not found")(playerSlot) }
}
pub type _GetClientFlags = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientFlags: Option<_GetClientFlags> = None;

/// Sets the flags of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose flags are to be set.
/// * `flags` - (int32): The new flags to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientFlags(playerSlot: i32, flags: i32) {
    unsafe { __s2sdk_SetClientFlags.expect("SetClientFlags function was not found")(playerSlot, flags) }
}
pub type _SetClientFlags = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientFlags: Option<_SetClientFlags> = None;

/// Retrieves the render color of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose render color is to be retrieved.
///
/// # Returns - (vec4):
/// The raw color value of the client's render color, or 0 if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientRenderColor(playerSlot: i32) -> Vec4 {
    unsafe { __s2sdk_GetClientRenderColor.expect("GetClientRenderColor function was not found")(playerSlot) }
}
pub type _GetClientRenderColor = unsafe extern "C" fn(i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientRenderColor: Option<_GetClientRenderColor> = None;

/// Sets the render color of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose render color is to be set.
/// * `color` - (vec4): The new raw color value to set for the client's render color.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientRenderColor(playerSlot: i32, color: &Vec4) {
    unsafe { __s2sdk_SetClientRenderColor.expect("SetClientRenderColor function was not found")(playerSlot, color) }
}
pub type _SetClientRenderColor = unsafe extern "C" fn(i32, &Vec4);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientRenderColor: Option<_SetClientRenderColor> = None;

/// Retrieves the render mode of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose render mode is to be retrieved.
///
/// # Returns - (uint8):
/// The render mode of the client, or 0 if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientRenderMode(playerSlot: i32) -> RenderMode {
    unsafe { __s2sdk_GetClientRenderMode.expect("GetClientRenderMode function was not found")(playerSlot) }
}
pub type _GetClientRenderMode = unsafe extern "C" fn(i32) -> RenderMode;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientRenderMode: Option<_GetClientRenderMode> = None;

/// Sets the render mode of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose render mode is to be set.
/// * `renderMode` - (uint8): The new render mode to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientRenderMode(playerSlot: i32, renderMode: RenderMode) {
    unsafe { __s2sdk_SetClientRenderMode.expect("SetClientRenderMode function was not found")(playerSlot, renderMode) }
}
pub type _SetClientRenderMode = unsafe extern "C" fn(i32, RenderMode);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientRenderMode: Option<_SetClientRenderMode> = None;

/// Retrieves the mass of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose mass is to be retrieved.
///
/// # Returns - (int32):
/// The mass of the client, or 0 if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientMass(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientMass.expect("GetClientMass function was not found")(playerSlot) }
}
pub type _GetClientMass = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientMass: Option<_GetClientMass> = None;

/// Sets the mass of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose mass is to be set.
/// * `mass` - (int32): The new mass value to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientMass(playerSlot: i32, mass: i32) {
    unsafe { __s2sdk_SetClientMass.expect("SetClientMass function was not found")(playerSlot, mass) }
}
pub type _SetClientMass = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientMass: Option<_SetClientMass> = None;

/// Retrieves the friction of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose friction is to be retrieved.
///
/// # Returns - (float):
/// The friction of the client, or 0 if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientFriction(playerSlot: i32) -> f32 {
    unsafe { __s2sdk_GetClientFriction.expect("GetClientFriction function was not found")(playerSlot) }
}
pub type _GetClientFriction = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientFriction: Option<_GetClientFriction> = None;

/// Sets the friction of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose friction is to be set.
/// * `friction` - (float): The new friction value to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientFriction(playerSlot: i32, friction: f32) {
    unsafe { __s2sdk_SetClientFriction.expect("SetClientFriction function was not found")(playerSlot, friction) }
}
pub type _SetClientFriction = unsafe extern "C" fn(i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientFriction: Option<_SetClientFriction> = None;

/// Retrieves the health of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose health is to be retrieved.
///
/// # Returns - (int32):
/// The health of the client, or 0 if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientHealth(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientHealth.expect("GetClientHealth function was not found")(playerSlot) }
}
pub type _GetClientHealth = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientHealth: Option<_GetClientHealth> = None;

/// Sets the health of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose health is to be set.
/// * `health` - (int32): The new health value to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientHealth(playerSlot: i32, health: i32) {
    unsafe { __s2sdk_SetClientHealth.expect("SetClientHealth function was not found")(playerSlot, health) }
}
pub type _SetClientHealth = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientHealth: Option<_SetClientHealth> = None;

/// Retrieves the max health of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose max health is to be retrieved.
///
/// # Returns - (int32):
/// The max health of the client, or 0 if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientMaxHealth(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientMaxHealth.expect("GetClientMaxHealth function was not found")(playerSlot) }
}
pub type _GetClientMaxHealth = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientMaxHealth: Option<_GetClientMaxHealth> = None;

/// Sets the max health of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose max health is to be set.
/// * `maxHealth` - (int32): The new max health value to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientMaxHealth(playerSlot: i32, maxHealth: i32) {
    unsafe { __s2sdk_SetClientMaxHealth.expect("SetClientMaxHealth function was not found")(playerSlot, maxHealth) }
}
pub type _SetClientMaxHealth = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientMaxHealth: Option<_SetClientMaxHealth> = None;

/// Retrieves the team number of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose team number is to be retrieved.
///
/// # Returns - (int32):
/// The team number of the client, or 0 if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientTeam(playerSlot: i32) -> CSTeam {
    unsafe { __s2sdk_GetClientTeam.expect("GetClientTeam function was not found")(playerSlot) }
}
pub type _GetClientTeam = unsafe extern "C" fn(i32) -> CSTeam;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientTeam: Option<_GetClientTeam> = None;

/// Sets the team number of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose team number is to be set.
/// * `team` - (int32): The new team number to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientTeam(playerSlot: i32, team: CSTeam) {
    unsafe { __s2sdk_SetClientTeam.expect("SetClientTeam function was not found")(playerSlot, team) }
}
pub type _SetClientTeam = unsafe extern "C" fn(i32, CSTeam);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientTeam: Option<_SetClientTeam> = None;

/// Retrieves the absolute origin of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose absolute origin is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the absolute origin will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientAbsOrigin(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientAbsOrigin.expect("GetClientAbsOrigin function was not found")(playerSlot) }
}
pub type _GetClientAbsOrigin = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientAbsOrigin: Option<_GetClientAbsOrigin> = None;

/// Sets the absolute origin of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose absolute origin is to be set.
/// * `origin` - (vec3): The new absolute origin to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientAbsOrigin(playerSlot: i32, origin: &Vec3) {
    unsafe { __s2sdk_SetClientAbsOrigin.expect("SetClientAbsOrigin function was not found")(playerSlot, origin) }
}
pub type _SetClientAbsOrigin = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientAbsOrigin: Option<_SetClientAbsOrigin> = None;

/// Retrieves the absolute scale of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose absolute scale is to be retrieved.
///
/// # Returns - (float):
/// A vector where the absolute scale will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientAbsScale(playerSlot: i32) -> f32 {
    unsafe { __s2sdk_GetClientAbsScale.expect("GetClientAbsScale function was not found")(playerSlot) }
}
pub type _GetClientAbsScale = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientAbsScale: Option<_GetClientAbsScale> = None;

/// Sets the absolute scale of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose absolute scale is to be set.
/// * `scale` - (float): The new absolute scale to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientAbsScale(playerSlot: i32, scale: f32) {
    unsafe { __s2sdk_SetClientAbsScale.expect("SetClientAbsScale function was not found")(playerSlot, scale) }
}
pub type _SetClientAbsScale = unsafe extern "C" fn(i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientAbsScale: Option<_SetClientAbsScale> = None;

/// Retrieves the angular rotation of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose angular rotation is to be retrieved.
///
/// # Returns - (vec3):
/// A QAngle where the angular rotation will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientAbsAngles(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientAbsAngles.expect("GetClientAbsAngles function was not found")(playerSlot) }
}
pub type _GetClientAbsAngles = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientAbsAngles: Option<_GetClientAbsAngles> = None;

/// Sets the angular rotation of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose angular rotation is to be set.
/// * `angle` - (vec3): The new angular rotation to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientAbsAngles(playerSlot: i32, angle: &Vec3) {
    unsafe { __s2sdk_SetClientAbsAngles.expect("SetClientAbsAngles function was not found")(playerSlot, angle) }
}
pub type _SetClientAbsAngles = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientAbsAngles: Option<_SetClientAbsAngles> = None;

/// Retrieves the local origin of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose local origin is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the local origin will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientLocalOrigin(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientLocalOrigin.expect("GetClientLocalOrigin function was not found")(playerSlot) }
}
pub type _GetClientLocalOrigin = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientLocalOrigin: Option<_GetClientLocalOrigin> = None;

/// Sets the local origin of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose local origin is to be set.
/// * `origin` - (vec3): The new local origin to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientLocalOrigin(playerSlot: i32, origin: &Vec3) {
    unsafe { __s2sdk_SetClientLocalOrigin.expect("SetClientLocalOrigin function was not found")(playerSlot, origin) }
}
pub type _SetClientLocalOrigin = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientLocalOrigin: Option<_SetClientLocalOrigin> = None;

/// Retrieves the local scale of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose local scale is to be retrieved.
///
/// # Returns - (float):
/// A vector where the local scale will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientLocalScale(playerSlot: i32) -> f32 {
    unsafe { __s2sdk_GetClientLocalScale.expect("GetClientLocalScale function was not found")(playerSlot) }
}
pub type _GetClientLocalScale = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientLocalScale: Option<_GetClientLocalScale> = None;

/// Sets the local scale of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose local scale is to be set.
/// * `scale` - (float): The new local scale to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientLocalScale(playerSlot: i32, scale: f32) {
    unsafe { __s2sdk_SetClientLocalScale.expect("SetClientLocalScale function was not found")(playerSlot, scale) }
}
pub type _SetClientLocalScale = unsafe extern "C" fn(i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientLocalScale: Option<_SetClientLocalScale> = None;

/// Retrieves the angular rotation of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose angular rotation is to be retrieved.
///
/// # Returns - (vec3):
/// A QAngle where the angular rotation will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientLocalAngles(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientLocalAngles.expect("GetClientLocalAngles function was not found")(playerSlot) }
}
pub type _GetClientLocalAngles = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientLocalAngles: Option<_GetClientLocalAngles> = None;

/// Sets the angular rotation of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose angular rotation is to be set.
/// * `angle` - (vec3): The new angular rotation to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientLocalAngles(playerSlot: i32, angle: &Vec3) {
    unsafe { __s2sdk_SetClientLocalAngles.expect("SetClientLocalAngles function was not found")(playerSlot, angle) }
}
pub type _SetClientLocalAngles = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientLocalAngles: Option<_SetClientLocalAngles> = None;

/// Retrieves the absolute velocity of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose absolute velocity is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the absolute velocity will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientAbsVelocity(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientAbsVelocity.expect("GetClientAbsVelocity function was not found")(playerSlot) }
}
pub type _GetClientAbsVelocity = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientAbsVelocity: Option<_GetClientAbsVelocity> = None;

/// Sets the absolute velocity of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose absolute velocity is to be set.
/// * `velocity` - (vec3): The new absolute velocity to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientAbsVelocity(playerSlot: i32, velocity: &Vec3) {
    unsafe { __s2sdk_SetClientAbsVelocity.expect("SetClientAbsVelocity function was not found")(playerSlot, velocity) }
}
pub type _SetClientAbsVelocity = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientAbsVelocity: Option<_SetClientAbsVelocity> = None;

/// Retrieves the base velocity of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose base velocity is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the base velocity will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientBaseVelocity(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientBaseVelocity.expect("GetClientBaseVelocity function was not found")(playerSlot) }
}
pub type _GetClientBaseVelocity = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientBaseVelocity: Option<_GetClientBaseVelocity> = None;

/// Retrieves the local angular velocity of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose local angular velocity is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the local angular velocity will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientLocalAngVelocity(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientLocalAngVelocity.expect("GetClientLocalAngVelocity function was not found")(playerSlot) }
}
pub type _GetClientLocalAngVelocity = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientLocalAngVelocity: Option<_GetClientLocalAngVelocity> = None;

/// Retrieves the angular velocity of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose angular velocity is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the angular velocity will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientAngVelocity(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientAngVelocity.expect("GetClientAngVelocity function was not found")(playerSlot) }
}
pub type _GetClientAngVelocity = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientAngVelocity: Option<_GetClientAngVelocity> = None;

/// Sets the angular velocity of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose angular velocity is to be set.
/// * `velocity` - (vec3): The new angular velocity to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientAngVelocity(playerSlot: i32, velocity: &Vec3) {
    unsafe { __s2sdk_SetClientAngVelocity.expect("SetClientAngVelocity function was not found")(playerSlot, velocity) }
}
pub type _SetClientAngVelocity = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientAngVelocity: Option<_SetClientAngVelocity> = None;

/// Retrieves the local velocity of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose local velocity is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the local velocity will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientLocalVelocity(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientLocalVelocity.expect("GetClientLocalVelocity function was not found")(playerSlot) }
}
pub type _GetClientLocalVelocity = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientLocalVelocity: Option<_GetClientLocalVelocity> = None;

/// Retrieves the angular rotation of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose angular rotation is to be retrieved.
///
/// # Returns - (vec3):
/// A vector where the angular rotation will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientAngRotation(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientAngRotation.expect("GetClientAngRotation function was not found")(playerSlot) }
}
pub type _GetClientAngRotation = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientAngRotation: Option<_GetClientAngRotation> = None;

/// Sets the angular rotation of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose angular rotation is to be set.
/// * `rotation` - (vec3): The new angular rotation to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientAngRotation(playerSlot: i32, rotation: &Vec3) {
    unsafe { __s2sdk_SetClientAngRotation.expect("SetClientAngRotation function was not found")(playerSlot, rotation) }
}
pub type _SetClientAngRotation = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientAngRotation: Option<_SetClientAngRotation> = None;

/// Returns the input Vector transformed from client to world space.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot
/// * `point` - (vec3): Point in client local space to transform
///
/// # Returns - (vec3):
/// The point transformed to world space coordinates
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TransformPointClientToWorld(playerSlot: i32, point: &Vec3) -> Vec3 {
    unsafe { __s2sdk_TransformPointClientToWorld.expect("TransformPointClientToWorld function was not found")(playerSlot, point) }
}
pub type _TransformPointClientToWorld = unsafe extern "C" fn(i32, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TransformPointClientToWorld: Option<_TransformPointClientToWorld> = None;

/// Returns the input Vector transformed from world to client space.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot
/// * `point` - (vec3): Point in world space to transform
///
/// # Returns - (vec3):
/// The point transformed to client local space coordinates
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TransformPointWorldToClient(playerSlot: i32, point: &Vec3) -> Vec3 {
    unsafe { __s2sdk_TransformPointWorldToClient.expect("TransformPointWorldToClient function was not found")(playerSlot, point) }
}
pub type _TransformPointWorldToClient = unsafe extern "C" fn(i32, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TransformPointWorldToClient: Option<_TransformPointWorldToClient> = None;

/// Get vector to eye position - absolute coords.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot
///
/// # Returns - (vec3):
/// Eye position in absolute/world coordinates
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientEyePosition(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientEyePosition.expect("GetClientEyePosition function was not found")(playerSlot) }
}
pub type _GetClientEyePosition = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientEyePosition: Option<_GetClientEyePosition> = None;

/// Get the qangles that this client is looking at.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot
///
/// # Returns - (vec3):
/// Eye angles as a vector (pitch, yaw, roll)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientEyeAngles(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientEyeAngles.expect("GetClientEyeAngles function was not found")(playerSlot) }
}
pub type _GetClientEyeAngles = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientEyeAngles: Option<_GetClientEyeAngles> = None;

/// Sets the forward velocity of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose forward velocity is to be set.
/// * `forward` - (vec3)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientForwardVector(playerSlot: i32, forward: &Vec3) {
    unsafe { __s2sdk_SetClientForwardVector.expect("SetClientForwardVector function was not found")(playerSlot, forward) }
}
pub type _SetClientForwardVector = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientForwardVector: Option<_SetClientForwardVector> = None;

/// Get the forward vector of the client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to query
///
/// # Returns - (vec3):
/// Forward-facing direction vector of the client
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientForwardVector(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientForwardVector.expect("GetClientForwardVector function was not found")(playerSlot) }
}
pub type _GetClientForwardVector = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientForwardVector: Option<_GetClientForwardVector> = None;

/// Get the left vector of the client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to query
///
/// # Returns - (vec3):
/// Left-facing direction vector of the client (aligned with the y axis)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientLeftVector(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientLeftVector.expect("GetClientLeftVector function was not found")(playerSlot) }
}
pub type _GetClientLeftVector = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientLeftVector: Option<_GetClientLeftVector> = None;

/// Get the right vector of the client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to query
///
/// # Returns - (vec3):
/// Right-facing direction vector of the client
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientRightVector(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientRightVector.expect("GetClientRightVector function was not found")(playerSlot) }
}
pub type _GetClientRightVector = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientRightVector: Option<_GetClientRightVector> = None;

/// Get the up vector of the client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to query
///
/// # Returns - (vec3):
/// Up-facing direction vector of the client
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientUpVector(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientUpVector.expect("GetClientUpVector function was not found")(playerSlot) }
}
pub type _GetClientUpVector = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientUpVector: Option<_GetClientUpVector> = None;

/// Get the client-to-world transformation matrix.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to query
///
/// # Returns - (mat4x4):
/// 4x4 transformation matrix representing client's position, rotation, and scale in world space
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientTransform(playerSlot: i32) -> Mat4x4 {
    unsafe { __s2sdk_GetClientTransform.expect("GetClientTransform function was not found")(playerSlot) }
}
pub type _GetClientTransform = unsafe extern "C" fn(i32) -> Mat4x4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientTransform: Option<_GetClientTransform> = None;

/// Retrieves the model name of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose model name is to be retrieved.
///
/// # Returns - (string):
/// A string where the model name will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientModel(playerSlot: i32) -> Str {
    unsafe { __s2sdk_GetClientModel.expect("GetClientModel function was not found")(playerSlot) }
}
pub type _GetClientModel = unsafe extern "C" fn(i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientModel: Option<_GetClientModel> = None;

/// Sets the model name of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose model name is to be set.
/// * `model` - (string): The new model name to set for the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientModel(playerSlot: i32, model: &Str) {
    unsafe { __s2sdk_SetClientModel.expect("SetClientModel function was not found")(playerSlot, model) }
}
pub type _SetClientModel = unsafe extern "C" fn(i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientModel: Option<_SetClientModel> = None;

/// Retrieves the water level of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose water level is to be retrieved.
///
/// # Returns - (float):
/// The water level of the client, or 0.0f if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientWaterLevel(playerSlot: i32) -> f32 {
    unsafe { __s2sdk_GetClientWaterLevel.expect("GetClientWaterLevel function was not found")(playerSlot) }
}
pub type _GetClientWaterLevel = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientWaterLevel: Option<_GetClientWaterLevel> = None;

/// Retrieves the ground client of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose ground client is to be retrieved.
///
/// # Returns - (int32):
/// The handle of the ground client, or INVALID_EHANDLE_INDEX if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientGroundEntity(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientGroundEntity.expect("GetClientGroundEntity function was not found")(playerSlot) }
}
pub type _GetClientGroundEntity = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientGroundEntity: Option<_GetClientGroundEntity> = None;

/// Retrieves the effects of an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot whose effects are to be retrieved.
///
/// # Returns - (int32):
/// The effect flags of the client, or 0 if the client is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientEffects(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientEffects.expect("GetClientEffects function was not found")(playerSlot) }
}
pub type _GetClientEffects = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientEffects: Option<_GetClientEffects> = None;

/// Adds the render effect flag to an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to modify
/// * `effects` - (int32): Render effect flags to add
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AddClientEffects(playerSlot: i32, effects: i32) {
    unsafe { __s2sdk_AddClientEffects.expect("AddClientEffects function was not found")(playerSlot, effects) }
}
pub type _AddClientEffects = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AddClientEffects: Option<_AddClientEffects> = None;

/// Removes the render effect flag from an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to modify
/// * `effects` - (int32): Render effect flags to remove
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RemoveClientEffects(playerSlot: i32, effects: i32) {
    unsafe { __s2sdk_RemoveClientEffects.expect("RemoveClientEffects function was not found")(playerSlot, effects) }
}
pub type _RemoveClientEffects = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RemoveClientEffects: Option<_RemoveClientEffects> = None;

/// Get a vector containing max bounds, centered on object.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to query
///
/// # Returns - (vec3):
/// Vector containing the maximum bounds of the client's bounding box
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientBoundingMaxs(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientBoundingMaxs.expect("GetClientBoundingMaxs function was not found")(playerSlot) }
}
pub type _GetClientBoundingMaxs = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientBoundingMaxs: Option<_GetClientBoundingMaxs> = None;

/// Get a vector containing min bounds, centered on object.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to query
///
/// # Returns - (vec3):
/// Vector containing the minimum bounds of the client's bounding box
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientBoundingMins(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientBoundingMins.expect("GetClientBoundingMins function was not found")(playerSlot) }
}
pub type _GetClientBoundingMins = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientBoundingMins: Option<_GetClientBoundingMins> = None;

/// Get vector to center of object - absolute coords.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to query
///
/// # Returns - (vec3):
/// Vector pointing to the center of the client in absolute/world coordinates
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientCenter(playerSlot: i32) -> Vec3 {
    unsafe { __s2sdk_GetClientCenter.expect("GetClientCenter function was not found")(playerSlot) }
}
pub type _GetClientCenter = unsafe extern "C" fn(i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientCenter: Option<_GetClientCenter> = None;

/// Teleports an client to a specified location and orientation.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to teleport.
/// * `origin` - (vec3): A pointer to a Vector representing the new absolute position. Use nan vector to not set.
/// * `angles` - (vec3): A pointer to a QAngle representing the new orientation. Use nan vector to not set.
/// * `velocity` - (vec3): A pointer to a Vector representing the new velocity. Use nan vector to not set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TeleportClient(playerSlot: i32, origin: &Vec3, angles: &Vec3, velocity: &Vec3) {
    unsafe { __s2sdk_TeleportClient.expect("TeleportClient function was not found")(playerSlot, origin, angles, velocity) }
}
pub type _TeleportClient = unsafe extern "C" fn(i32, &Vec3, &Vec3, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TeleportClient: Option<_TeleportClient> = None;

/// Apply an absolute velocity impulse to an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to apply impulse to
/// * `vecImpulse` - (vec3): Velocity impulse vector to apply
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ApplyAbsVelocityImpulseToClient(playerSlot: i32, vecImpulse: &Vec3) {
    unsafe { __s2sdk_ApplyAbsVelocityImpulseToClient.expect("ApplyAbsVelocityImpulseToClient function was not found")(playerSlot, vecImpulse) }
}
pub type _ApplyAbsVelocityImpulseToClient = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ApplyAbsVelocityImpulseToClient: Option<_ApplyAbsVelocityImpulseToClient> = None;

/// Apply a local angular velocity impulse to an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to apply impulse to
/// * `angImpulse` - (vec3): Angular velocity impulse vector to apply
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ApplyLocalAngularVelocityImpulseToClient(playerSlot: i32, angImpulse: &Vec3) {
    unsafe { __s2sdk_ApplyLocalAngularVelocityImpulseToClient.expect("ApplyLocalAngularVelocityImpulseToClient function was not found")(playerSlot, angImpulse) }
}
pub type _ApplyLocalAngularVelocityImpulseToClient = unsafe extern "C" fn(i32, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ApplyLocalAngularVelocityImpulseToClient: Option<_ApplyLocalAngularVelocityImpulseToClient> = None;

/// Invokes a named input method on a specified client.
///
/// # Arguments
/// * `playerSlot` - (int32): The handle of the target client that will receive the input.
/// * `inputName` - (string): The name of the input action to invoke.
/// * `activatorHandle` - (int32): The index of the player's slot that initiated the sequence of actions.
/// * `callerHandle` - (int32): The index of the player's slot sending this event. Use -1 to specify
/// * `value` - (any): The value associated with the input action.
/// * `type_` - (int32): The type or classification of the value.
/// * `outputId` - (int32): An identifier for tracking the output of this operation.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AcceptClientInput(playerSlot: i32, inputName: &Str, activatorHandle: i32, callerHandle: i32, value: &Var, type_: FieldType, outputId: i32) {
    unsafe { __s2sdk_AcceptClientInput.expect("AcceptClientInput function was not found")(playerSlot, inputName, activatorHandle, callerHandle, value, type_, outputId) }
}
pub type _AcceptClientInput = unsafe extern "C" fn(i32, &Str, i32, i32, &Var, FieldType, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AcceptClientInput: Option<_AcceptClientInput> = None;

/// Connects a script function to an player output.
///
/// # Arguments
/// * `playerSlot` - (int32): The handle of the player.
/// * `output` - (string): The name of the output to connect to.
/// * `functionName` - (string): The name of the script function to call.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ConnectClientOutput(playerSlot: i32, output: &Str, functionName: &Str) {
    unsafe { __s2sdk_ConnectClientOutput.expect("ConnectClientOutput function was not found")(playerSlot, output, functionName) }
}
pub type _ConnectClientOutput = unsafe extern "C" fn(i32, &Str, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ConnectClientOutput: Option<_ConnectClientOutput> = None;

/// Disconnects a script function from an player output.
///
/// # Arguments
/// * `playerSlot` - (int32): The handle of the player.
/// * `output` - (string): The name of the output.
/// * `functionName` - (string): The name of the script function to disconnect.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DisconnectClientOutput(playerSlot: i32, output: &Str, functionName: &Str) {
    unsafe { __s2sdk_DisconnectClientOutput.expect("DisconnectClientOutput function was not found")(playerSlot, output, functionName) }
}
pub type _DisconnectClientOutput = unsafe extern "C" fn(i32, &Str, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DisconnectClientOutput: Option<_DisconnectClientOutput> = None;

/// Disconnects a script function from an I/O event on a different player.
///
/// # Arguments
/// * `playerSlot` - (int32): The handle of the calling player.
/// * `output` - (string): The name of the output.
/// * `functionName` - (string): The function name to disconnect.
/// * `targetHandle` - (int32): The handle of the entity whose output is being disconnected.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DisconnectClientRedirectedOutput(playerSlot: i32, output: &Str, functionName: &Str, targetHandle: i32) {
    unsafe { __s2sdk_DisconnectClientRedirectedOutput.expect("DisconnectClientRedirectedOutput function was not found")(playerSlot, output, functionName, targetHandle) }
}
pub type _DisconnectClientRedirectedOutput = unsafe extern "C" fn(i32, &Str, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DisconnectClientRedirectedOutput: Option<_DisconnectClientRedirectedOutput> = None;

/// Fires an player output.
///
/// # Arguments
/// * `playerSlot` - (int32): The handle of the player firing the output.
/// * `outputName` - (string): The name of the output to fire.
/// * `activatorHandle` - (int32): The entity activating the output.
/// * `callerHandle` - (int32): The entity that called the output.
/// * `value` - (any): The value associated with the input action.
/// * `type_` - (int32): The type or classification of the value.
/// * `delay` - (float): Delay in seconds before firing the output.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FireClientOutput(playerSlot: i32, outputName: &Str, activatorHandle: i32, callerHandle: i32, value: &Var, type_: FieldType, delay: f32) {
    unsafe { __s2sdk_FireClientOutput.expect("FireClientOutput function was not found")(playerSlot, outputName, activatorHandle, callerHandle, value, type_, delay) }
}
pub type _FireClientOutput = unsafe extern "C" fn(i32, &Str, i32, i32, &Var, FieldType, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FireClientOutput: Option<_FireClientOutput> = None;

/// Redirects an player output to call a function on another player.
///
/// # Arguments
/// * `playerSlot` - (int32): The handle of the player whose output is being redirected.
/// * `output` - (string): The name of the output to redirect.
/// * `functionName` - (string): The function name to call on the target player.
/// * `targetHandle` - (int32): The handle of the entity that will receive the output call.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RedirectClientOutput(playerSlot: i32, output: &Str, functionName: &Str, targetHandle: i32) {
    unsafe { __s2sdk_RedirectClientOutput.expect("RedirectClientOutput function was not found")(playerSlot, output, functionName, targetHandle) }
}
pub type _RedirectClientOutput = unsafe extern "C" fn(i32, &Str, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RedirectClientOutput: Option<_RedirectClientOutput> = None;

/// Makes an client follow another client with optional bone merging.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot that will follow
/// * `attachmentHandle` - (int32): The index of the player's slot to follow
/// * `boneMerge` - (bool): If true, bones will be merged between entities
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FollowClient(playerSlot: i32, attachmentHandle: i32, boneMerge: bool) {
    unsafe { __s2sdk_FollowClient.expect("FollowClient function was not found")(playerSlot, attachmentHandle, boneMerge) }
}
pub type _FollowClient = unsafe extern "C" fn(i32, i32, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FollowClient: Option<_FollowClient> = None;

/// Makes an client follow another client and merge with a specific bone or attachment.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot that will follow
/// * `attachmentHandle` - (int32): The index of the player's slot to follow
/// * `boneOrAttachName` - (string): Name of the bone or attachment point to merge with
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn FollowClientMerge(playerSlot: i32, attachmentHandle: i32, boneOrAttachName: &Str) {
    unsafe { __s2sdk_FollowClientMerge.expect("FollowClientMerge function was not found")(playerSlot, attachmentHandle, boneOrAttachName) }
}
pub type _FollowClientMerge = unsafe extern "C" fn(i32, i32, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_FollowClientMerge: Option<_FollowClientMerge> = None;

/// Apply damage to an client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot receiving damage
/// * `inflictorSlot` - (int32): The index of the player's slot inflicting damage (e.g., projectile)
/// * `attackerSlot` - (int32): The index of the attacking client
/// * `force` - (vec3): Direction and magnitude of force to apply
/// * `hitPos` - (vec3): Position where the damage hit occurred
/// * `damage` - (float): Amount of damage to apply
/// * `damageTypes` - (int32): Bitfield of damage type flags
///
/// # Returns - (int32):
/// Amount of damage actually applied to the client
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TakeClientDamage(playerSlot: i32, inflictorSlot: i32, attackerSlot: i32, force: &Vec3, hitPos: &Vec3, damage: f32, damageTypes: DamageTypes) -> i32 {
    unsafe { __s2sdk_TakeClientDamage.expect("TakeClientDamage function was not found")(playerSlot, inflictorSlot, attackerSlot, force, hitPos, damage, damageTypes) }
}
pub type _TakeClientDamage = unsafe extern "C" fn(i32, i32, i32, &Vec3, &Vec3, f32, DamageTypes) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TakeClientDamage: Option<_TakeClientDamage> = None;

/// Retrieves the pawn entity pointer associated with a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (ptr64):
/// A pointer to the client's pawn entity, or nullptr if the client or controller is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientPawn(playerSlot: i32) -> usize {
    unsafe { __s2sdk_GetClientPawn.expect("GetClientPawn function was not found")(playerSlot) }
}
pub type _GetClientPawn = unsafe extern "C" fn(i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientPawn: Option<_GetClientPawn> = None;

/// Processes the target string to determine if one user can target another.
///
/// # Arguments
/// * `caller` - (int32): The index of the player's slot making the target request.
/// * `target` - (string): The target string specifying the player or players to be targeted.
///
/// # Returns - (int32[]):
/// A vector where the result of the targeting operation will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ProcessTargetString(caller: i32, target: &Str) -> Arr<i32> {
    unsafe { __s2sdk_ProcessTargetString.expect("ProcessTargetString function was not found")(caller, target) }
}
pub type _ProcessTargetString = unsafe extern "C" fn(i32, &Str) -> Arr<i32>;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ProcessTargetString: Option<_ProcessTargetString> = None;

/// Switches the player's team.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `team` - (int32): The team index to switch the client to.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SwitchClientTeam(playerSlot: i32, team: CSTeam) {
    unsafe { __s2sdk_SwitchClientTeam.expect("SwitchClientTeam function was not found")(playerSlot, team) }
}
pub type _SwitchClientTeam = unsafe extern "C" fn(i32, CSTeam);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SwitchClientTeam: Option<_SwitchClientTeam> = None;

/// Respawns a player.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to respawn.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RespawnClient(playerSlot: i32) {
    unsafe { __s2sdk_RespawnClient.expect("RespawnClient function was not found")(playerSlot) }
}
pub type _RespawnClient = unsafe extern "C" fn(i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RespawnClient: Option<_RespawnClient> = None;

/// Forces a player to commit suicide.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `explode` - (bool): If true, the client will explode upon death.
/// * `force` - (bool): If true, the suicide will be forced.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ForcePlayerSuicide(playerSlot: i32, explode: bool, force: bool) {
    unsafe { __s2sdk_ForcePlayerSuicide.expect("ForcePlayerSuicide function was not found")(playerSlot, explode, force) }
}
pub type _ForcePlayerSuicide = unsafe extern "C" fn(i32, bool, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ForcePlayerSuicide: Option<_ForcePlayerSuicide> = None;

/// Disconnects a client from the server as soon as the next frame starts.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to be kicked.
/// * `reason` - (int32): The network-level reason code describing why the client is being disconnected.
/// * `message` - (string): The optional internal diagnostic message. If empty, no message is passed to the engine.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn KickClient(playerSlot: i32, reason: NetworkDisconnectionReason, message: &Str) {
    unsafe { __s2sdk_KickClient.expect("KickClient function was not found")(playerSlot, reason, message) }
}
pub type _KickClient = unsafe extern "C" fn(i32, NetworkDisconnectionReason, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_KickClient: Option<_KickClient> = None;

/// Bans a client for a specified duration.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot to be banned.
/// * `duration` - (float): Duration of the ban in seconds.
/// * `kick` - (bool): If true, the client will be kicked immediately after being banned.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn BanClient(playerSlot: i32, duration: f32, kick: bool) {
    unsafe { __s2sdk_BanClient.expect("BanClient function was not found")(playerSlot, duration, kick) }
}
pub type _BanClient = unsafe extern "C" fn(i32, f32, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_BanClient: Option<_BanClient> = None;

/// Bans an identity (either an IP address or a Steam authentication string).
///
/// # Arguments
/// * `steamId` - (uint64): The Steam ID to ban.
/// * `duration` - (float): Duration of the ban in seconds.
/// * `kick` - (bool): If true, the client will be kicked immediately after being banned.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn BanIdentity(steamId: u64, duration: f32, kick: bool) {
    unsafe { __s2sdk_BanIdentity.expect("BanIdentity function was not found")(steamId, duration, kick) }
}
pub type _BanIdentity = unsafe extern "C" fn(u64, f32, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_BanIdentity: Option<_BanIdentity> = None;

/// Retrieves the handle of the client's currently active weapon.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (int32):
/// The entity handle of the active weapon, or INVALID_EHANDLE_INDEX if the client is invalid or has no active weapon.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientActiveWeapon(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientActiveWeapon.expect("GetClientActiveWeapon function was not found")(playerSlot) }
}
pub type _GetClientActiveWeapon = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientActiveWeapon: Option<_GetClientActiveWeapon> = None;

/// Retrieves a list of weapon handles owned by the client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (int32[]):
/// A vector of entity handles for the client's weapons, or an empty vector if the client is invalid or has no weapons.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientWeapons(playerSlot: i32) -> Arr<i32> {
    unsafe { __s2sdk_GetClientWeapons.expect("GetClientWeapons function was not found")(playerSlot) }
}
pub type _GetClientWeapons = unsafe extern "C" fn(i32) -> Arr<i32>;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientWeapons: Option<_GetClientWeapons> = None;

/// Removes all weapons from a client, with an option to remove the suit as well.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `removeSuit` - (bool): A boolean indicating whether to also remove the client's suit.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RemoveWeapons(playerSlot: i32, removeSuit: bool) {
    unsafe { __s2sdk_RemoveWeapons.expect("RemoveWeapons function was not found")(playerSlot, removeSuit) }
}
pub type _RemoveWeapons = unsafe extern "C" fn(i32, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RemoveWeapons: Option<_RemoveWeapons> = None;

/// Forces a player to drop their weapon.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `weaponHandle` - (int32): The handle of weapon to drop.
/// * `target` - (vec3): Target direction.
/// * `velocity` - (vec3): Velocity to toss weapon or zero to just drop weapon.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn DropWeapon(playerSlot: i32, weaponHandle: i32, target: &Vec3, velocity: &Vec3) {
    unsafe { __s2sdk_DropWeapon.expect("DropWeapon function was not found")(playerSlot, weaponHandle, target, velocity) }
}
pub type _DropWeapon = unsafe extern "C" fn(i32, i32, &Vec3, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_DropWeapon: Option<_DropWeapon> = None;

/// Selects a player's weapon.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `weaponHandle` - (int32): The handle of weapon to bump.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SelectWeapon(playerSlot: i32, weaponHandle: i32) {
    unsafe { __s2sdk_SelectWeapon.expect("SelectWeapon function was not found")(playerSlot, weaponHandle) }
}
pub type _SelectWeapon = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SelectWeapon: Option<_SelectWeapon> = None;

/// Switches a player's weapon.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `weaponHandle` - (int32): The handle of weapon to switch.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SwitchWeapon(playerSlot: i32, weaponHandle: i32) {
    unsafe { __s2sdk_SwitchWeapon.expect("SwitchWeapon function was not found")(playerSlot, weaponHandle) }
}
pub type _SwitchWeapon = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SwitchWeapon: Option<_SwitchWeapon> = None;

/// Removes a player's weapon.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `weaponHandle` - (int32): The handle of weapon to remove.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RemoveWeapon(playerSlot: i32, weaponHandle: i32) {
    unsafe { __s2sdk_RemoveWeapon.expect("RemoveWeapon function was not found")(playerSlot, weaponHandle) }
}
pub type _RemoveWeapon = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RemoveWeapon: Option<_RemoveWeapon> = None;

/// Gives a named item (e.g., weapon) to a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `itemName` - (string): The name of the item to give.
///
/// # Returns - (int32):
/// The entity handle of the created item, or INVALID_EHANDLE_INDEX if the client or item is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GiveNamedItem(playerSlot: i32, itemName: &Str) -> i32 {
    unsafe { __s2sdk_GiveNamedItem.expect("GiveNamedItem function was not found")(playerSlot, itemName) }
}
pub type _GiveNamedItem = unsafe extern "C" fn(i32, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GiveNamedItem: Option<_GiveNamedItem> = None;

/// Retrieves the state of a specific button for a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `buttonIndex` - (int32): The index of the button (0-2).
///
/// # Returns - (uint64):
/// uint64_t The state of the specified button, or 0 if the client or button index is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientButtons(playerSlot: i32, buttonIndex: i32) -> u64 {
    unsafe { __s2sdk_GetClientButtons.expect("GetClientButtons function was not found")(playerSlot, buttonIndex) }
}
pub type _GetClientButtons = unsafe extern "C" fn(i32, i32) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientButtons: Option<_GetClientButtons> = None;

/// Returns the client's armor value.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (int32):
/// The armor value of the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientArmor(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientArmor.expect("GetClientArmor function was not found")(playerSlot) }
}
pub type _GetClientArmor = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientArmor: Option<_GetClientArmor> = None;

/// Sets the client's armor value.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `armor` - (int32): The armor value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientArmor(playerSlot: i32, armor: i32) {
    unsafe { __s2sdk_SetClientArmor.expect("SetClientArmor function was not found")(playerSlot, armor) }
}
pub type _SetClientArmor = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientArmor: Option<_SetClientArmor> = None;

/// Returns the client's speed value.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (float):
/// The speed value of the client.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientSpeed(playerSlot: i32) -> f32 {
    unsafe { __s2sdk_GetClientSpeed.expect("GetClientSpeed function was not found")(playerSlot) }
}
pub type _GetClientSpeed = unsafe extern "C" fn(i32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientSpeed: Option<_GetClientSpeed> = None;

/// Sets the client's speed value.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `speed` - (float): The speed value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientSpeed(playerSlot: i32, speed: f32) {
    unsafe { __s2sdk_SetClientSpeed.expect("SetClientSpeed function was not found")(playerSlot, speed) }
}
pub type _SetClientSpeed = unsafe extern "C" fn(i32, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientSpeed: Option<_SetClientSpeed> = None;

/// Retrieves the amount of money a client has.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (int32):
/// The amount of money the client has, or 0 if the player slot is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientMoney(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientMoney.expect("GetClientMoney function was not found")(playerSlot) }
}
pub type _GetClientMoney = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientMoney: Option<_GetClientMoney> = None;

/// Sets the amount of money for a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `money` - (int32): The amount of money to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientMoney(playerSlot: i32, money: i32) {
    unsafe { __s2sdk_SetClientMoney.expect("SetClientMoney function was not found")(playerSlot, money) }
}
pub type _SetClientMoney = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientMoney: Option<_SetClientMoney> = None;

/// Retrieves the number of kills for a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (int32):
/// The number of kills the client has, or 0 if the player slot is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientKills(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientKills.expect("GetClientKills function was not found")(playerSlot) }
}
pub type _GetClientKills = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientKills: Option<_GetClientKills> = None;

/// Sets the number of kills for a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `kills` - (int32): The number of kills to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientKills(playerSlot: i32, kills: i32) {
    unsafe { __s2sdk_SetClientKills.expect("SetClientKills function was not found")(playerSlot, kills) }
}
pub type _SetClientKills = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientKills: Option<_SetClientKills> = None;

/// Retrieves the number of deaths for a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (int32):
/// The number of deaths the client has, or 0 if the player slot is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientDeaths(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientDeaths.expect("GetClientDeaths function was not found")(playerSlot) }
}
pub type _GetClientDeaths = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientDeaths: Option<_GetClientDeaths> = None;

/// Sets the number of deaths for a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `deaths` - (int32): The number of deaths to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientDeaths(playerSlot: i32, deaths: i32) {
    unsafe { __s2sdk_SetClientDeaths.expect("SetClientDeaths function was not found")(playerSlot, deaths) }
}
pub type _SetClientDeaths = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientDeaths: Option<_SetClientDeaths> = None;

/// Retrieves the number of assists for a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (int32):
/// The number of assists the client has, or 0 if the player slot is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientAssists(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientAssists.expect("GetClientAssists function was not found")(playerSlot) }
}
pub type _GetClientAssists = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientAssists: Option<_GetClientAssists> = None;

/// Sets the number of assists for a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `assists` - (int32): The number of assists to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientAssists(playerSlot: i32, assists: i32) {
    unsafe { __s2sdk_SetClientAssists.expect("SetClientAssists function was not found")(playerSlot, assists) }
}
pub type _SetClientAssists = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientAssists: Option<_SetClientAssists> = None;

/// Retrieves the total damage dealt by a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
///
/// # Returns - (int32):
/// The total damage dealt by the client, or 0 if the player slot is invalid.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetClientDamage(playerSlot: i32) -> i32 {
    unsafe { __s2sdk_GetClientDamage.expect("GetClientDamage function was not found")(playerSlot) }
}
pub type _GetClientDamage = unsafe extern "C" fn(i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetClientDamage: Option<_GetClientDamage> = None;

/// Sets the total damage dealt by a client.
///
/// # Arguments
/// * `playerSlot` - (int32): The index of the player's slot.
/// * `damage` - (int32): The amount of damage to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetClientDamage(playerSlot: i32, damage: i32) {
    unsafe { __s2sdk_SetClientDamage.expect("SetClientDamage function was not found")(playerSlot, damage) }
}
pub type _SetClientDamage = unsafe extern "C" fn(i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetClientDamage: Option<_SetClientDamage> = None;

