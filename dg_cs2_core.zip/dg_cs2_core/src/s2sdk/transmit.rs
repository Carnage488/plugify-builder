// Generated from s2sdk.pplugin (group: transmit)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Sets a bit in the TransmitEntity bitvec, marking an entity as transmittable.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The handle of the entity to mark as transmittable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetTransmitInfoEntity(info: usize, entityHandle: i32) {
    unsafe { __s2sdk_SetTransmitInfoEntity.expect("SetTransmitInfoEntity function was not found")(info, entityHandle) }
}
pub type _SetTransmitInfoEntity = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetTransmitInfoEntity: Option<_SetTransmitInfoEntity> = None;

/// Clears a bit in the TransmitEntity bitvec, marking an entity as not transmittable.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The handle of the entity to mark as not transmittable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ClearTransmitInfoEntity(info: usize, entityHandle: i32) {
    unsafe { __s2sdk_ClearTransmitInfoEntity.expect("ClearTransmitInfoEntity function was not found")(info, entityHandle) }
}
pub type _ClearTransmitInfoEntity = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ClearTransmitInfoEntity: Option<_ClearTransmitInfoEntity> = None;

/// Checks if a bit is set in the TransmitEntity bitvec.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The handle of the entity to check.
///
/// # Returns - (bool):
/// True if the entity is marked as transmittable, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsTransmitInfoEntitySet(info: usize, entityHandle: i32) -> bool {
    unsafe { __s2sdk_IsTransmitInfoEntitySet.expect("IsTransmitInfoEntitySet function was not found")(info, entityHandle) }
}
pub type _IsTransmitInfoEntitySet = unsafe extern "C" fn(usize, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsTransmitInfoEntitySet: Option<_IsTransmitInfoEntitySet> = None;

/// Sets all bits in the TransmitEntity bitvec, marking all entities as transmittable.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetTransmitInfoEntityAll(info: usize) {
    unsafe { __s2sdk_SetTransmitInfoEntityAll.expect("SetTransmitInfoEntityAll function was not found")(info) }
}
pub type _SetTransmitInfoEntityAll = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetTransmitInfoEntityAll: Option<_SetTransmitInfoEntityAll> = None;

/// Clears all bits in the TransmitEntity bitvec, marking all entities as not transmittable.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ClearTransmitInfoEntityAll(info: usize) {
    unsafe { __s2sdk_ClearTransmitInfoEntityAll.expect("ClearTransmitInfoEntityAll function was not found")(info) }
}
pub type _ClearTransmitInfoEntityAll = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ClearTransmitInfoEntityAll: Option<_ClearTransmitInfoEntityAll> = None;

/// Sets a bit in the TransmitNonPlayers bitvec, marking a non-player entity as transmittable.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The index of the non-player entity to mark as transmittable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetTransmitInfoNonPlayer(info: usize, entityHandle: i32) {
    unsafe { __s2sdk_SetTransmitInfoNonPlayer.expect("SetTransmitInfoNonPlayer function was not found")(info, entityHandle) }
}
pub type _SetTransmitInfoNonPlayer = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetTransmitInfoNonPlayer: Option<_SetTransmitInfoNonPlayer> = None;

/// Clears a bit in the TransmitNonPlayers bitvec, marking a non-player entity as not transmittable.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The index of the non-player entity to mark as not transmittable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ClearTransmitInfoNonPlayer(info: usize, entityHandle: i32) {
    unsafe { __s2sdk_ClearTransmitInfoNonPlayer.expect("ClearTransmitInfoNonPlayer function was not found")(info, entityHandle) }
}
pub type _ClearTransmitInfoNonPlayer = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ClearTransmitInfoNonPlayer: Option<_ClearTransmitInfoNonPlayer> = None;

/// Checks if a bit is set in the TransmitNonPlayers bitvec.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The index of the non-player entity to check.
///
/// # Returns - (bool):
/// True if the entity is marked as transmittable, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsTransmitInfoNonPlayerSet(info: usize, entityHandle: i32) -> bool {
    unsafe { __s2sdk_IsTransmitInfoNonPlayerSet.expect("IsTransmitInfoNonPlayerSet function was not found")(info, entityHandle) }
}
pub type _IsTransmitInfoNonPlayerSet = unsafe extern "C" fn(usize, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsTransmitInfoNonPlayerSet: Option<_IsTransmitInfoNonPlayerSet> = None;

/// Sets all bits in the TransmitNonPlayers bitvec, marking all non-player entities as transmittable.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetTransmitInfoNonPlayerAll(info: usize) {
    unsafe { __s2sdk_SetTransmitInfoNonPlayerAll.expect("SetTransmitInfoNonPlayerAll function was not found")(info) }
}
pub type _SetTransmitInfoNonPlayerAll = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetTransmitInfoNonPlayerAll: Option<_SetTransmitInfoNonPlayerAll> = None;

/// Clears all bits in the TransmitNonPlayers bitvec, marking all non-player entities as not transmittable.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ClearTransmitInfoNonPlayerAll(info: usize) {
    unsafe { __s2sdk_ClearTransmitInfoNonPlayerAll.expect("ClearTransmitInfoNonPlayerAll function was not found")(info) }
}
pub type _ClearTransmitInfoNonPlayerAll = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ClearTransmitInfoNonPlayerAll: Option<_ClearTransmitInfoNonPlayerAll> = None;

/// Sets a bit in the TransmitOutOfPVS bitvec, marking an entity to always transmit.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The handle of the entity to mark as always transmittable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetTransmitInfoOutOfPVS(info: usize, entityHandle: i32) {
    unsafe { __s2sdk_SetTransmitInfoOutOfPVS.expect("SetTransmitInfoOutOfPVS function was not found")(info, entityHandle) }
}
pub type _SetTransmitInfoOutOfPVS = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetTransmitInfoOutOfPVS: Option<_SetTransmitInfoOutOfPVS> = None;

/// Clears a bit in the TransmitOutOfPVS bitvec, unmarking an entity from always transmit.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The handle of the entity to unmark from always transmit.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ClearTransmitInfoOutOfPVS(info: usize, entityHandle: i32) {
    unsafe { __s2sdk_ClearTransmitInfoOutOfPVS.expect("ClearTransmitInfoOutOfPVS function was not found")(info, entityHandle) }
}
pub type _ClearTransmitInfoOutOfPVS = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ClearTransmitInfoOutOfPVS: Option<_ClearTransmitInfoOutOfPVS> = None;

/// Checks if a bit is set in the TransmitOutOfPVS bitvec.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The handle of the entity to check.
///
/// # Returns - (bool):
/// True if the entity is marked to always transmit, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsTransmitInfoOutOfPVSSet(info: usize, entityHandle: i32) -> bool {
    unsafe { __s2sdk_IsTransmitInfoOutOfPVSSet.expect("IsTransmitInfoOutOfPVSSet function was not found")(info, entityHandle) }
}
pub type _IsTransmitInfoOutOfPVSSet = unsafe extern "C" fn(usize, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsTransmitInfoOutOfPVSSet: Option<_IsTransmitInfoOutOfPVSSet> = None;

/// Sets all bits in the TransmitOutOfPVS bitvec, marking all entities to always transmit.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetTransmitInfoOutOfPVSAll(info: usize) {
    unsafe { __s2sdk_SetTransmitInfoOutOfPVSAll.expect("SetTransmitInfoOutOfPVSAll function was not found")(info) }
}
pub type _SetTransmitInfoOutOfPVSAll = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetTransmitInfoOutOfPVSAll: Option<_SetTransmitInfoOutOfPVSAll> = None;

/// Clears all bits in the TransmitOutOfPVS bitvec, unmarking all entities from always transmit.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ClearTransmitInfoOutOfPVSAll(info: usize) {
    unsafe { __s2sdk_ClearTransmitInfoOutOfPVSAll.expect("ClearTransmitInfoOutOfPVSAll function was not found")(info) }
}
pub type _ClearTransmitInfoOutOfPVSAll = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ClearTransmitInfoOutOfPVSAll: Option<_ClearTransmitInfoOutOfPVSAll> = None;

/// Sets a bit in the TransmitHLTV bitvec, marking an entity to always transmit.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The handle of the entity to mark as always transmittable.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetTransmitInfoHLTV(info: usize, entityHandle: i32) {
    unsafe { __s2sdk_SetTransmitInfoHLTV.expect("SetTransmitInfoHLTV function was not found")(info, entityHandle) }
}
pub type _SetTransmitInfoHLTV = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetTransmitInfoHLTV: Option<_SetTransmitInfoHLTV> = None;

/// Clears a bit in the TransmitHLTV bitvec, unmarking an entity from always transmit.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The handle of the entity to unmark from always transmit.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ClearTransmitInfoHLTV(info: usize, entityHandle: i32) {
    unsafe { __s2sdk_ClearTransmitInfoHLTV.expect("ClearTransmitInfoHLTV function was not found")(info, entityHandle) }
}
pub type _ClearTransmitInfoHLTV = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ClearTransmitInfoHLTV: Option<_ClearTransmitInfoHLTV> = None;

/// Checks if a bit is set in the TransmitHLTV bitvec.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `entityHandle` - (int32): The handle of the entity to check.
///
/// # Returns - (bool):
/// True if the entity is marked to always transmit, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsTransmitInfoHLTVSet(info: usize, entityHandle: i32) -> bool {
    unsafe { __s2sdk_IsTransmitInfoHLTVSet.expect("IsTransmitInfoHLTVSet function was not found")(info, entityHandle) }
}
pub type _IsTransmitInfoHLTVSet = unsafe extern "C" fn(usize, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsTransmitInfoHLTVSet: Option<_IsTransmitInfoHLTVSet> = None;

/// Sets all bits in the TransmitHLTV bitvec, marking all entities to always transmit.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetTransmitInfoHLTVAll(info: usize) {
    unsafe { __s2sdk_SetTransmitInfoHLTVAll.expect("SetTransmitInfoHLTVAll function was not found")(info) }
}
pub type _SetTransmitInfoHLTVAll = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetTransmitInfoHLTVAll: Option<_SetTransmitInfoHLTVAll> = None;

/// Clears all bits in the TransmitHLTV bitvec, unmarking all entities from always transmit.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ClearTransmitInfoHLTVAll(info: usize) {
    unsafe { __s2sdk_ClearTransmitInfoHLTVAll.expect("ClearTransmitInfoHLTVAll function was not found")(info) }
}
pub type _ClearTransmitInfoHLTVAll = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ClearTransmitInfoHLTVAll: Option<_ClearTransmitInfoHLTVAll> = None;

/// Gets the count of target player slots.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
///
/// # Returns - (int32):
/// The number of target player slots, or 0 if the info pointer is null.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetTransmitInfoTargetSlotsCount(info: usize) -> i32 {
    unsafe { __s2sdk_GetTransmitInfoTargetSlotsCount.expect("GetTransmitInfoTargetSlotsCount function was not found")(info) }
}
pub type _GetTransmitInfoTargetSlotsCount = unsafe extern "C" fn(usize) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetTransmitInfoTargetSlotsCount: Option<_GetTransmitInfoTargetSlotsCount> = None;

/// Gets a player slot value at a specific index in the target slots vector.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `index` - (int32): The index in the target slots vector.
///
/// # Returns - (int32):
/// The player slot value, or -1 if the index is invalid or info is null.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetTransmitInfoTargetSlot(info: usize, index: i32) -> i32 {
    unsafe { __s2sdk_GetTransmitInfoTargetSlot.expect("GetTransmitInfoTargetSlot function was not found")(info, index) }
}
pub type _GetTransmitInfoTargetSlot = unsafe extern "C" fn(usize, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetTransmitInfoTargetSlot: Option<_GetTransmitInfoTargetSlot> = None;

/// Adds a player slot to the target slots vector.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `playerSlot` - (int32): The player slot value to add.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn AddTransmitInfoTargetSlot(info: usize, playerSlot: i32) {
    unsafe { __s2sdk_AddTransmitInfoTargetSlot.expect("AddTransmitInfoTargetSlot function was not found")(info, playerSlot) }
}
pub type _AddTransmitInfoTargetSlot = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_AddTransmitInfoTargetSlot: Option<_AddTransmitInfoTargetSlot> = None;

/// Removes a player slot from the target slots vector.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `index` - (int32): Index within the target slots vector to remove.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RemoveTransmitInfoTargetSlot(info: usize, index: i32) {
    unsafe { __s2sdk_RemoveTransmitInfoTargetSlot.expect("RemoveTransmitInfoTargetSlot function was not found")(info, index) }
}
pub type _RemoveTransmitInfoTargetSlot = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RemoveTransmitInfoTargetSlot: Option<_RemoveTransmitInfoTargetSlot> = None;

/// Gets the target slots vector.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
///
/// # Returns - (int32[]):
/// The player slots array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetTransmitInfoTargetSlotsAll(info: usize) -> Arr<i32> {
    unsafe { __s2sdk_GetTransmitInfoTargetSlotsAll.expect("GetTransmitInfoTargetSlotsAll function was not found")(info) }
}
pub type _GetTransmitInfoTargetSlotsAll = unsafe extern "C" fn(usize) -> Arr<i32>;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetTransmitInfoTargetSlotsAll: Option<_GetTransmitInfoTargetSlotsAll> = None;

/// Clears all target player slots from the vector.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn RemoveTransmitInfoTargetSlotsAll(info: usize) {
    unsafe { __s2sdk_RemoveTransmitInfoTargetSlotsAll.expect("RemoveTransmitInfoTargetSlotsAll function was not found")(info) }
}
pub type _RemoveTransmitInfoTargetSlotsAll = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_RemoveTransmitInfoTargetSlotsAll: Option<_RemoveTransmitInfoTargetSlotsAll> = None;

/// Gets the player slot value from the CCheckTransmitInfo.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
///
/// # Returns - (int32):
/// The player slot value, or -1 if info is null.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetTransmitInfoPlayerSlot(info: usize) -> i32 {
    unsafe { __s2sdk_GetTransmitInfoPlayerSlot.expect("GetTransmitInfoPlayerSlot function was not found")(info) }
}
pub type _GetTransmitInfoPlayerSlot = unsafe extern "C" fn(usize) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetTransmitInfoPlayerSlot: Option<_GetTransmitInfoPlayerSlot> = None;

/// Sets the player slot value in the CCheckTransmitInfo.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `playerSlot` - (int32): The player slot value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetTransmitInfoPlayerSlot(info: usize, playerSlot: i32) {
    unsafe { __s2sdk_SetTransmitInfoPlayerSlot.expect("SetTransmitInfoPlayerSlot function was not found")(info, playerSlot) }
}
pub type _SetTransmitInfoPlayerSlot = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetTransmitInfoPlayerSlot: Option<_SetTransmitInfoPlayerSlot> = None;

/// Gets the full update flag from the CCheckTransmitInfo.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
///
/// # Returns - (bool):
/// True if full update is enabled, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetTransmitInfoFullUpdate(info: usize) -> bool {
    unsafe { __s2sdk_GetTransmitInfoFullUpdate.expect("GetTransmitInfoFullUpdate function was not found")(info) }
}
pub type _GetTransmitInfoFullUpdate = unsafe extern "C" fn(usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetTransmitInfoFullUpdate: Option<_GetTransmitInfoFullUpdate> = None;

/// Sets the full update flag in the CCheckTransmitInfo.
///
/// # Arguments
/// * `info` - (ptr64): Pointer to the CCheckTransmitInfo structure.
/// * `fullUpdate` - (bool): The full update flag value to set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetTransmitInfoFullUpdate(info: usize, fullUpdate: bool) {
    unsafe { __s2sdk_SetTransmitInfoFullUpdate.expect("SetTransmitInfoFullUpdate function was not found")(info, fullUpdate) }
}
pub type _SetTransmitInfoFullUpdate = unsafe extern "C" fn(usize, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetTransmitInfoFullUpdate: Option<_SetTransmitInfoFullUpdate> = None;

