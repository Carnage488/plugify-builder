// Generated from s2sdk.pplugin (group: trace)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Performs a collideable trace using the VScript-compatible table call, exposing it through C++ exports.
///
/// # Arguments
/// * `start` - (vec3): Trace start position (world space)
/// * `end` - (vec3): Trace end position (world space)
/// * `entityHandle` - (int32): Entity handle of the collideable
/// * `outPos` - (vec3&): Output: position of impact
/// * `outFraction` - (double&): Output: fraction of trace completed
/// * `outHit` - (bool&): Output: whether a hit occurred
/// * `outStartSolid` - (bool&): Output: whether trace started inside solid
/// * `outNormal` - (vec3&): Output: surface normal at impact
///
/// # Returns - (bool):
/// True if trace hit something, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TraceCollideable(start: &Vec3, end: &Vec3, entityHandle: i32, outPos: &mut Vec3, outFraction: &mut f64, outHit: &mut bool, outStartSolid: &mut bool, outNormal: &mut Vec3) -> bool {
    unsafe { __s2sdk_TraceCollideable.expect("TraceCollideable function was not found")(start, end, entityHandle, outPos, outFraction, outHit, outStartSolid, outNormal) }
}
pub type _TraceCollideable = unsafe extern "C" fn(&Vec3, &Vec3, i32, &mut Vec3, &mut f64, &mut bool, &mut bool, &mut Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TraceCollideable: Option<_TraceCollideable> = None;

/// Performs a collideable trace using the VScript-compatible table call, exposing it through C++ exports.
///
/// # Arguments
/// * `start` - (vec3): Trace start position (world space)
/// * `end` - (vec3): Trace end position (world space)
/// * `entityHandle` - (int32): Entity handle of the collideable
/// * `mins` - (ptr64): Bounding box minimums
/// * `maxs` - (ptr64): Bounding box maximums
/// * `outPos` - (vec3&): Output: position of impact
/// * `outFraction` - (double&): Output: fraction of trace completed
/// * `outHit` - (bool&): Output: whether a hit occurred
/// * `outStartSolid` - (bool&): Output: whether trace started inside solid
/// * `outNormal` - (vec3&): Output: surface normal at impact
///
/// # Returns - (bool):
/// True if trace hit something, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TraceCollideable2(start: &Vec3, end: &Vec3, entityHandle: i32, mins: usize, maxs: usize, outPos: &mut Vec3, outFraction: &mut f64, outHit: &mut bool, outStartSolid: &mut bool, outNormal: &mut Vec3) -> bool {
    unsafe { __s2sdk_TraceCollideable2.expect("TraceCollideable2 function was not found")(start, end, entityHandle, mins, maxs, outPos, outFraction, outHit, outStartSolid, outNormal) }
}
pub type _TraceCollideable2 = unsafe extern "C" fn(&Vec3, &Vec3, i32, usize, usize, &mut Vec3, &mut f64, &mut bool, &mut bool, &mut Vec3) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TraceCollideable2: Option<_TraceCollideable2> = None;

/// Performs a hull trace with specified dimensions and mask.
///
/// # Arguments
/// * `start` - (vec3): Trace start position
/// * `end` - (vec3): Trace end position
/// * `min` - (vec3): Local bounding box minimums
/// * `max` - (vec3): Local bounding box maximums
/// * `mask` - (int32): Trace mask
/// * `ignoreHandle` - (int32): Entity handle to ignore during trace
/// * `outPos` - (vec3&): Output: position of impact
/// * `outFraction` - (double&): Output: fraction of trace completed
/// * `outHit` - (bool&): Output: whether a hit occurred
/// * `outEntHit` - (int32&): Output: handle of entity hit
/// * `outStartSolid` - (bool&): Output: whether trace started inside solid
///
/// # Returns - (bool):
/// True if trace hit something, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TraceHull(start: &Vec3, end: &Vec3, min: &Vec3, max: &Vec3, mask: i32, ignoreHandle: i32, outPos: &mut Vec3, outFraction: &mut f64, outHit: &mut bool, outEntHit: &mut i32, outStartSolid: &mut bool) -> bool {
    unsafe { __s2sdk_TraceHull.expect("TraceHull function was not found")(start, end, min, max, mask, ignoreHandle, outPos, outFraction, outHit, outEntHit, outStartSolid) }
}
pub type _TraceHull = unsafe extern "C" fn(&Vec3, &Vec3, &Vec3, &Vec3, i32, i32, &mut Vec3, &mut f64, &mut bool, &mut i32, &mut bool) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TraceHull: Option<_TraceHull> = None;

/// Performs a line trace between two points.
///
/// # Arguments
/// * `startPos` - (vec3): Trace start position
/// * `endPos` - (vec3): Trace end position
/// * `mask` - (int32): Trace mask
/// * `ignoreHandle` - (int32): Entity handle to ignore during trace
/// * `outPos` - (vec3&): Output: position of impact
/// * `outFraction` - (double&): Output: fraction of trace completed
/// * `outHit` - (bool&): Output: whether a hit occurred
/// * `outEntHit` - (int32&): Output: handle of entity hit
/// * `outStartSolid` - (bool&): Output: whether trace started inside solid
///
/// # Returns - (bool):
/// True if trace hit something, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn TraceLine(startPos: &Vec3, endPos: &Vec3, mask: i32, ignoreHandle: i32, outPos: &mut Vec3, outFraction: &mut f64, outHit: &mut bool, outEntHit: &mut i32, outStartSolid: &mut bool) -> bool {
    unsafe { __s2sdk_TraceLine.expect("TraceLine function was not found")(startPos, endPos, mask, ignoreHandle, outPos, outFraction, outHit, outEntHit, outStartSolid) }
}
pub type _TraceLine = unsafe extern "C" fn(&Vec3, &Vec3, i32, i32, &mut Vec3, &mut f64, &mut bool, &mut i32, &mut bool) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_TraceLine: Option<_TraceLine> = None;

