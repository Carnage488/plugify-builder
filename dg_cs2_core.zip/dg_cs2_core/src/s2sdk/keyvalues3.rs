// Generated from s2sdk.pplugin (group: keyvalues3)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Creates a new KeyValues3 object with specified type and subtype
///
/// # Arguments
/// * `type_` - (int32): The KV3 type enumeration value
/// * `subtype` - (int32): The KV3 subtype enumeration value
///
/// # Returns - (ptr64):
/// Pointer to the newly created KeyValues3 object
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3Create(type_: i32, subtype: i32) -> usize {
    unsafe { __s2sdk_Kv3Create.expect("Kv3Create function was not found")(type_, subtype) }
}
pub type _Kv3Create = unsafe extern "C" fn(i32, i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3Create: Option<_Kv3Create> = None;

/// Creates a new KeyValues3 object with cluster element, type, and subtype
///
/// # Arguments
/// * `cluster_elem` - (int32): The cluster element index
/// * `type_` - (int32): The KV3 type enumeration value
/// * `subtype` - (int32): The KV3 subtype enumeration value
///
/// # Returns - (ptr64):
/// Pointer to the newly created KeyValues3 object
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3CreateWithCluster(cluster_elem: i32, type_: i32, subtype: i32) -> usize {
    unsafe { __s2sdk_Kv3CreateWithCluster.expect("Kv3CreateWithCluster function was not found")(cluster_elem, type_, subtype) }
}
pub type _Kv3CreateWithCluster = unsafe extern "C" fn(i32, i32, i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3CreateWithCluster: Option<_Kv3CreateWithCluster> = None;

/// Creates a copy of an existing KeyValues3 object
///
/// # Arguments
/// * `other` - (ptr64): Pointer to the KeyValues3 object to copy
///
/// # Returns - (ptr64):
/// Pointer to the newly created copy, or nullptr if other is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3CreateCopy(other: usize) -> usize {
    unsafe { __s2sdk_Kv3CreateCopy.expect("Kv3CreateCopy function was not found")(other) }
}
pub type _Kv3CreateCopy = unsafe extern "C" fn(usize) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3CreateCopy: Option<_Kv3CreateCopy> = None;

/// Destroys a KeyValues3 object and frees its memory
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object to destroy
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3Destroy(kv: usize) {
    unsafe { __s2sdk_Kv3Destroy.expect("Kv3Destroy function was not found")(kv) }
}
pub type _Kv3Destroy = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3Destroy: Option<_Kv3Destroy> = None;

/// Copies data from another KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the destination KeyValues3 object
/// * `other` - (ptr64): Pointer to the source KeyValues3 object
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3CopyFrom(kv: usize, other: usize) {
    unsafe { __s2sdk_Kv3CopyFrom.expect("Kv3CopyFrom function was not found")(kv, other) }
}
pub type _Kv3CopyFrom = unsafe extern "C" fn(usize, usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3CopyFrom: Option<_Kv3CopyFrom> = None;

/// Overlays keys from another KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the destination KeyValues3 object
/// * `other` - (ptr64): Pointer to the source KeyValues3 object
/// * `depth` - (bool): Whether to perform a deep overlay
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3OverlayKeysFrom(kv: usize, other: usize, depth: bool) {
    unsafe { __s2sdk_Kv3OverlayKeysFrom.expect("Kv3OverlayKeysFrom function was not found")(kv, other, depth) }
}
pub type _Kv3OverlayKeysFrom = unsafe extern "C" fn(usize, usize, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3OverlayKeysFrom: Option<_Kv3OverlayKeysFrom> = None;

/// Gets the context associated with a KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (ptr64):
/// Pointer to the CKV3Arena, or nullptr if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetContext(kv: usize) -> usize {
    unsafe { __s2sdk_Kv3GetContext.expect("Kv3GetContext function was not found")(kv) }
}
pub type _Kv3GetContext = unsafe extern "C" fn(usize) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetContext: Option<_Kv3GetContext> = None;

/// Gets the metadata associated with a KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `ppCtx` - (ptr64): Pointer to store the context pointer
///
/// # Returns - (ptr64):
/// Pointer to the KV3MetaData_t structure, or nullptr if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMetaData(kv: usize, ppCtx: usize) -> usize {
    unsafe { __s2sdk_Kv3GetMetaData.expect("Kv3GetMetaData function was not found")(kv, ppCtx) }
}
pub type _Kv3GetMetaData = unsafe extern "C" fn(usize, usize) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMetaData: Option<_Kv3GetMetaData> = None;

/// Checks if a specific flag is set
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `flag` - (uint8): The flag to check
///
/// # Returns - (bool):
/// true if the flag is set, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3HasFlag(kv: usize, flag: u8) -> bool {
    unsafe { __s2sdk_Kv3HasFlag.expect("Kv3HasFlag function was not found")(kv, flag) }
}
pub type _Kv3HasFlag = unsafe extern "C" fn(usize, u8) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3HasFlag: Option<_Kv3HasFlag> = None;

/// Checks if any flags are set
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (bool):
/// true if any flags are set, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3HasAnyFlags(kv: usize) -> bool {
    unsafe { __s2sdk_Kv3HasAnyFlags.expect("Kv3HasAnyFlags function was not found")(kv) }
}
pub type _Kv3HasAnyFlags = unsafe extern "C" fn(usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3HasAnyFlags: Option<_Kv3HasAnyFlags> = None;

/// Gets all flags as a bitmask
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (uint8):
/// Bitmask of all flags, or 0 if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetAllFlags(kv: usize) -> u8 {
    unsafe { __s2sdk_Kv3GetAllFlags.expect("Kv3GetAllFlags function was not found")(kv) }
}
pub type _Kv3GetAllFlags = unsafe extern "C" fn(usize) -> u8;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetAllFlags: Option<_Kv3GetAllFlags> = None;

/// Sets all flags from a bitmask
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `flags` - (uint8): Bitmask of flags to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetAllFlags(kv: usize, flags: u8) {
    unsafe { __s2sdk_Kv3SetAllFlags.expect("Kv3SetAllFlags function was not found")(kv, flags) }
}
pub type _Kv3SetAllFlags = unsafe extern "C" fn(usize, u8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetAllFlags: Option<_Kv3SetAllFlags> = None;

/// Sets or clears a specific flag
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `flag` - (uint8): The flag to modify
/// * `state` - (bool): true to set the flag, false to clear it
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetFlag(kv: usize, flag: u8, state: bool) {
    unsafe { __s2sdk_Kv3SetFlag.expect("Kv3SetFlag function was not found")(kv, flag, state) }
}
pub type _Kv3SetFlag = unsafe extern "C" fn(usize, u8, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetFlag: Option<_Kv3SetFlag> = None;

/// Gets the basic type of the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (uint8):
/// The type enumeration value, or 0 if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetType(kv: usize) -> u8 {
    unsafe { __s2sdk_Kv3GetType.expect("Kv3GetType function was not found")(kv) }
}
pub type _Kv3GetType = unsafe extern "C" fn(usize) -> u8;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetType: Option<_Kv3GetType> = None;

/// Gets the extended type of the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (uint8):
/// The extended type enumeration value, or 0 if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetTypeEx(kv: usize) -> u8 {
    unsafe { __s2sdk_Kv3GetTypeEx.expect("Kv3GetTypeEx function was not found")(kv) }
}
pub type _Kv3GetTypeEx = unsafe extern "C" fn(usize) -> u8;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetTypeEx: Option<_Kv3GetTypeEx> = None;

/// Gets the subtype of the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (uint8):
/// The subtype enumeration value, or 0 if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetSubType(kv: usize) -> u8 {
    unsafe { __s2sdk_Kv3GetSubType.expect("Kv3GetSubType function was not found")(kv) }
}
pub type _Kv3GetSubType = unsafe extern "C" fn(usize) -> u8;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetSubType: Option<_Kv3GetSubType> = None;

/// Checks if the object has invalid member names
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (bool):
/// true if invalid member names exist, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3HasInvalidMemberNames(kv: usize) -> bool {
    unsafe { __s2sdk_Kv3HasInvalidMemberNames.expect("Kv3HasInvalidMemberNames function was not found")(kv) }
}
pub type _Kv3HasInvalidMemberNames = unsafe extern "C" fn(usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3HasInvalidMemberNames: Option<_Kv3HasInvalidMemberNames> = None;

/// Sets the invalid member names flag
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `bValue` - (bool): true to mark as having invalid member names, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetHasInvalidMemberNames(kv: usize, bValue: bool) {
    unsafe { __s2sdk_Kv3SetHasInvalidMemberNames.expect("Kv3SetHasInvalidMemberNames function was not found")(kv, bValue) }
}
pub type _Kv3SetHasInvalidMemberNames = unsafe extern "C" fn(usize, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetHasInvalidMemberNames: Option<_Kv3SetHasInvalidMemberNames> = None;

/// Gets the type as a string representation
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (string):
/// String representation of the type, or empty string if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetTypeAsString(kv: usize) -> Str {
    unsafe { __s2sdk_Kv3GetTypeAsString.expect("Kv3GetTypeAsString function was not found")(kv) }
}
pub type _Kv3GetTypeAsString = unsafe extern "C" fn(usize) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetTypeAsString: Option<_Kv3GetTypeAsString> = None;

/// Gets the subtype as a string representation
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (string):
/// String representation of the subtype, or empty string if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetSubTypeAsString(kv: usize) -> Str {
    unsafe { __s2sdk_Kv3GetSubTypeAsString.expect("Kv3GetSubTypeAsString function was not found")(kv) }
}
pub type _Kv3GetSubTypeAsString = unsafe extern "C" fn(usize) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetSubTypeAsString: Option<_Kv3GetSubTypeAsString> = None;

/// Converts the KeyValues3 object to a string representation
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `flags` - (uint32): Formatting flags for the string conversion
///
/// # Returns - (string):
/// String representation of the object, or empty string if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3ToString(kv: usize, flags: u32) -> Str {
    unsafe { __s2sdk_Kv3ToString.expect("Kv3ToString function was not found")(kv, flags) }
}
pub type _Kv3ToString = unsafe extern "C" fn(usize, u32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3ToString: Option<_Kv3ToString> = None;

/// Checks if the KeyValues3 object is null
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (bool):
/// true if the object is null or the pointer is null, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3IsNull(kv: usize) -> bool {
    unsafe { __s2sdk_Kv3IsNull.expect("Kv3IsNull function was not found")(kv) }
}
pub type _Kv3IsNull = unsafe extern "C" fn(usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3IsNull: Option<_Kv3IsNull> = None;

/// Sets the KeyValues3 object to null
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetToNull(kv: usize) {
    unsafe { __s2sdk_Kv3SetToNull.expect("Kv3SetToNull function was not found")(kv) }
}
pub type _Kv3SetToNull = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetToNull: Option<_Kv3SetToNull> = None;

/// Checks if the KeyValues3 object is an array
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (bool):
/// true if the object is an array, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3IsArray(kv: usize) -> bool {
    unsafe { __s2sdk_Kv3IsArray.expect("Kv3IsArray function was not found")(kv) }
}
pub type _Kv3IsArray = unsafe extern "C" fn(usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3IsArray: Option<_Kv3IsArray> = None;

/// Checks if the KeyValues3 object is a KV3 array
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (bool):
/// true if the object is a KV3 array, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3IsKV3Array(kv: usize) -> bool {
    unsafe { __s2sdk_Kv3IsKV3Array.expect("Kv3IsKV3Array function was not found")(kv) }
}
pub type _Kv3IsKV3Array = unsafe extern "C" fn(usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3IsKV3Array: Option<_Kv3IsKV3Array> = None;

/// Checks if the KeyValues3 object is a table
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (bool):
/// true if the object is a table, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3IsTable(kv: usize) -> bool {
    unsafe { __s2sdk_Kv3IsTable.expect("Kv3IsTable function was not found")(kv) }
}
pub type _Kv3IsTable = unsafe extern "C" fn(usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3IsTable: Option<_Kv3IsTable> = None;

/// Checks if the KeyValues3 object is a string
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (bool):
/// true if the object is a string, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3IsString(kv: usize) -> bool {
    unsafe { __s2sdk_Kv3IsString.expect("Kv3IsString function was not found")(kv) }
}
pub type _Kv3IsString = unsafe extern "C" fn(usize) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3IsString: Option<_Kv3IsString> = None;

/// Gets the boolean value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (bool): Default value to return if kv is null or conversion fails
///
/// # Returns - (bool):
/// Boolean value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetBool(kv: usize, defaultValue: bool) -> bool {
    unsafe { __s2sdk_Kv3GetBool.expect("Kv3GetBool function was not found")(kv, defaultValue) }
}
pub type _Kv3GetBool = unsafe extern "C" fn(usize, bool) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetBool: Option<_Kv3GetBool> = None;

/// Gets the char value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (char8): Default value to return if kv is null or conversion fails
///
/// # Returns - (char8):
/// Char value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetChar(kv: usize, defaultValue: i8) -> i8 {
    unsafe { __s2sdk_Kv3GetChar.expect("Kv3GetChar function was not found")(kv, defaultValue) }
}
pub type _Kv3GetChar = unsafe extern "C" fn(usize, i8) -> i8;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetChar: Option<_Kv3GetChar> = None;

/// Gets the 32-bit Unicode character value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (uint32): Default value to return if kv is null or conversion fails
///
/// # Returns - (uint32):
/// 32-bit Unicode character value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetUChar32(kv: usize, defaultValue: u32) -> u32 {
    unsafe { __s2sdk_Kv3GetUChar32.expect("Kv3GetUChar32 function was not found")(kv, defaultValue) }
}
pub type _Kv3GetUChar32 = unsafe extern "C" fn(usize, u32) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetUChar32: Option<_Kv3GetUChar32> = None;

/// Gets the signed 8-bit integer value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (int8): Default value to return if kv is null or conversion fails
///
/// # Returns - (int8):
/// int8_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetInt8(kv: usize, defaultValue: i8) -> i8 {
    unsafe { __s2sdk_Kv3GetInt8.expect("Kv3GetInt8 function was not found")(kv, defaultValue) }
}
pub type _Kv3GetInt8 = unsafe extern "C" fn(usize, i8) -> i8;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetInt8: Option<_Kv3GetInt8> = None;

/// Gets the unsigned 8-bit integer value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (uint8): Default value to return if kv is null or conversion fails
///
/// # Returns - (uint8):
/// uint8_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetUInt8(kv: usize, defaultValue: u8) -> u8 {
    unsafe { __s2sdk_Kv3GetUInt8.expect("Kv3GetUInt8 function was not found")(kv, defaultValue) }
}
pub type _Kv3GetUInt8 = unsafe extern "C" fn(usize, u8) -> u8;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetUInt8: Option<_Kv3GetUInt8> = None;

/// Gets the signed 16-bit integer value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (int16): Default value to return if kv is null or conversion fails
///
/// # Returns - (int16):
/// int16_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetShort(kv: usize, defaultValue: i16) -> i16 {
    unsafe { __s2sdk_Kv3GetShort.expect("Kv3GetShort function was not found")(kv, defaultValue) }
}
pub type _Kv3GetShort = unsafe extern "C" fn(usize, i16) -> i16;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetShort: Option<_Kv3GetShort> = None;

/// Gets the unsigned 16-bit integer value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (uint16): Default value to return if kv is null or conversion fails
///
/// # Returns - (uint16):
/// uint16_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetUShort(kv: usize, defaultValue: u16) -> u16 {
    unsafe { __s2sdk_Kv3GetUShort.expect("Kv3GetUShort function was not found")(kv, defaultValue) }
}
pub type _Kv3GetUShort = unsafe extern "C" fn(usize, u16) -> u16;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetUShort: Option<_Kv3GetUShort> = None;

/// Gets the signed 32-bit integer value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (int32): Default value to return if kv is null or conversion fails
///
/// # Returns - (int32):
/// int32_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetInt(kv: usize, defaultValue: i32) -> i32 {
    unsafe { __s2sdk_Kv3GetInt.expect("Kv3GetInt function was not found")(kv, defaultValue) }
}
pub type _Kv3GetInt = unsafe extern "C" fn(usize, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetInt: Option<_Kv3GetInt> = None;

/// Gets the unsigned 32-bit integer value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (uint32): Default value to return if kv is null or conversion fails
///
/// # Returns - (uint32):
/// uint32_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetUInt(kv: usize, defaultValue: u32) -> u32 {
    unsafe { __s2sdk_Kv3GetUInt.expect("Kv3GetUInt function was not found")(kv, defaultValue) }
}
pub type _Kv3GetUInt = unsafe extern "C" fn(usize, u32) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetUInt: Option<_Kv3GetUInt> = None;

/// Gets the signed 64-bit integer value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (int64): Default value to return if kv is null or conversion fails
///
/// # Returns - (int64):
/// int64_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetInt64(kv: usize, defaultValue: i64) -> i64 {
    unsafe { __s2sdk_Kv3GetInt64.expect("Kv3GetInt64 function was not found")(kv, defaultValue) }
}
pub type _Kv3GetInt64 = unsafe extern "C" fn(usize, i64) -> i64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetInt64: Option<_Kv3GetInt64> = None;

/// Gets the unsigned 64-bit integer value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (uint64): Default value to return if kv is null or conversion fails
///
/// # Returns - (uint64):
/// uint64_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetUInt64(kv: usize, defaultValue: u64) -> u64 {
    unsafe { __s2sdk_Kv3GetUInt64.expect("Kv3GetUInt64 function was not found")(kv, defaultValue) }
}
pub type _Kv3GetUInt64 = unsafe extern "C" fn(usize, u64) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetUInt64: Option<_Kv3GetUInt64> = None;

/// Gets the float value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (float): Default value to return if kv is null or conversion fails
///
/// # Returns - (float):
/// Float value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetFloat(kv: usize, defaultValue: f32) -> f32 {
    unsafe { __s2sdk_Kv3GetFloat.expect("Kv3GetFloat function was not found")(kv, defaultValue) }
}
pub type _Kv3GetFloat = unsafe extern "C" fn(usize, f32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetFloat: Option<_Kv3GetFloat> = None;

/// Gets the double value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (double): Default value to return if kv is null or conversion fails
///
/// # Returns - (double):
/// Double value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetDouble(kv: usize, defaultValue: f64) -> f64 {
    unsafe { __s2sdk_Kv3GetDouble.expect("Kv3GetDouble function was not found")(kv, defaultValue) }
}
pub type _Kv3GetDouble = unsafe extern "C" fn(usize, f64) -> f64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetDouble: Option<_Kv3GetDouble> = None;

/// Sets the KeyValues3 object to a boolean value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (bool): Boolean value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetBool(kv: usize, value: bool) {
    unsafe { __s2sdk_Kv3SetBool.expect("Kv3SetBool function was not found")(kv, value) }
}
pub type _Kv3SetBool = unsafe extern "C" fn(usize, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetBool: Option<_Kv3SetBool> = None;

/// Sets the KeyValues3 object to a char value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (char8): Char value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetChar(kv: usize, value: i8) {
    unsafe { __s2sdk_Kv3SetChar.expect("Kv3SetChar function was not found")(kv, value) }
}
pub type _Kv3SetChar = unsafe extern "C" fn(usize, i8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetChar: Option<_Kv3SetChar> = None;

/// Sets the KeyValues3 object to a 32-bit Unicode character value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (uint32): 32-bit Unicode character value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetUChar32(kv: usize, value: u32) {
    unsafe { __s2sdk_Kv3SetUChar32.expect("Kv3SetUChar32 function was not found")(kv, value) }
}
pub type _Kv3SetUChar32 = unsafe extern "C" fn(usize, u32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetUChar32: Option<_Kv3SetUChar32> = None;

/// Sets the KeyValues3 object to a signed 8-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (int8): int8_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetInt8(kv: usize, value: i8) {
    unsafe { __s2sdk_Kv3SetInt8.expect("Kv3SetInt8 function was not found")(kv, value) }
}
pub type _Kv3SetInt8 = unsafe extern "C" fn(usize, i8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetInt8: Option<_Kv3SetInt8> = None;

/// Sets the KeyValues3 object to an unsigned 8-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (uint8): uint8_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetUInt8(kv: usize, value: u8) {
    unsafe { __s2sdk_Kv3SetUInt8.expect("Kv3SetUInt8 function was not found")(kv, value) }
}
pub type _Kv3SetUInt8 = unsafe extern "C" fn(usize, u8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetUInt8: Option<_Kv3SetUInt8> = None;

/// Sets the KeyValues3 object to a signed 16-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (int16): int16_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetShort(kv: usize, value: i16) {
    unsafe { __s2sdk_Kv3SetShort.expect("Kv3SetShort function was not found")(kv, value) }
}
pub type _Kv3SetShort = unsafe extern "C" fn(usize, i16);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetShort: Option<_Kv3SetShort> = None;

/// Sets the KeyValues3 object to an unsigned 16-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (uint16): uint16_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetUShort(kv: usize, value: u16) {
    unsafe { __s2sdk_Kv3SetUShort.expect("Kv3SetUShort function was not found")(kv, value) }
}
pub type _Kv3SetUShort = unsafe extern "C" fn(usize, u16);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetUShort: Option<_Kv3SetUShort> = None;

/// Sets the KeyValues3 object to a signed 32-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (int32): int32_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetInt(kv: usize, value: i32) {
    unsafe { __s2sdk_Kv3SetInt.expect("Kv3SetInt function was not found")(kv, value) }
}
pub type _Kv3SetInt = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetInt: Option<_Kv3SetInt> = None;

/// Sets the KeyValues3 object to an unsigned 32-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (uint32): uint32_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetUInt(kv: usize, value: u32) {
    unsafe { __s2sdk_Kv3SetUInt.expect("Kv3SetUInt function was not found")(kv, value) }
}
pub type _Kv3SetUInt = unsafe extern "C" fn(usize, u32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetUInt: Option<_Kv3SetUInt> = None;

/// Sets the KeyValues3 object to a signed 64-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (int64): int64_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetInt64(kv: usize, value: i64) {
    unsafe { __s2sdk_Kv3SetInt64.expect("Kv3SetInt64 function was not found")(kv, value) }
}
pub type _Kv3SetInt64 = unsafe extern "C" fn(usize, i64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetInt64: Option<_Kv3SetInt64> = None;

/// Sets the KeyValues3 object to an unsigned 64-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (uint64): uint64_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetUInt64(kv: usize, value: u64) {
    unsafe { __s2sdk_Kv3SetUInt64.expect("Kv3SetUInt64 function was not found")(kv, value) }
}
pub type _Kv3SetUInt64 = unsafe extern "C" fn(usize, u64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetUInt64: Option<_Kv3SetUInt64> = None;

/// Sets the KeyValues3 object to a float value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (float): Float value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetFloat(kv: usize, value: f32) {
    unsafe { __s2sdk_Kv3SetFloat.expect("Kv3SetFloat function was not found")(kv, value) }
}
pub type _Kv3SetFloat = unsafe extern "C" fn(usize, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetFloat: Option<_Kv3SetFloat> = None;

/// Sets the KeyValues3 object to a double value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `value` - (double): Double value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetDouble(kv: usize, value: f64) {
    unsafe { __s2sdk_Kv3SetDouble.expect("Kv3SetDouble function was not found")(kv, value) }
}
pub type _Kv3SetDouble = unsafe extern "C" fn(usize, f64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetDouble: Option<_Kv3SetDouble> = None;

/// Gets the pointer value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (ptr64): Default value to return if kv is null
///
/// # Returns - (ptr64):
/// Pointer value as uintptr_t or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetPointer(kv: usize, defaultValue: usize) -> usize {
    unsafe { __s2sdk_Kv3GetPointer.expect("Kv3GetPointer function was not found")(kv, defaultValue) }
}
pub type _Kv3GetPointer = unsafe extern "C" fn(usize, usize) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetPointer: Option<_Kv3GetPointer> = None;

/// Sets the KeyValues3 object to a pointer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `ptr` - (ptr64): Pointer value as uintptr_t to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetPointer(kv: usize, ptr: usize) {
    unsafe { __s2sdk_Kv3SetPointer.expect("Kv3SetPointer function was not found")(kv, ptr) }
}
pub type _Kv3SetPointer = unsafe extern "C" fn(usize, usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetPointer: Option<_Kv3SetPointer> = None;

/// Gets the string token value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (uint32): Default token value to return if kv is null
///
/// # Returns - (uint32):
/// String token hash code or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetStringToken(kv: usize, defaultValue: u32) -> u32 {
    unsafe { __s2sdk_Kv3GetStringToken.expect("Kv3GetStringToken function was not found")(kv, defaultValue) }
}
pub type _Kv3GetStringToken = unsafe extern "C" fn(usize, u32) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetStringToken: Option<_Kv3GetStringToken> = None;

/// Sets the KeyValues3 object to a string token value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `token` - (uint32): String token hash code to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetStringToken(kv: usize, token: u32) {
    unsafe { __s2sdk_Kv3SetStringToken.expect("Kv3SetStringToken function was not found")(kv, token) }
}
pub type _Kv3SetStringToken = unsafe extern "C" fn(usize, u32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetStringToken: Option<_Kv3SetStringToken> = None;

/// Gets the entity handle value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (int32): Default entity handle value to return if kv is null
///
/// # Returns - (int32):
/// Entity handle as int32_t or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetEHandle(kv: usize, defaultValue: i32) -> i32 {
    unsafe { __s2sdk_Kv3GetEHandle.expect("Kv3GetEHandle function was not found")(kv, defaultValue) }
}
pub type _Kv3GetEHandle = unsafe extern "C" fn(usize, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetEHandle: Option<_Kv3GetEHandle> = None;

/// Sets the KeyValues3 object to an entity handle value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `ehandle` - (int32): Entity handle value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetEHandle(kv: usize, ehandle: i32) {
    unsafe { __s2sdk_Kv3SetEHandle.expect("Kv3SetEHandle function was not found")(kv, ehandle) }
}
pub type _Kv3SetEHandle = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetEHandle: Option<_Kv3SetEHandle> = None;

/// Gets the string value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (string): Default string to return if kv is null or value is empty
///
/// # Returns - (string):
/// String value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetString(kv: usize, defaultValue: &Str) -> Str {
    unsafe { __s2sdk_Kv3GetString.expect("Kv3GetString function was not found")(kv, defaultValue) }
}
pub type _Kv3GetString = unsafe extern "C" fn(usize, &Str) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetString: Option<_Kv3GetString> = None;

/// Sets the KeyValues3 object to a string value (copies the string)
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `str` - (string): String value to set
/// * `subtype` - (uint8): String subtype enumeration value
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetString(kv: usize, str: &Str, subtype: u8) {
    unsafe { __s2sdk_Kv3SetString.expect("Kv3SetString function was not found")(kv, str, subtype) }
}
pub type _Kv3SetString = unsafe extern "C" fn(usize, &Str, u8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetString: Option<_Kv3SetString> = None;

/// Sets the KeyValues3 object to an external string value (does not copy)
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `str` - (string): External string value to reference
/// * `subtype` - (uint8): String subtype enumeration value
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetStringExternal(kv: usize, str: &Str, subtype: u8) {
    unsafe { __s2sdk_Kv3SetStringExternal.expect("Kv3SetStringExternal function was not found")(kv, str, subtype) }
}
pub type _Kv3SetStringExternal = unsafe extern "C" fn(usize, &Str, u8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetStringExternal: Option<_Kv3SetStringExternal> = None;

/// Gets the binary blob from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (uint8[]):
/// Vector containing the binary blob data, or empty vector if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetBinaryBlob(kv: usize) -> Arr<u8> {
    unsafe { __s2sdk_Kv3GetBinaryBlob.expect("Kv3GetBinaryBlob function was not found")(kv) }
}
pub type _Kv3GetBinaryBlob = unsafe extern "C" fn(usize) -> Arr<u8>;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetBinaryBlob: Option<_Kv3GetBinaryBlob> = None;

/// Gets the size of the binary blob in the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (int32):
/// Size of the binary blob in bytes, or 0 if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetBinaryBlobSize(kv: usize) -> i32 {
    unsafe { __s2sdk_Kv3GetBinaryBlobSize.expect("Kv3GetBinaryBlobSize function was not found")(kv) }
}
pub type _Kv3GetBinaryBlobSize = unsafe extern "C" fn(usize) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetBinaryBlobSize: Option<_Kv3GetBinaryBlobSize> = None;

/// Sets the KeyValues3 object to a binary blob (copies the data)
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `blob` - (uint8[]): Vector containing the binary blob data
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetToBinaryBlob(kv: usize, blob: &Arr<u8>) {
    unsafe { __s2sdk_Kv3SetToBinaryBlob.expect("Kv3SetToBinaryBlob function was not found")(kv, blob) }
}
pub type _Kv3SetToBinaryBlob = unsafe extern "C" fn(usize, &Arr<u8>);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetToBinaryBlob: Option<_Kv3SetToBinaryBlob> = None;

/// Sets the KeyValues3 object to an external binary blob (does not copy)
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `blob` - (uint8[]): Vector containing the external binary blob data
/// * `free_mem` - (bool): Whether to free the memory when the object is destroyed
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetToBinaryBlobExternal(kv: usize, blob: &Arr<u8>, free_mem: bool) {
    unsafe { __s2sdk_Kv3SetToBinaryBlobExternal.expect("Kv3SetToBinaryBlobExternal function was not found")(kv, blob, free_mem) }
}
pub type _Kv3SetToBinaryBlobExternal = unsafe extern "C" fn(usize, &Arr<u8>, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetToBinaryBlobExternal: Option<_Kv3SetToBinaryBlobExternal> = None;

/// Gets the color value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (vec4): Default color value to return if kv is null
///
/// # Returns - (vec4):
/// Color value as vec4 or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetColor(kv: usize, defaultValue: &Vec4) -> Vec4 {
    unsafe { __s2sdk_Kv3GetColor.expect("Kv3GetColor function was not found")(kv, defaultValue) }
}
pub type _Kv3GetColor = unsafe extern "C" fn(usize, &Vec4) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetColor: Option<_Kv3GetColor> = None;

/// Sets the KeyValues3 object to a color value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `color` - (vec4): Color value as vec4 to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetColor(kv: usize, color: &Vec4) {
    unsafe { __s2sdk_Kv3SetColor.expect("Kv3SetColor function was not found")(kv, color) }
}
pub type _Kv3SetColor = unsafe extern "C" fn(usize, &Vec4);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetColor: Option<_Kv3SetColor> = None;

/// Gets the 3D vector value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (vec3): Default vector to return if kv is null
///
/// # Returns - (vec3):
/// 3D vector or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetVector(kv: usize, defaultValue: &Vec3) -> Vec3 {
    unsafe { __s2sdk_Kv3GetVector.expect("Kv3GetVector function was not found")(kv, defaultValue) }
}
pub type _Kv3GetVector = unsafe extern "C" fn(usize, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetVector: Option<_Kv3GetVector> = None;

/// Gets the 2D vector value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (vec2): Default 2D vector to return if kv is null
///
/// # Returns - (vec2):
/// 2D vector or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetVector2D(kv: usize, defaultValue: &Vec2) -> Vec2 {
    unsafe { __s2sdk_Kv3GetVector2D.expect("Kv3GetVector2D function was not found")(kv, defaultValue) }
}
pub type _Kv3GetVector2D = unsafe extern "C" fn(usize, &Vec2) -> Vec2;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetVector2D: Option<_Kv3GetVector2D> = None;

/// Gets the 4D vector value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (vec4): Default 4D vector to return if kv is null
///
/// # Returns - (vec4):
/// 4D vector or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetVector4D(kv: usize, defaultValue: &Vec4) -> Vec4 {
    unsafe { __s2sdk_Kv3GetVector4D.expect("Kv3GetVector4D function was not found")(kv, defaultValue) }
}
pub type _Kv3GetVector4D = unsafe extern "C" fn(usize, &Vec4) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetVector4D: Option<_Kv3GetVector4D> = None;

/// Gets the quaternion value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (vec4): Default quaternion to return if kv is null
///
/// # Returns - (vec4):
/// Quaternion as vec4 or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetQuaternion(kv: usize, defaultValue: &Vec4) -> Vec4 {
    unsafe { __s2sdk_Kv3GetQuaternion.expect("Kv3GetQuaternion function was not found")(kv, defaultValue) }
}
pub type _Kv3GetQuaternion = unsafe extern "C" fn(usize, &Vec4) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetQuaternion: Option<_Kv3GetQuaternion> = None;

/// Gets the angle (QAngle) value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (vec3): Default angle to return if kv is null
///
/// # Returns - (vec3):
/// QAngle as vec3 or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetQAngle(kv: usize, defaultValue: &Vec3) -> Vec3 {
    unsafe { __s2sdk_Kv3GetQAngle.expect("Kv3GetQAngle function was not found")(kv, defaultValue) }
}
pub type _Kv3GetQAngle = unsafe extern "C" fn(usize, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetQAngle: Option<_Kv3GetQAngle> = None;

/// Gets the 3x4 matrix value from the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `defaultValue` - (mat4x4): Default matrix to return if kv is null
///
/// # Returns - (mat4x4):
/// 3x4 matrix as mat4x4 or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMatrix3x4(kv: usize, defaultValue: &Mat4x4) -> Mat4x4 {
    unsafe { __s2sdk_Kv3GetMatrix3x4.expect("Kv3GetMatrix3x4 function was not found")(kv, defaultValue) }
}
pub type _Kv3GetMatrix3x4 = unsafe extern "C" fn(usize, &Mat4x4) -> Mat4x4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMatrix3x4: Option<_Kv3GetMatrix3x4> = None;

/// Sets the KeyValues3 object to a 3D vector value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `vec` - (vec3): 3D vector to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetVector(kv: usize, vec: &Vec3) {
    unsafe { __s2sdk_Kv3SetVector.expect("Kv3SetVector function was not found")(kv, vec) }
}
pub type _Kv3SetVector = unsafe extern "C" fn(usize, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetVector: Option<_Kv3SetVector> = None;

/// Sets the KeyValues3 object to a 2D vector value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `vec2d` - (vec2): 2D vector to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetVector2D(kv: usize, vec2d: &Vec2) {
    unsafe { __s2sdk_Kv3SetVector2D.expect("Kv3SetVector2D function was not found")(kv, vec2d) }
}
pub type _Kv3SetVector2D = unsafe extern "C" fn(usize, &Vec2);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetVector2D: Option<_Kv3SetVector2D> = None;

/// Sets the KeyValues3 object to a 4D vector value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `vec4d` - (vec4): 4D vector to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetVector4D(kv: usize, vec4d: &Vec4) {
    unsafe { __s2sdk_Kv3SetVector4D.expect("Kv3SetVector4D function was not found")(kv, vec4d) }
}
pub type _Kv3SetVector4D = unsafe extern "C" fn(usize, &Vec4);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetVector4D: Option<_Kv3SetVector4D> = None;

/// Sets the KeyValues3 object to a quaternion value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `quat` - (vec4): Quaternion to set (as vec4)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetQuaternion(kv: usize, quat: &Vec4) {
    unsafe { __s2sdk_Kv3SetQuaternion.expect("Kv3SetQuaternion function was not found")(kv, quat) }
}
pub type _Kv3SetQuaternion = unsafe extern "C" fn(usize, &Vec4);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetQuaternion: Option<_Kv3SetQuaternion> = None;

/// Sets the KeyValues3 object to an angle (QAngle) value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `ang` - (vec3): QAngle to set (as vec3)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetQAngle(kv: usize, ang: &Vec3) {
    unsafe { __s2sdk_Kv3SetQAngle.expect("Kv3SetQAngle function was not found")(kv, ang) }
}
pub type _Kv3SetQAngle = unsafe extern "C" fn(usize, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetQAngle: Option<_Kv3SetQAngle> = None;

/// Sets the KeyValues3 object to a 3x4 matrix value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `matrix` - (mat4x4): 3x4 matrix to set (as mat4x4)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMatrix3x4(kv: usize, matrix: &Mat4x4) {
    unsafe { __s2sdk_Kv3SetMatrix3x4.expect("Kv3SetMatrix3x4 function was not found")(kv, matrix) }
}
pub type _Kv3SetMatrix3x4 = unsafe extern "C" fn(usize, &Mat4x4);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMatrix3x4: Option<_Kv3SetMatrix3x4> = None;

/// Gets the number of elements in the array
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (int32):
/// Number of array elements, or 0 if kv is null or not an array
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetArrayElementCount(kv: usize) -> i32 {
    unsafe { __s2sdk_Kv3GetArrayElementCount.expect("Kv3GetArrayElementCount function was not found")(kv) }
}
pub type _Kv3GetArrayElementCount = unsafe extern "C" fn(usize) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetArrayElementCount: Option<_Kv3GetArrayElementCount> = None;

/// Sets the number of elements in the array
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `count` - (int32): Number of elements to set
/// * `type_` - (uint8): Type of array elements
/// * `subtype` - (uint8): Subtype of array elements
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetArrayElementCount(kv: usize, count: i32, type_: u8, subtype: u8) {
    unsafe { __s2sdk_Kv3SetArrayElementCount.expect("Kv3SetArrayElementCount function was not found")(kv, count, type_, subtype) }
}
pub type _Kv3SetArrayElementCount = unsafe extern "C" fn(usize, i32, u8, u8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetArrayElementCount: Option<_Kv3SetArrayElementCount> = None;

/// Sets the KeyValues3 object to an empty KV3 array
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetToEmptyKV3Array(kv: usize) {
    unsafe { __s2sdk_Kv3SetToEmptyKV3Array.expect("Kv3SetToEmptyKV3Array function was not found")(kv) }
}
pub type _Kv3SetToEmptyKV3Array = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetToEmptyKV3Array: Option<_Kv3SetToEmptyKV3Array> = None;

/// Gets an array element at the specified index
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `elem` - (int32): Index of the element to get
///
/// # Returns - (ptr64):
/// Pointer to the element KeyValues3 object, or nullptr if invalid
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetArrayElement(kv: usize, elem: i32) -> usize {
    unsafe { __s2sdk_Kv3GetArrayElement.expect("Kv3GetArrayElement function was not found")(kv, elem) }
}
pub type _Kv3GetArrayElement = unsafe extern "C" fn(usize, i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetArrayElement: Option<_Kv3GetArrayElement> = None;

/// Inserts a new element before the specified index
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `elem` - (int32): Index before which to insert
///
/// # Returns - (ptr64):
/// Pointer to the newly inserted element, or nullptr if invalid
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3ArrayInsertElementBefore(kv: usize, elem: i32) -> usize {
    unsafe { __s2sdk_Kv3ArrayInsertElementBefore.expect("Kv3ArrayInsertElementBefore function was not found")(kv, elem) }
}
pub type _Kv3ArrayInsertElementBefore = unsafe extern "C" fn(usize, i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3ArrayInsertElementBefore: Option<_Kv3ArrayInsertElementBefore> = None;

/// Inserts a new element after the specified index
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `elem` - (int32): Index after which to insert
///
/// # Returns - (ptr64):
/// Pointer to the newly inserted element, or nullptr if invalid
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3ArrayInsertElementAfter(kv: usize, elem: i32) -> usize {
    unsafe { __s2sdk_Kv3ArrayInsertElementAfter.expect("Kv3ArrayInsertElementAfter function was not found")(kv, elem) }
}
pub type _Kv3ArrayInsertElementAfter = unsafe extern "C" fn(usize, i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3ArrayInsertElementAfter: Option<_Kv3ArrayInsertElementAfter> = None;

/// Adds a new element to the end of the array
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (ptr64):
/// Pointer to the newly added element, or nullptr if invalid
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3ArrayAddElementToTail(kv: usize) -> usize {
    unsafe { __s2sdk_Kv3ArrayAddElementToTail.expect("Kv3ArrayAddElementToTail function was not found")(kv) }
}
pub type _Kv3ArrayAddElementToTail = unsafe extern "C" fn(usize) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3ArrayAddElementToTail: Option<_Kv3ArrayAddElementToTail> = None;

/// Swaps two array elements
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `idx1` - (int32): Index of the first element
/// * `idx2` - (int32): Index of the second element
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3ArraySwapItems(kv: usize, idx1: i32, idx2: i32) {
    unsafe { __s2sdk_Kv3ArraySwapItems.expect("Kv3ArraySwapItems function was not found")(kv, idx1, idx2) }
}
pub type _Kv3ArraySwapItems = unsafe extern "C" fn(usize, i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3ArraySwapItems: Option<_Kv3ArraySwapItems> = None;

/// Removes an element from the array
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `elem` - (int32): Index of the element to remove
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3ArrayRemoveElement(kv: usize, elem: i32) {
    unsafe { __s2sdk_Kv3ArrayRemoveElement.expect("Kv3ArrayRemoveElement function was not found")(kv, elem) }
}
pub type _Kv3ArrayRemoveElement = unsafe extern "C" fn(usize, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3ArrayRemoveElement: Option<_Kv3ArrayRemoveElement> = None;

/// Sets the KeyValues3 object to an empty table
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetToEmptyTable(kv: usize) {
    unsafe { __s2sdk_Kv3SetToEmptyTable.expect("Kv3SetToEmptyTable function was not found")(kv) }
}
pub type _Kv3SetToEmptyTable = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetToEmptyTable: Option<_Kv3SetToEmptyTable> = None;

/// Gets the number of members in the table
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
///
/// # Returns - (int32):
/// Number of table members, or 0 if kv is null or not a table
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberCount(kv: usize) -> i32 {
    unsafe { __s2sdk_Kv3GetMemberCount.expect("Kv3GetMemberCount function was not found")(kv) }
}
pub type _Kv3GetMemberCount = unsafe extern "C" fn(usize) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberCount: Option<_Kv3GetMemberCount> = None;

/// Checks if a member with the specified name exists
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member to check
///
/// # Returns - (bool):
/// true if the member exists, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3HasMember(kv: usize, name: &Str) -> bool {
    unsafe { __s2sdk_Kv3HasMember.expect("Kv3HasMember function was not found")(kv, name) }
}
pub type _Kv3HasMember = unsafe extern "C" fn(usize, &Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3HasMember: Option<_Kv3HasMember> = None;

/// Finds a member by name
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member to find
///
/// # Returns - (ptr64):
/// Pointer to the member KeyValues3 object, or nullptr if not found
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3FindMember(kv: usize, name: &Str) -> usize {
    unsafe { __s2sdk_Kv3FindMember.expect("Kv3FindMember function was not found")(kv, name) }
}
pub type _Kv3FindMember = unsafe extern "C" fn(usize, &Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3FindMember: Option<_Kv3FindMember> = None;

/// Finds a member by name, or creates it if it doesn't exist
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member to find or create
///
/// # Returns - (ptr64):
/// Pointer to the member KeyValues3 object, or nullptr if kv is null
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3FindOrCreateMember(kv: usize, name: &Str) -> usize {
    unsafe { __s2sdk_Kv3FindOrCreateMember.expect("Kv3FindOrCreateMember function was not found")(kv, name) }
}
pub type _Kv3FindOrCreateMember = unsafe extern "C" fn(usize, &Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3FindOrCreateMember: Option<_Kv3FindOrCreateMember> = None;

/// Removes a member from the table
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member to remove
///
/// # Returns - (bool):
/// true if the member was removed, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3RemoveMember(kv: usize, name: &Str) -> bool {
    unsafe { __s2sdk_Kv3RemoveMember.expect("Kv3RemoveMember function was not found")(kv, name) }
}
pub type _Kv3RemoveMember = unsafe extern "C" fn(usize, &Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3RemoveMember: Option<_Kv3RemoveMember> = None;

/// Gets the name of a member at the specified index
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `index` - (int32): Index of the member
///
/// # Returns - (string):
/// Name of the member, or empty string if invalid
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberName(kv: usize, index: i32) -> Str {
    unsafe { __s2sdk_Kv3GetMemberName.expect("Kv3GetMemberName function was not found")(kv, index) }
}
pub type _Kv3GetMemberName = unsafe extern "C" fn(usize, i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberName: Option<_Kv3GetMemberName> = None;

/// Gets a member by index
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `index` - (int32): Index of the member to get
///
/// # Returns - (ptr64):
/// Pointer to the member KeyValues3 object, or nullptr if invalid
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberByIndex(kv: usize, index: i32) -> usize {
    unsafe { __s2sdk_Kv3GetMemberByIndex.expect("Kv3GetMemberByIndex function was not found")(kv, index) }
}
pub type _Kv3GetMemberByIndex = unsafe extern "C" fn(usize, i32) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberByIndex: Option<_Kv3GetMemberByIndex> = None;

/// Gets a boolean value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (bool): Default value to return if member not found
///
/// # Returns - (bool):
/// Boolean value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberBool(kv: usize, name: &Str, defaultValue: bool) -> bool {
    unsafe { __s2sdk_Kv3GetMemberBool.expect("Kv3GetMemberBool function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberBool = unsafe extern "C" fn(usize, &Str, bool) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberBool: Option<_Kv3GetMemberBool> = None;

/// Gets a char value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (char8): Default value to return if member not found
///
/// # Returns - (char8):
/// Char value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberChar(kv: usize, name: &Str, defaultValue: i8) -> i8 {
    unsafe { __s2sdk_Kv3GetMemberChar.expect("Kv3GetMemberChar function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberChar = unsafe extern "C" fn(usize, &Str, i8) -> i8;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberChar: Option<_Kv3GetMemberChar> = None;

/// Gets a 32-bit Unicode character value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (uint32): Default value to return if member not found
///
/// # Returns - (uint32):
/// 32-bit Unicode character value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberUChar32(kv: usize, name: &Str, defaultValue: u32) -> u32 {
    unsafe { __s2sdk_Kv3GetMemberUChar32.expect("Kv3GetMemberUChar32 function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberUChar32 = unsafe extern "C" fn(usize, &Str, u32) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberUChar32: Option<_Kv3GetMemberUChar32> = None;

/// Gets a signed 8-bit integer value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (int8): Default value to return if member not found
///
/// # Returns - (int8):
/// int8_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberInt8(kv: usize, name: &Str, defaultValue: i8) -> i8 {
    unsafe { __s2sdk_Kv3GetMemberInt8.expect("Kv3GetMemberInt8 function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberInt8 = unsafe extern "C" fn(usize, &Str, i8) -> i8;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberInt8: Option<_Kv3GetMemberInt8> = None;

/// Gets an unsigned 8-bit integer value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (uint8): Default value to return if member not found
///
/// # Returns - (uint8):
/// uint8_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberUInt8(kv: usize, name: &Str, defaultValue: u8) -> u8 {
    unsafe { __s2sdk_Kv3GetMemberUInt8.expect("Kv3GetMemberUInt8 function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberUInt8 = unsafe extern "C" fn(usize, &Str, u8) -> u8;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberUInt8: Option<_Kv3GetMemberUInt8> = None;

/// Gets a signed 16-bit integer value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (int16): Default value to return if member not found
///
/// # Returns - (int16):
/// int16_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberShort(kv: usize, name: &Str, defaultValue: i16) -> i16 {
    unsafe { __s2sdk_Kv3GetMemberShort.expect("Kv3GetMemberShort function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberShort = unsafe extern "C" fn(usize, &Str, i16) -> i16;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberShort: Option<_Kv3GetMemberShort> = None;

/// Gets an unsigned 16-bit integer value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (uint16): Default value to return if member not found
///
/// # Returns - (uint16):
/// uint16_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberUShort(kv: usize, name: &Str, defaultValue: u16) -> u16 {
    unsafe { __s2sdk_Kv3GetMemberUShort.expect("Kv3GetMemberUShort function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberUShort = unsafe extern "C" fn(usize, &Str, u16) -> u16;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberUShort: Option<_Kv3GetMemberUShort> = None;

/// Gets a signed 32-bit integer value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (int32): Default value to return if member not found
///
/// # Returns - (int32):
/// int32_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberInt(kv: usize, name: &Str, defaultValue: i32) -> i32 {
    unsafe { __s2sdk_Kv3GetMemberInt.expect("Kv3GetMemberInt function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberInt = unsafe extern "C" fn(usize, &Str, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberInt: Option<_Kv3GetMemberInt> = None;

/// Gets an unsigned 32-bit integer value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (uint32): Default value to return if member not found
///
/// # Returns - (uint32):
/// uint32_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberUInt(kv: usize, name: &Str, defaultValue: u32) -> u32 {
    unsafe { __s2sdk_Kv3GetMemberUInt.expect("Kv3GetMemberUInt function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberUInt = unsafe extern "C" fn(usize, &Str, u32) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberUInt: Option<_Kv3GetMemberUInt> = None;

/// Gets a signed 64-bit integer value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (int64): Default value to return if member not found
///
/// # Returns - (int64):
/// int64_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberInt64(kv: usize, name: &Str, defaultValue: i64) -> i64 {
    unsafe { __s2sdk_Kv3GetMemberInt64.expect("Kv3GetMemberInt64 function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberInt64 = unsafe extern "C" fn(usize, &Str, i64) -> i64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberInt64: Option<_Kv3GetMemberInt64> = None;

/// Gets an unsigned 64-bit integer value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (uint64): Default value to return if member not found
///
/// # Returns - (uint64):
/// uint64_t value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberUInt64(kv: usize, name: &Str, defaultValue: u64) -> u64 {
    unsafe { __s2sdk_Kv3GetMemberUInt64.expect("Kv3GetMemberUInt64 function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberUInt64 = unsafe extern "C" fn(usize, &Str, u64) -> u64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberUInt64: Option<_Kv3GetMemberUInt64> = None;

/// Gets a float value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (float): Default value to return if member not found
///
/// # Returns - (float):
/// Float value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberFloat(kv: usize, name: &Str, defaultValue: f32) -> f32 {
    unsafe { __s2sdk_Kv3GetMemberFloat.expect("Kv3GetMemberFloat function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberFloat = unsafe extern "C" fn(usize, &Str, f32) -> f32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberFloat: Option<_Kv3GetMemberFloat> = None;

/// Gets a double value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (double): Default value to return if member not found
///
/// # Returns - (double):
/// Double value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberDouble(kv: usize, name: &Str, defaultValue: f64) -> f64 {
    unsafe { __s2sdk_Kv3GetMemberDouble.expect("Kv3GetMemberDouble function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberDouble = unsafe extern "C" fn(usize, &Str, f64) -> f64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberDouble: Option<_Kv3GetMemberDouble> = None;

/// Gets a pointer value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (ptr64): Default value to return if member not found
///
/// # Returns - (ptr64):
/// Pointer value as uintptr_t or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberPointer(kv: usize, name: &Str, defaultValue: usize) -> usize {
    unsafe { __s2sdk_Kv3GetMemberPointer.expect("Kv3GetMemberPointer function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberPointer = unsafe extern "C" fn(usize, &Str, usize) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberPointer: Option<_Kv3GetMemberPointer> = None;

/// Gets a string token value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (uint32): Default token value to return if member not found
///
/// # Returns - (uint32):
/// String token hash code or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberStringToken(kv: usize, name: &Str, defaultValue: u32) -> u32 {
    unsafe { __s2sdk_Kv3GetMemberStringToken.expect("Kv3GetMemberStringToken function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberStringToken = unsafe extern "C" fn(usize, &Str, u32) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberStringToken: Option<_Kv3GetMemberStringToken> = None;

/// Gets an entity handle value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (int32): Default entity handle value to return if member not found
///
/// # Returns - (int32):
/// Entity handle as int32_t or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberEHandle(kv: usize, name: &Str, defaultValue: i32) -> i32 {
    unsafe { __s2sdk_Kv3GetMemberEHandle.expect("Kv3GetMemberEHandle function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberEHandle = unsafe extern "C" fn(usize, &Str, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberEHandle: Option<_Kv3GetMemberEHandle> = None;

/// Gets a string value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (string): Default string to return if member not found
///
/// # Returns - (string):
/// String value or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberString(kv: usize, name: &Str, defaultValue: &Str) -> Str {
    unsafe { __s2sdk_Kv3GetMemberString.expect("Kv3GetMemberString function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberString = unsafe extern "C" fn(usize, &Str, &Str) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberString: Option<_Kv3GetMemberString> = None;

/// Gets a color value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (vec4): Default color value to return if member not found
///
/// # Returns - (vec4):
/// Color value as vec4 or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberColor(kv: usize, name: &Str, defaultValue: &Vec4) -> Vec4 {
    unsafe { __s2sdk_Kv3GetMemberColor.expect("Kv3GetMemberColor function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberColor = unsafe extern "C" fn(usize, &Str, &Vec4) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberColor: Option<_Kv3GetMemberColor> = None;

/// Gets a 3D vector value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (vec3): Default vector to return if member not found
///
/// # Returns - (vec3):
/// 3D vector or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberVector(kv: usize, name: &Str, defaultValue: &Vec3) -> Vec3 {
    unsafe { __s2sdk_Kv3GetMemberVector.expect("Kv3GetMemberVector function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberVector = unsafe extern "C" fn(usize, &Str, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberVector: Option<_Kv3GetMemberVector> = None;

/// Gets a 2D vector value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (vec2): Default 2D vector to return if member not found
///
/// # Returns - (vec2):
/// 2D vector or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberVector2D(kv: usize, name: &Str, defaultValue: &Vec2) -> Vec2 {
    unsafe { __s2sdk_Kv3GetMemberVector2D.expect("Kv3GetMemberVector2D function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberVector2D = unsafe extern "C" fn(usize, &Str, &Vec2) -> Vec2;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberVector2D: Option<_Kv3GetMemberVector2D> = None;

/// Gets a 4D vector value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (vec4): Default 4D vector to return if member not found
///
/// # Returns - (vec4):
/// 4D vector or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberVector4D(kv: usize, name: &Str, defaultValue: &Vec4) -> Vec4 {
    unsafe { __s2sdk_Kv3GetMemberVector4D.expect("Kv3GetMemberVector4D function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberVector4D = unsafe extern "C" fn(usize, &Str, &Vec4) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberVector4D: Option<_Kv3GetMemberVector4D> = None;

/// Gets a quaternion value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (vec4): Default quaternion to return if member not found
///
/// # Returns - (vec4):
/// Quaternion as vec4 or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberQuaternion(kv: usize, name: &Str, defaultValue: &Vec4) -> Vec4 {
    unsafe { __s2sdk_Kv3GetMemberQuaternion.expect("Kv3GetMemberQuaternion function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberQuaternion = unsafe extern "C" fn(usize, &Str, &Vec4) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberQuaternion: Option<_Kv3GetMemberQuaternion> = None;

/// Gets an angle (QAngle) value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (vec3): Default angle to return if member not found
///
/// # Returns - (vec3):
/// QAngle as vec3 or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberQAngle(kv: usize, name: &Str, defaultValue: &Vec3) -> Vec3 {
    unsafe { __s2sdk_Kv3GetMemberQAngle.expect("Kv3GetMemberQAngle function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberQAngle = unsafe extern "C" fn(usize, &Str, &Vec3) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberQAngle: Option<_Kv3GetMemberQAngle> = None;

/// Gets a 3x4 matrix value from a table member
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `defaultValue` - (mat4x4): Default matrix to return if member not found
///
/// # Returns - (mat4x4):
/// 3x4 matrix as mat4x4 or defaultValue
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3GetMemberMatrix3x4(kv: usize, name: &Str, defaultValue: &Mat4x4) -> Mat4x4 {
    unsafe { __s2sdk_Kv3GetMemberMatrix3x4.expect("Kv3GetMemberMatrix3x4 function was not found")(kv, name, defaultValue) }
}
pub type _Kv3GetMemberMatrix3x4 = unsafe extern "C" fn(usize, &Str, &Mat4x4) -> Mat4x4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3GetMemberMatrix3x4: Option<_Kv3GetMemberMatrix3x4> = None;

/// Sets a table member to null
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberToNull(kv: usize, name: &Str) {
    unsafe { __s2sdk_Kv3SetMemberToNull.expect("Kv3SetMemberToNull function was not found")(kv, name) }
}
pub type _Kv3SetMemberToNull = unsafe extern "C" fn(usize, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberToNull: Option<_Kv3SetMemberToNull> = None;

/// Sets a table member to an empty array
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberToEmptyArray(kv: usize, name: &Str) {
    unsafe { __s2sdk_Kv3SetMemberToEmptyArray.expect("Kv3SetMemberToEmptyArray function was not found")(kv, name) }
}
pub type _Kv3SetMemberToEmptyArray = unsafe extern "C" fn(usize, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberToEmptyArray: Option<_Kv3SetMemberToEmptyArray> = None;

/// Sets a table member to an empty table
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberToEmptyTable(kv: usize, name: &Str) {
    unsafe { __s2sdk_Kv3SetMemberToEmptyTable.expect("Kv3SetMemberToEmptyTable function was not found")(kv, name) }
}
pub type _Kv3SetMemberToEmptyTable = unsafe extern "C" fn(usize, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberToEmptyTable: Option<_Kv3SetMemberToEmptyTable> = None;

/// Sets a table member to a binary blob (copies the data)
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `blob` - (uint8[]): Vector containing the binary blob data
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberToBinaryBlob(kv: usize, name: &Str, blob: &Arr<u8>) {
    unsafe { __s2sdk_Kv3SetMemberToBinaryBlob.expect("Kv3SetMemberToBinaryBlob function was not found")(kv, name, blob) }
}
pub type _Kv3SetMemberToBinaryBlob = unsafe extern "C" fn(usize, &Str, &Arr<u8>);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberToBinaryBlob: Option<_Kv3SetMemberToBinaryBlob> = None;

/// Sets a table member to an external binary blob (does not copy)
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `blob` - (uint8[]): Vector containing the external binary blob data
/// * `free_mem` - (bool): Whether to free the memory when the object is destroyed
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberToBinaryBlobExternal(kv: usize, name: &Str, blob: &Arr<u8>, free_mem: bool) {
    unsafe { __s2sdk_Kv3SetMemberToBinaryBlobExternal.expect("Kv3SetMemberToBinaryBlobExternal function was not found")(kv, name, blob, free_mem) }
}
pub type _Kv3SetMemberToBinaryBlobExternal = unsafe extern "C" fn(usize, &Str, &Arr<u8>, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberToBinaryBlobExternal: Option<_Kv3SetMemberToBinaryBlobExternal> = None;

/// Sets a table member to a copy of another KeyValues3 value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `other` - (ptr64): Pointer to the KeyValues3 object to copy
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberToCopyOfValue(kv: usize, name: &Str, other: usize) {
    unsafe { __s2sdk_Kv3SetMemberToCopyOfValue.expect("Kv3SetMemberToCopyOfValue function was not found")(kv, name, other) }
}
pub type _Kv3SetMemberToCopyOfValue = unsafe extern "C" fn(usize, &Str, usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberToCopyOfValue: Option<_Kv3SetMemberToCopyOfValue> = None;

/// Sets a table member to a boolean value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (bool): Boolean value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberBool(kv: usize, name: &Str, value: bool) {
    unsafe { __s2sdk_Kv3SetMemberBool.expect("Kv3SetMemberBool function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberBool = unsafe extern "C" fn(usize, &Str, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberBool: Option<_Kv3SetMemberBool> = None;

/// Sets a table member to a char value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (char8): Char value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberChar(kv: usize, name: &Str, value: i8) {
    unsafe { __s2sdk_Kv3SetMemberChar.expect("Kv3SetMemberChar function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberChar = unsafe extern "C" fn(usize, &Str, i8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberChar: Option<_Kv3SetMemberChar> = None;

/// Sets a table member to a 32-bit Unicode character value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (uint32): 32-bit Unicode character value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberUChar32(kv: usize, name: &Str, value: u32) {
    unsafe { __s2sdk_Kv3SetMemberUChar32.expect("Kv3SetMemberUChar32 function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberUChar32 = unsafe extern "C" fn(usize, &Str, u32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberUChar32: Option<_Kv3SetMemberUChar32> = None;

/// Sets a table member to a signed 8-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (int8): int8_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberInt8(kv: usize, name: &Str, value: i8) {
    unsafe { __s2sdk_Kv3SetMemberInt8.expect("Kv3SetMemberInt8 function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberInt8 = unsafe extern "C" fn(usize, &Str, i8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberInt8: Option<_Kv3SetMemberInt8> = None;

/// Sets a table member to an unsigned 8-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (uint8): uint8_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberUInt8(kv: usize, name: &Str, value: u8) {
    unsafe { __s2sdk_Kv3SetMemberUInt8.expect("Kv3SetMemberUInt8 function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberUInt8 = unsafe extern "C" fn(usize, &Str, u8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberUInt8: Option<_Kv3SetMemberUInt8> = None;

/// Sets a table member to a signed 16-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (int16): int16_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberShort(kv: usize, name: &Str, value: i16) {
    unsafe { __s2sdk_Kv3SetMemberShort.expect("Kv3SetMemberShort function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberShort = unsafe extern "C" fn(usize, &Str, i16);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberShort: Option<_Kv3SetMemberShort> = None;

/// Sets a table member to an unsigned 16-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (uint16): uint16_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberUShort(kv: usize, name: &Str, value: u16) {
    unsafe { __s2sdk_Kv3SetMemberUShort.expect("Kv3SetMemberUShort function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberUShort = unsafe extern "C" fn(usize, &Str, u16);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberUShort: Option<_Kv3SetMemberUShort> = None;

/// Sets a table member to a signed 32-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (int32): int32_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberInt(kv: usize, name: &Str, value: i32) {
    unsafe { __s2sdk_Kv3SetMemberInt.expect("Kv3SetMemberInt function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberInt = unsafe extern "C" fn(usize, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberInt: Option<_Kv3SetMemberInt> = None;

/// Sets a table member to an unsigned 32-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (uint32): uint32_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberUInt(kv: usize, name: &Str, value: u32) {
    unsafe { __s2sdk_Kv3SetMemberUInt.expect("Kv3SetMemberUInt function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberUInt = unsafe extern "C" fn(usize, &Str, u32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberUInt: Option<_Kv3SetMemberUInt> = None;

/// Sets a table member to a signed 64-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (int64): int64_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberInt64(kv: usize, name: &Str, value: i64) {
    unsafe { __s2sdk_Kv3SetMemberInt64.expect("Kv3SetMemberInt64 function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberInt64 = unsafe extern "C" fn(usize, &Str, i64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberInt64: Option<_Kv3SetMemberInt64> = None;

/// Sets a table member to an unsigned 64-bit integer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (uint64): uint64_t value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberUInt64(kv: usize, name: &Str, value: u64) {
    unsafe { __s2sdk_Kv3SetMemberUInt64.expect("Kv3SetMemberUInt64 function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberUInt64 = unsafe extern "C" fn(usize, &Str, u64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberUInt64: Option<_Kv3SetMemberUInt64> = None;

/// Sets a table member to a float value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (float): Float value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberFloat(kv: usize, name: &Str, value: f32) {
    unsafe { __s2sdk_Kv3SetMemberFloat.expect("Kv3SetMemberFloat function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberFloat = unsafe extern "C" fn(usize, &Str, f32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberFloat: Option<_Kv3SetMemberFloat> = None;

/// Sets a table member to a double value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `value` - (double): Double value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberDouble(kv: usize, name: &Str, value: f64) {
    unsafe { __s2sdk_Kv3SetMemberDouble.expect("Kv3SetMemberDouble function was not found")(kv, name, value) }
}
pub type _Kv3SetMemberDouble = unsafe extern "C" fn(usize, &Str, f64);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberDouble: Option<_Kv3SetMemberDouble> = None;

/// Sets a table member to a pointer value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `ptr` - (ptr64): Pointer value as uintptr_t to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberPointer(kv: usize, name: &Str, ptr: usize) {
    unsafe { __s2sdk_Kv3SetMemberPointer.expect("Kv3SetMemberPointer function was not found")(kv, name, ptr) }
}
pub type _Kv3SetMemberPointer = unsafe extern "C" fn(usize, &Str, usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberPointer: Option<_Kv3SetMemberPointer> = None;

/// Sets a table member to a string token value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `token` - (uint32): String token hash code to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberStringToken(kv: usize, name: &Str, token: u32) {
    unsafe { __s2sdk_Kv3SetMemberStringToken.expect("Kv3SetMemberStringToken function was not found")(kv, name, token) }
}
pub type _Kv3SetMemberStringToken = unsafe extern "C" fn(usize, &Str, u32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberStringToken: Option<_Kv3SetMemberStringToken> = None;

/// Sets a table member to an entity handle value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `ehandle` - (int32): Entity handle value to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberEHandle(kv: usize, name: &Str, ehandle: i32) {
    unsafe { __s2sdk_Kv3SetMemberEHandle.expect("Kv3SetMemberEHandle function was not found")(kv, name, ehandle) }
}
pub type _Kv3SetMemberEHandle = unsafe extern "C" fn(usize, &Str, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberEHandle: Option<_Kv3SetMemberEHandle> = None;

/// Sets a table member to a string value (copies the string)
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `str` - (string): String value to set
/// * `subtype` - (uint8): String subtype enumeration value
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberString(kv: usize, name: &Str, str: &Str, subtype: u8) {
    unsafe { __s2sdk_Kv3SetMemberString.expect("Kv3SetMemberString function was not found")(kv, name, str, subtype) }
}
pub type _Kv3SetMemberString = unsafe extern "C" fn(usize, &Str, &Str, u8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberString: Option<_Kv3SetMemberString> = None;

/// Sets a table member to an external string value (does not copy)
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `str` - (string): External string value to reference
/// * `subtype` - (uint8): String subtype enumeration value
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberStringExternal(kv: usize, name: &Str, str: &Str, subtype: u8) {
    unsafe { __s2sdk_Kv3SetMemberStringExternal.expect("Kv3SetMemberStringExternal function was not found")(kv, name, str, subtype) }
}
pub type _Kv3SetMemberStringExternal = unsafe extern "C" fn(usize, &Str, &Str, u8);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberStringExternal: Option<_Kv3SetMemberStringExternal> = None;

/// Sets a table member to a color value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `color` - (vec4): Color value as vec4 to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberColor(kv: usize, name: &Str, color: &Vec4) {
    unsafe { __s2sdk_Kv3SetMemberColor.expect("Kv3SetMemberColor function was not found")(kv, name, color) }
}
pub type _Kv3SetMemberColor = unsafe extern "C" fn(usize, &Str, &Vec4);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberColor: Option<_Kv3SetMemberColor> = None;

/// Sets a table member to a 3D vector value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `vec` - (vec3): 3D vector to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberVector(kv: usize, name: &Str, vec: &Vec3) {
    unsafe { __s2sdk_Kv3SetMemberVector.expect("Kv3SetMemberVector function was not found")(kv, name, vec) }
}
pub type _Kv3SetMemberVector = unsafe extern "C" fn(usize, &Str, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberVector: Option<_Kv3SetMemberVector> = None;

/// Sets a table member to a 2D vector value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `vec2d` - (vec2): 2D vector to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberVector2D(kv: usize, name: &Str, vec2d: &Vec2) {
    unsafe { __s2sdk_Kv3SetMemberVector2D.expect("Kv3SetMemberVector2D function was not found")(kv, name, vec2d) }
}
pub type _Kv3SetMemberVector2D = unsafe extern "C" fn(usize, &Str, &Vec2);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberVector2D: Option<_Kv3SetMemberVector2D> = None;

/// Sets a table member to a 4D vector value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `vec4d` - (vec4): 4D vector to set
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberVector4D(kv: usize, name: &Str, vec4d: &Vec4) {
    unsafe { __s2sdk_Kv3SetMemberVector4D.expect("Kv3SetMemberVector4D function was not found")(kv, name, vec4d) }
}
pub type _Kv3SetMemberVector4D = unsafe extern "C" fn(usize, &Str, &Vec4);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberVector4D: Option<_Kv3SetMemberVector4D> = None;

/// Sets a table member to a quaternion value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `quat` - (vec4): Quaternion to set (as vec4)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberQuaternion(kv: usize, name: &Str, quat: &Vec4) {
    unsafe { __s2sdk_Kv3SetMemberQuaternion.expect("Kv3SetMemberQuaternion function was not found")(kv, name, quat) }
}
pub type _Kv3SetMemberQuaternion = unsafe extern "C" fn(usize, &Str, &Vec4);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberQuaternion: Option<_Kv3SetMemberQuaternion> = None;

/// Sets a table member to an angle (QAngle) value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `ang` - (vec3): QAngle to set (as vec3)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberQAngle(kv: usize, name: &Str, ang: &Vec3) {
    unsafe { __s2sdk_Kv3SetMemberQAngle.expect("Kv3SetMemberQAngle function was not found")(kv, name, ang) }
}
pub type _Kv3SetMemberQAngle = unsafe extern "C" fn(usize, &Str, &Vec3);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberQAngle: Option<_Kv3SetMemberQAngle> = None;

/// Sets a table member to a 3x4 matrix value
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `name` - (string): Name of the member
/// * `matrix` - (mat4x4): 3x4 matrix to set (as mat4x4)
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SetMemberMatrix3x4(kv: usize, name: &Str, matrix: &Mat4x4) {
    unsafe { __s2sdk_Kv3SetMemberMatrix3x4.expect("Kv3SetMemberMatrix3x4 function was not found")(kv, name, matrix) }
}
pub type _Kv3SetMemberMatrix3x4 = unsafe extern "C" fn(usize, &Str, &Mat4x4);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SetMemberMatrix3x4: Option<_Kv3SetMemberMatrix3x4> = None;

/// Prints debug information about the KeyValues3 object
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3DebugPrint(kv: usize) {
    unsafe { __s2sdk_Kv3DebugPrint.expect("Kv3DebugPrint function was not found")(kv) }
}
pub type _Kv3DebugPrint = unsafe extern "C" fn(usize);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3DebugPrint: Option<_Kv3DebugPrint> = None;

/// Loads KeyValues3 data from a buffer into a context
///
/// # Arguments
/// * `context` - (ptr64): Pointer to the KeyValues3 context
/// * `error` - (string&): Output string for error messages
/// * `input` - (uint8[]): Vector containing the input buffer data
/// * `kv_name` - (string): Name for the KeyValues3 object
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadFromBuffer(context: usize, error: &mut Str, input: &Arr<u8>, kv_name: &Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadFromBuffer.expect("Kv3LoadFromBuffer function was not found")(context, error, input, kv_name, flags) }
}
pub type _Kv3LoadFromBuffer = unsafe extern "C" fn(usize, &mut Str, &Arr<u8>, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadFromBuffer: Option<_Kv3LoadFromBuffer> = None;

/// Loads KeyValues3 data from a buffer
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `input` - (uint8[]): Vector containing the input buffer data
/// * `kv_name` - (string): Name for the KeyValues3 object
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3Load(kv: usize, error: &mut Str, input: &Arr<u8>, kv_name: &Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3Load.expect("Kv3Load function was not found")(kv, error, input, kv_name, flags) }
}
pub type _Kv3Load = unsafe extern "C" fn(usize, &mut Str, &Arr<u8>, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3Load: Option<_Kv3Load> = None;

/// Loads KeyValues3 data from a text string
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `input` - (string): Text string containing KV3 data
/// * `kv_name` - (string): Name for the KeyValues3 object
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadFromText(kv: usize, error: &mut Str, input: &Str, kv_name: &Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadFromText.expect("Kv3LoadFromText function was not found")(kv, error, input, kv_name, flags) }
}
pub type _Kv3LoadFromText = unsafe extern "C" fn(usize, &mut Str, &Str, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadFromText: Option<_Kv3LoadFromText> = None;

/// Loads KeyValues3 data from a file into a context
///
/// # Arguments
/// * `context` - (ptr64): Pointer to the KeyValues3 context
/// * `error` - (string&): Output string for error messages
/// * `filename` - (string): Name of the file to load
/// * `path` - (string): Path to the file
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadFromFileToContext(context: usize, error: &mut Str, filename: &Str, path: &Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadFromFileToContext.expect("Kv3LoadFromFileToContext function was not found")(context, error, filename, path, flags) }
}
pub type _Kv3LoadFromFileToContext = unsafe extern "C" fn(usize, &mut Str, &Str, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadFromFileToContext: Option<_Kv3LoadFromFileToContext> = None;

/// Loads KeyValues3 data from a file
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `filename` - (string): Name of the file to load
/// * `path` - (string): Path to the file
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadFromFile(kv: usize, error: &mut Str, filename: &Str, path: &Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadFromFile.expect("Kv3LoadFromFile function was not found")(kv, error, filename, path, flags) }
}
pub type _Kv3LoadFromFile = unsafe extern "C" fn(usize, &mut Str, &Str, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadFromFile: Option<_Kv3LoadFromFile> = None;

/// Loads KeyValues3 data from a JSON string
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `input` - (string): JSON string
/// * `kv_name` - (string): Name for the KeyValues3 object
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadFromJSON(kv: usize, error: &mut Str, input: &Str, kv_name: &Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadFromJSON.expect("Kv3LoadFromJSON function was not found")(kv, error, input, kv_name, flags) }
}
pub type _Kv3LoadFromJSON = unsafe extern "C" fn(usize, &mut Str, &Str, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadFromJSON: Option<_Kv3LoadFromJSON> = None;

/// Loads KeyValues3 data from a JSON file
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `path` - (string): Path to the file
/// * `filename` - (string): Name of the file to load
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadFromJSONFile(kv: usize, error: &mut Str, path: &Str, filename: &Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadFromJSONFile.expect("Kv3LoadFromJSONFile function was not found")(kv, error, path, filename, flags) }
}
pub type _Kv3LoadFromJSONFile = unsafe extern "C" fn(usize, &mut Str, &Str, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadFromJSONFile: Option<_Kv3LoadFromJSONFile> = None;

/// Loads KeyValues3 data from a KeyValues1 file
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `path` - (string): Path to the file
/// * `filename` - (string): Name of the file to load
/// * `esc_behavior` - (uint8): Escape sequence behavior for KV1 text
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadFromKV1File(kv: usize, error: &mut Str, path: &Str, filename: &Str, esc_behavior: u8, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadFromKV1File.expect("Kv3LoadFromKV1File function was not found")(kv, error, path, filename, esc_behavior, flags) }
}
pub type _Kv3LoadFromKV1File = unsafe extern "C" fn(usize, &mut Str, &Str, &Str, u8, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadFromKV1File: Option<_Kv3LoadFromKV1File> = None;

/// Loads KeyValues3 data from a KeyValues1 text string
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `input` - (string): KV1 text string
/// * `esc_behavior` - (uint8): Escape sequence behavior for KV1 text
/// * `kv_name` - (string): Name for the KeyValues3 object
/// * `unk` - (bool): Unknown boolean parameter
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadFromKV1Text(kv: usize, error: &mut Str, input: &Str, esc_behavior: u8, kv_name: &Str, unk: bool, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadFromKV1Text.expect("Kv3LoadFromKV1Text function was not found")(kv, error, input, esc_behavior, kv_name, unk, flags) }
}
pub type _Kv3LoadFromKV1Text = unsafe extern "C" fn(usize, &mut Str, &Str, u8, &Str, bool, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadFromKV1Text: Option<_Kv3LoadFromKV1Text> = None;

/// Loads KeyValues3 data from a KeyValues1 text string with translation
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `input` - (string): KV1 text string
/// * `esc_behavior` - (uint8): Escape sequence behavior for KV1 text
/// * `translation` - (ptr64): Pointer to translation table
/// * `unk1` - (int32): Unknown integer parameter
/// * `kv_name` - (string): Name for the KeyValues3 object
/// * `unk2` - (bool): Unknown boolean parameter
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadFromKV1TextTranslated(kv: usize, error: &mut Str, input: &Str, esc_behavior: u8, translation: usize, unk1: i32, kv_name: &Str, unk2: bool, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadFromKV1TextTranslated.expect("Kv3LoadFromKV1TextTranslated function was not found")(kv, error, input, esc_behavior, translation, unk1, kv_name, unk2, flags) }
}
pub type _Kv3LoadFromKV1TextTranslated = unsafe extern "C" fn(usize, &mut Str, &Str, u8, usize, i32, &Str, bool, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadFromKV1TextTranslated: Option<_Kv3LoadFromKV1TextTranslated> = None;

/// Loads data from a buffer that may be KV3 or KV1 format
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `input` - (uint8[]): Vector containing the input buffer data
/// * `kv_name` - (string): Name for the KeyValues3 object
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadFromKV3OrKV1(kv: usize, error: &mut Str, input: &Arr<u8>, kv_name: &Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadFromKV3OrKV1.expect("Kv3LoadFromKV3OrKV1 function was not found")(kv, error, input, kv_name, flags) }
}
pub type _Kv3LoadFromKV3OrKV1 = unsafe extern "C" fn(usize, &mut Str, &Arr<u8>, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadFromKV3OrKV1: Option<_Kv3LoadFromKV3OrKV1> = None;

/// Loads KeyValues3 data from old schema text format
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `input` - (uint8[]): Vector containing the input buffer data
/// * `kv_name` - (string): Name for the KeyValues3 object
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadFromOldSchemaText(kv: usize, error: &mut Str, input: &Arr<u8>, kv_name: &Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadFromOldSchemaText.expect("Kv3LoadFromOldSchemaText function was not found")(kv, error, input, kv_name, flags) }
}
pub type _Kv3LoadFromOldSchemaText = unsafe extern "C" fn(usize, &mut Str, &Arr<u8>, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadFromOldSchemaText: Option<_Kv3LoadFromOldSchemaText> = None;

/// Loads KeyValues3 text without a header
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `input` - (string): Text string containing KV3 data
/// * `kv_name` - (string): Name for the KeyValues3 object
/// * `flags` - (uint32): Loading flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3LoadTextNoHeader(kv: usize, error: &mut Str, input: &Str, kv_name: &Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3LoadTextNoHeader.expect("Kv3LoadTextNoHeader function was not found")(kv, error, input, kv_name, flags) }
}
pub type _Kv3LoadTextNoHeader = unsafe extern "C" fn(usize, &mut Str, &Str, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3LoadTextNoHeader: Option<_Kv3LoadTextNoHeader> = None;

/// Saves KeyValues3 data to a buffer
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `output` - (uint8[]&): Vector to store the output buffer data
/// * `flags` - (uint32): Saving flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3Save(kv: usize, error: &mut Str, output: &mut Arr<u8>, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3Save.expect("Kv3Save function was not found")(kv, error, output, flags) }
}
pub type _Kv3Save = unsafe extern "C" fn(usize, &mut Str, &mut Arr<u8>, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3Save: Option<_Kv3Save> = None;

/// Saves KeyValues3 data as JSON to a buffer
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `output` - (uint8[]&): Vector to store the output JSON data
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SaveAsJSON(kv: usize, error: &mut Str, output: &mut Arr<u8>) -> bool {
    unsafe { __s2sdk_Kv3SaveAsJSON.expect("Kv3SaveAsJSON function was not found")(kv, error, output) }
}
pub type _Kv3SaveAsJSON = unsafe extern "C" fn(usize, &mut Str, &mut Arr<u8>) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SaveAsJSON: Option<_Kv3SaveAsJSON> = None;

/// Saves KeyValues3 data as a JSON string
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `output` - (string&): String to store the JSON output
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SaveAsJSONString(kv: usize, error: &mut Str, output: &mut Str) -> bool {
    unsafe { __s2sdk_Kv3SaveAsJSONString.expect("Kv3SaveAsJSONString function was not found")(kv, error, output) }
}
pub type _Kv3SaveAsJSONString = unsafe extern "C" fn(usize, &mut Str, &mut Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SaveAsJSONString: Option<_Kv3SaveAsJSONString> = None;

/// Saves KeyValues3 data as KeyValues1 text to a buffer
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `output` - (uint8[]&): Vector to store the output KV1 text data
/// * `esc_behavior` - (uint8): Escape sequence behavior for KV1 text
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SaveAsKV1Text(kv: usize, error: &mut Str, output: &mut Arr<u8>, esc_behavior: u8) -> bool {
    unsafe { __s2sdk_Kv3SaveAsKV1Text.expect("Kv3SaveAsKV1Text function was not found")(kv, error, output, esc_behavior) }
}
pub type _Kv3SaveAsKV1Text = unsafe extern "C" fn(usize, &mut Str, &mut Arr<u8>, u8) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SaveAsKV1Text: Option<_Kv3SaveAsKV1Text> = None;

/// Saves KeyValues3 data as KeyValues1 text with translation to a buffer
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `output` - (uint8[]&): Vector to store the output KV1 text data
/// * `esc_behavior` - (uint8): Escape sequence behavior for KV1 text
/// * `translation` - (ptr64): Pointer to translation table
/// * `unk` - (int32): Unknown integer parameter
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SaveAsKV1TextTranslated(kv: usize, error: &mut Str, output: &mut Arr<u8>, esc_behavior: u8, translation: usize, unk: i32) -> bool {
    unsafe { __s2sdk_Kv3SaveAsKV1TextTranslated.expect("Kv3SaveAsKV1TextTranslated function was not found")(kv, error, output, esc_behavior, translation, unk) }
}
pub type _Kv3SaveAsKV1TextTranslated = unsafe extern "C" fn(usize, &mut Str, &mut Arr<u8>, u8, usize, i32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SaveAsKV1TextTranslated: Option<_Kv3SaveAsKV1TextTranslated> = None;

/// Saves KeyValues3 text without a header to a buffer
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `output` - (uint8[]&): Vector to store the output text data
/// * `flags` - (uint32): Saving flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SaveTextNoHeaderToBuffer(kv: usize, error: &mut Str, output: &mut Arr<u8>, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3SaveTextNoHeaderToBuffer.expect("Kv3SaveTextNoHeaderToBuffer function was not found")(kv, error, output, flags) }
}
pub type _Kv3SaveTextNoHeaderToBuffer = unsafe extern "C" fn(usize, &mut Str, &mut Arr<u8>, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SaveTextNoHeaderToBuffer: Option<_Kv3SaveTextNoHeaderToBuffer> = None;

/// Saves KeyValues3 text without a header to a string
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `output` - (string&): String to store the text output
/// * `flags` - (uint32): Saving flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SaveTextNoHeader(kv: usize, error: &mut Str, output: &mut Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3SaveTextNoHeader.expect("Kv3SaveTextNoHeader function was not found")(kv, error, output, flags) }
}
pub type _Kv3SaveTextNoHeader = unsafe extern "C" fn(usize, &mut Str, &mut Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SaveTextNoHeader: Option<_Kv3SaveTextNoHeader> = None;

/// Saves KeyValues3 text to a string
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `output` - (string&): String to store the text output
/// * `flags` - (uint32): Saving flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SaveTextToString(kv: usize, error: &mut Str, output: &mut Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3SaveTextToString.expect("Kv3SaveTextToString function was not found")(kv, error, output, flags) }
}
pub type _Kv3SaveTextToString = unsafe extern "C" fn(usize, &mut Str, &mut Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SaveTextToString: Option<_Kv3SaveTextToString> = None;

/// Saves KeyValues3 data to a file
///
/// # Arguments
/// * `kv` - (ptr64): Pointer to the KeyValues3 object
/// * `error` - (string&): Output string for error messages
/// * `filename` - (string): Name of the file to save
/// * `path` - (string): Path to save the file
/// * `flags` - (uint32): Saving flags
///
/// # Returns - (bool):
/// true if successful, false otherwise
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn Kv3SaveToFile(kv: usize, error: &mut Str, filename: &Str, path: &Str, flags: u32) -> bool {
    unsafe { __s2sdk_Kv3SaveToFile.expect("Kv3SaveToFile function was not found")(kv, error, filename, path, flags) }
}
pub type _Kv3SaveToFile = unsafe extern "C" fn(usize, &mut Str, &Str, &Str, u32) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_Kv3SaveToFile: Option<_Kv3SaveToFile> = None;

