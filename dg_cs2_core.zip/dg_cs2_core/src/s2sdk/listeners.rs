// Generated from s2sdk.pplugin (group: listeners)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientConnect_Register(callback: OnClientConnectCallback) {
    unsafe { __s2sdk_OnClientConnect_Register.expect("OnClientConnect_Register function was not found")(callback) }
}
pub type _OnClientConnect_Register = unsafe extern "C" fn(OnClientConnectCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientConnect_Register: Option<_OnClientConnect_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientConnect_Unregister(callback: OnClientConnectCallback) {
    unsafe { __s2sdk_OnClientConnect_Unregister.expect("OnClientConnect_Unregister function was not found")(callback) }
}
pub type _OnClientConnect_Unregister = unsafe extern "C" fn(OnClientConnectCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientConnect_Unregister: Option<_OnClientConnect_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientConnect_Post_Register(callback: OnClientConnect_PostCallback) {
    unsafe { __s2sdk_OnClientConnect_Post_Register.expect("OnClientConnect_Post_Register function was not found")(callback) }
}
pub type _OnClientConnect_Post_Register = unsafe extern "C" fn(OnClientConnect_PostCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientConnect_Post_Register: Option<_OnClientConnect_Post_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientConnect_Post_Unregister(callback: OnClientConnect_PostCallback) {
    unsafe { __s2sdk_OnClientConnect_Post_Unregister.expect("OnClientConnect_Post_Unregister function was not found")(callback) }
}
pub type _OnClientConnect_Post_Unregister = unsafe extern "C" fn(OnClientConnect_PostCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientConnect_Post_Unregister: Option<_OnClientConnect_Post_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientConnected_Register(callback: OnClientConnectedCallback) {
    unsafe { __s2sdk_OnClientConnected_Register.expect("OnClientConnected_Register function was not found")(callback) }
}
pub type _OnClientConnected_Register = unsafe extern "C" fn(OnClientConnectedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientConnected_Register: Option<_OnClientConnected_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientConnected_Unregister(callback: OnClientConnectedCallback) {
    unsafe { __s2sdk_OnClientConnected_Unregister.expect("OnClientConnected_Unregister function was not found")(callback) }
}
pub type _OnClientConnected_Unregister = unsafe extern "C" fn(OnClientConnectedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientConnected_Unregister: Option<_OnClientConnected_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientPutInServer_Register(callback: OnClientPutInServerCallback) {
    unsafe { __s2sdk_OnClientPutInServer_Register.expect("OnClientPutInServer_Register function was not found")(callback) }
}
pub type _OnClientPutInServer_Register = unsafe extern "C" fn(OnClientPutInServerCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientPutInServer_Register: Option<_OnClientPutInServer_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientPutInServer_Unregister(callback: OnClientPutInServerCallback) {
    unsafe { __s2sdk_OnClientPutInServer_Unregister.expect("OnClientPutInServer_Unregister function was not found")(callback) }
}
pub type _OnClientPutInServer_Unregister = unsafe extern "C" fn(OnClientPutInServerCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientPutInServer_Unregister: Option<_OnClientPutInServer_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientDisconnect_Register(callback: OnClientDisconnectCallback) {
    unsafe { __s2sdk_OnClientDisconnect_Register.expect("OnClientDisconnect_Register function was not found")(callback) }
}
pub type _OnClientDisconnect_Register = unsafe extern "C" fn(OnClientDisconnectCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientDisconnect_Register: Option<_OnClientDisconnect_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientDisconnect_Unregister(callback: OnClientDisconnectCallback) {
    unsafe { __s2sdk_OnClientDisconnect_Unregister.expect("OnClientDisconnect_Unregister function was not found")(callback) }
}
pub type _OnClientDisconnect_Unregister = unsafe extern "C" fn(OnClientDisconnectCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientDisconnect_Unregister: Option<_OnClientDisconnect_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientDisconnect_Post_Register(callback: OnClientDisconnect_PostCallback) {
    unsafe { __s2sdk_OnClientDisconnect_Post_Register.expect("OnClientDisconnect_Post_Register function was not found")(callback) }
}
pub type _OnClientDisconnect_Post_Register = unsafe extern "C" fn(OnClientDisconnect_PostCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientDisconnect_Post_Register: Option<_OnClientDisconnect_Post_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientDisconnect_Post_Unregister(callback: OnClientDisconnect_PostCallback) {
    unsafe { __s2sdk_OnClientDisconnect_Post_Unregister.expect("OnClientDisconnect_Post_Unregister function was not found")(callback) }
}
pub type _OnClientDisconnect_Post_Unregister = unsafe extern "C" fn(OnClientDisconnect_PostCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientDisconnect_Post_Unregister: Option<_OnClientDisconnect_Post_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientActive_Register(callback: OnClientActiveCallback) {
    unsafe { __s2sdk_OnClientActive_Register.expect("OnClientActive_Register function was not found")(callback) }
}
pub type _OnClientActive_Register = unsafe extern "C" fn(OnClientActiveCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientActive_Register: Option<_OnClientActive_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientActive_Unregister(callback: OnClientActiveCallback) {
    unsafe { __s2sdk_OnClientActive_Unregister.expect("OnClientActive_Unregister function was not found")(callback) }
}
pub type _OnClientActive_Unregister = unsafe extern "C" fn(OnClientActiveCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientActive_Unregister: Option<_OnClientActive_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientFullyConnect_Register(callback: OnClientFullyConnectCallback) {
    unsafe { __s2sdk_OnClientFullyConnect_Register.expect("OnClientFullyConnect_Register function was not found")(callback) }
}
pub type _OnClientFullyConnect_Register = unsafe extern "C" fn(OnClientFullyConnectCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientFullyConnect_Register: Option<_OnClientFullyConnect_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientFullyConnect_Unregister(callback: OnClientFullyConnectCallback) {
    unsafe { __s2sdk_OnClientFullyConnect_Unregister.expect("OnClientFullyConnect_Unregister function was not found")(callback) }
}
pub type _OnClientFullyConnect_Unregister = unsafe extern "C" fn(OnClientFullyConnectCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientFullyConnect_Unregister: Option<_OnClientFullyConnect_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientSettingsChanged_Register(callback: OnClientSettingsChangedCallback) {
    unsafe { __s2sdk_OnClientSettingsChanged_Register.expect("OnClientSettingsChanged_Register function was not found")(callback) }
}
pub type _OnClientSettingsChanged_Register = unsafe extern "C" fn(OnClientSettingsChangedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientSettingsChanged_Register: Option<_OnClientSettingsChanged_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientSettingsChanged_Unregister(callback: OnClientSettingsChangedCallback) {
    unsafe { __s2sdk_OnClientSettingsChanged_Unregister.expect("OnClientSettingsChanged_Unregister function was not found")(callback) }
}
pub type _OnClientSettingsChanged_Unregister = unsafe extern "C" fn(OnClientSettingsChangedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientSettingsChanged_Unregister: Option<_OnClientSettingsChanged_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientAuthenticated_Register(callback: OnClientAuthenticatedCallback) {
    unsafe { __s2sdk_OnClientAuthenticated_Register.expect("OnClientAuthenticated_Register function was not found")(callback) }
}
pub type _OnClientAuthenticated_Register = unsafe extern "C" fn(OnClientAuthenticatedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientAuthenticated_Register: Option<_OnClientAuthenticated_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnClientAuthenticated_Unregister(callback: OnClientAuthenticatedCallback) {
    unsafe { __s2sdk_OnClientAuthenticated_Unregister.expect("OnClientAuthenticated_Unregister function was not found")(callback) }
}
pub type _OnClientAuthenticated_Unregister = unsafe extern "C" fn(OnClientAuthenticatedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnClientAuthenticated_Unregister: Option<_OnClientAuthenticated_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnRoundTerminated_Register(callback: OnRoundTerminatedCallback) {
    unsafe { __s2sdk_OnRoundTerminated_Register.expect("OnRoundTerminated_Register function was not found")(callback) }
}
pub type _OnRoundTerminated_Register = unsafe extern "C" fn(OnRoundTerminatedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnRoundTerminated_Register: Option<_OnRoundTerminated_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnRoundTerminated_Unregister(callback: OnRoundTerminatedCallback) {
    unsafe { __s2sdk_OnRoundTerminated_Unregister.expect("OnRoundTerminated_Unregister function was not found")(callback) }
}
pub type _OnRoundTerminated_Unregister = unsafe extern "C" fn(OnRoundTerminatedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnRoundTerminated_Unregister: Option<_OnRoundTerminated_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnEntityCreated_Register(callback: OnEntityCreatedCallback) {
    unsafe { __s2sdk_OnEntityCreated_Register.expect("OnEntityCreated_Register function was not found")(callback) }
}
pub type _OnEntityCreated_Register = unsafe extern "C" fn(OnEntityCreatedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnEntityCreated_Register: Option<_OnEntityCreated_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnEntityCreated_Unregister(callback: OnEntityCreatedCallback) {
    unsafe { __s2sdk_OnEntityCreated_Unregister.expect("OnEntityCreated_Unregister function was not found")(callback) }
}
pub type _OnEntityCreated_Unregister = unsafe extern "C" fn(OnEntityCreatedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnEntityCreated_Unregister: Option<_OnEntityCreated_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnEntityDeleted_Register(callback: OnEntityDeletedCallback) {
    unsafe { __s2sdk_OnEntityDeleted_Register.expect("OnEntityDeleted_Register function was not found")(callback) }
}
pub type _OnEntityDeleted_Register = unsafe extern "C" fn(OnEntityDeletedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnEntityDeleted_Register: Option<_OnEntityDeleted_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnEntityDeleted_Unregister(callback: OnEntityDeletedCallback) {
    unsafe { __s2sdk_OnEntityDeleted_Unregister.expect("OnEntityDeleted_Unregister function was not found")(callback) }
}
pub type _OnEntityDeleted_Unregister = unsafe extern "C" fn(OnEntityDeletedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnEntityDeleted_Unregister: Option<_OnEntityDeleted_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnEntityParentChanged_Register(callback: OnEntityParentChangedCallback) {
    unsafe { __s2sdk_OnEntityParentChanged_Register.expect("OnEntityParentChanged_Register function was not found")(callback) }
}
pub type _OnEntityParentChanged_Register = unsafe extern "C" fn(OnEntityParentChangedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnEntityParentChanged_Register: Option<_OnEntityParentChanged_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnEntityParentChanged_Unregister(callback: OnEntityParentChangedCallback) {
    unsafe { __s2sdk_OnEntityParentChanged_Unregister.expect("OnEntityParentChanged_Unregister function was not found")(callback) }
}
pub type _OnEntityParentChanged_Unregister = unsafe extern "C" fn(OnEntityParentChangedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnEntityParentChanged_Unregister: Option<_OnEntityParentChanged_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnServerCheckTransmit_Register(callback: OnServerCheckTransmitCallback) {
    unsafe { __s2sdk_OnServerCheckTransmit_Register.expect("OnServerCheckTransmit_Register function was not found")(callback) }
}
pub type _OnServerCheckTransmit_Register = unsafe extern "C" fn(OnServerCheckTransmitCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnServerCheckTransmit_Register: Option<_OnServerCheckTransmit_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnServerCheckTransmit_Unregister(callback: OnServerCheckTransmitCallback) {
    unsafe { __s2sdk_OnServerCheckTransmit_Unregister.expect("OnServerCheckTransmit_Unregister function was not found")(callback) }
}
pub type _OnServerCheckTransmit_Unregister = unsafe extern "C" fn(OnServerCheckTransmitCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnServerCheckTransmit_Unregister: Option<_OnServerCheckTransmit_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnServerStartup_Register(callback: OnServerStartupCallback) {
    unsafe { __s2sdk_OnServerStartup_Register.expect("OnServerStartup_Register function was not found")(callback) }
}
pub type _OnServerStartup_Register = unsafe extern "C" fn(OnServerStartupCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnServerStartup_Register: Option<_OnServerStartup_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnServerStartup_Unregister(callback: OnServerStartupCallback) {
    unsafe { __s2sdk_OnServerStartup_Unregister.expect("OnServerStartup_Unregister function was not found")(callback) }
}
pub type _OnServerStartup_Unregister = unsafe extern "C" fn(OnServerStartupCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnServerStartup_Unregister: Option<_OnServerStartup_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnBuildGameSessionManifest_Register(callback: OnBuildGameSessionManifestCallback) {
    unsafe { __s2sdk_OnBuildGameSessionManifest_Register.expect("OnBuildGameSessionManifest_Register function was not found")(callback) }
}
pub type _OnBuildGameSessionManifest_Register = unsafe extern "C" fn(OnBuildGameSessionManifestCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnBuildGameSessionManifest_Register: Option<_OnBuildGameSessionManifest_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnBuildGameSessionManifest_Unregister(callback: OnBuildGameSessionManifestCallback) {
    unsafe { __s2sdk_OnBuildGameSessionManifest_Unregister.expect("OnBuildGameSessionManifest_Unregister function was not found")(callback) }
}
pub type _OnBuildGameSessionManifest_Unregister = unsafe extern "C" fn(OnBuildGameSessionManifestCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnBuildGameSessionManifest_Unregister: Option<_OnBuildGameSessionManifest_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnServerActivate_Register(callback: OnServerActivateCallback) {
    unsafe { __s2sdk_OnServerActivate_Register.expect("OnServerActivate_Register function was not found")(callback) }
}
pub type _OnServerActivate_Register = unsafe extern "C" fn(OnServerActivateCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnServerActivate_Register: Option<_OnServerActivate_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnServerActivate_Unregister(callback: OnServerActivateCallback) {
    unsafe { __s2sdk_OnServerActivate_Unregister.expect("OnServerActivate_Unregister function was not found")(callback) }
}
pub type _OnServerActivate_Unregister = unsafe extern "C" fn(OnServerActivateCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnServerActivate_Unregister: Option<_OnServerActivate_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnServerSpawn_Register(callback: OnServerSpawnCallback) {
    unsafe { __s2sdk_OnServerSpawn_Register.expect("OnServerSpawn_Register function was not found")(callback) }
}
pub type _OnServerSpawn_Register = unsafe extern "C" fn(OnServerSpawnCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnServerSpawn_Register: Option<_OnServerSpawn_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnServerSpawn_Unregister(callback: OnServerSpawnCallback) {
    unsafe { __s2sdk_OnServerSpawn_Unregister.expect("OnServerSpawn_Unregister function was not found")(callback) }
}
pub type _OnServerSpawn_Unregister = unsafe extern "C" fn(OnServerSpawnCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnServerSpawn_Unregister: Option<_OnServerSpawn_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnServerStarted_Register(callback: OnServerStartedCallback) {
    unsafe { __s2sdk_OnServerStarted_Register.expect("OnServerStarted_Register function was not found")(callback) }
}
pub type _OnServerStarted_Register = unsafe extern "C" fn(OnServerStartedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnServerStarted_Register: Option<_OnServerStarted_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnServerStarted_Unregister(callback: OnServerStartedCallback) {
    unsafe { __s2sdk_OnServerStarted_Unregister.expect("OnServerStarted_Unregister function was not found")(callback) }
}
pub type _OnServerStarted_Unregister = unsafe extern "C" fn(OnServerStartedCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnServerStarted_Unregister: Option<_OnServerStarted_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnMapStart_Register(callback: OnMapStartCallback) {
    unsafe { __s2sdk_OnMapStart_Register.expect("OnMapStart_Register function was not found")(callback) }
}
pub type _OnMapStart_Register = unsafe extern "C" fn(OnMapStartCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnMapStart_Register: Option<_OnMapStart_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnMapStart_Unregister(callback: OnMapStartCallback) {
    unsafe { __s2sdk_OnMapStart_Unregister.expect("OnMapStart_Unregister function was not found")(callback) }
}
pub type _OnMapStart_Unregister = unsafe extern "C" fn(OnMapStartCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnMapStart_Unregister: Option<_OnMapStart_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnMapEnd_Register(callback: OnMapEndCallback) {
    unsafe { __s2sdk_OnMapEnd_Register.expect("OnMapEnd_Register function was not found")(callback) }
}
pub type _OnMapEnd_Register = unsafe extern "C" fn(OnMapEndCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnMapEnd_Register: Option<_OnMapEnd_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnMapEnd_Unregister(callback: OnMapEndCallback) {
    unsafe { __s2sdk_OnMapEnd_Unregister.expect("OnMapEnd_Unregister function was not found")(callback) }
}
pub type _OnMapEnd_Unregister = unsafe extern "C" fn(OnMapEndCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnMapEnd_Unregister: Option<_OnMapEnd_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnGameFrame_Register(callback: OnGameFrameCallback) {
    unsafe { __s2sdk_OnGameFrame_Register.expect("OnGameFrame_Register function was not found")(callback) }
}
pub type _OnGameFrame_Register = unsafe extern "C" fn(OnGameFrameCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnGameFrame_Register: Option<_OnGameFrame_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnGameFrame_Unregister(callback: OnGameFrameCallback) {
    unsafe { __s2sdk_OnGameFrame_Unregister.expect("OnGameFrame_Unregister function was not found")(callback) }
}
pub type _OnGameFrame_Unregister = unsafe extern "C" fn(OnGameFrameCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnGameFrame_Unregister: Option<_OnGameFrame_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnUpdateWhenNotInGame_Register(callback: OnUpdateWhenNotInGameCallback) {
    unsafe { __s2sdk_OnUpdateWhenNotInGame_Register.expect("OnUpdateWhenNotInGame_Register function was not found")(callback) }
}
pub type _OnUpdateWhenNotInGame_Register = unsafe extern "C" fn(OnUpdateWhenNotInGameCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnUpdateWhenNotInGame_Register: Option<_OnUpdateWhenNotInGame_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnUpdateWhenNotInGame_Unregister(callback: OnUpdateWhenNotInGameCallback) {
    unsafe { __s2sdk_OnUpdateWhenNotInGame_Unregister.expect("OnUpdateWhenNotInGame_Unregister function was not found")(callback) }
}
pub type _OnUpdateWhenNotInGame_Unregister = unsafe extern "C" fn(OnUpdateWhenNotInGameCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnUpdateWhenNotInGame_Unregister: Option<_OnUpdateWhenNotInGame_Unregister> = None;

/// Register callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnPreWorldUpdate_Register(callback: OnPreWorldUpdateCallback) {
    unsafe { __s2sdk_OnPreWorldUpdate_Register.expect("OnPreWorldUpdate_Register function was not found")(callback) }
}
pub type _OnPreWorldUpdate_Register = unsafe extern "C" fn(OnPreWorldUpdateCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnPreWorldUpdate_Register: Option<_OnPreWorldUpdate_Register> = None;

/// Unregister callback to event.
///
/// # Arguments
/// * `callback` - (function): Function callback.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn OnPreWorldUpdate_Unregister(callback: OnPreWorldUpdateCallback) {
    unsafe { __s2sdk_OnPreWorldUpdate_Unregister.expect("OnPreWorldUpdate_Unregister function was not found")(callback) }
}
pub type _OnPreWorldUpdate_Unregister = unsafe extern "C" fn(OnPreWorldUpdateCallback);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_OnPreWorldUpdate_Unregister: Option<_OnPreWorldUpdate_Unregister> = None;

