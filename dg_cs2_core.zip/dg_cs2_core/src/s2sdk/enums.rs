// Generated from s2sdk.pplugin

#[allow(unused_imports)]
use plugify::{vector_enum_traits};

/// Enum representing various movement types for entities.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MoveType {
    /// Never moves.
    None = 0,
    /// Previously isometric movement type.
    Isometric = 1,
    /// Player only - moving on the ground.
    Walk = 2,
    /// No gravity, but still collides with stuff.
    Fly = 3,
    /// Flies through the air and is affected by gravity.
    Flygravity = 4,
    /// Uses VPHYSICS for simulation.
    Vphysics = 5,
    /// No clip to world, push and crush.
    Push = 6,
    /// No gravity, no collisions, still has velocity/avelocity.
    Noclip = 7,
    /// Used by players only when going onto a ladder.
    Ladder = 8,
    /// Observer movement, depends on player's observer mode.
    Observer = 9,
    /// Allows the entity to describe its own physics.
    Custom = 10,
}
vector_enum_traits!(MoveType, i32);

/// Enum representing rendering modes for materials.
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RenderMode {
    /// Standard rendering mode (src).
    Normal = 0,
    /// Composite: c*a + dest*(1-a).
    TransColor = 1,
    /// Composite: src*a + dest*(1-a).
    TransTexture = 2,
    /// Composite: src*a + dest -- No Z buffer checks -- Fixed size in screen space.
    Glow = 3,
    /// Composite: src*srca + dest*(1-srca).
    TransAlpha = 4,
    /// Composite: src*a + dest.
    TransAdd = 5,
    /// Not drawn, used for environmental effects.
    Environmental = 6,
    /// Uses a fractional frame value to blend between animation frames.
    TransAddFrameBlend = 7,
    /// Composite: src + dest*(1-a).
    TransAlphaAdd = 8,
    /// Same as Glow but not fixed size in screen space.
    WorldGlow = 9,
    /// No rendering.
    None = 10,
    /// Developer visualizer rendering mode.
    DevVisualizer = 11,
}
vector_enum_traits!(RenderMode, u8);

/// Enum representing the possible teams in Counter-Strike.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CSTeam {
    /// No team.
    None = 0,
    /// Spectator team.
    Spectator = 1,
    /// Terrorist team.
    T = 2,
    /// Counter-Terrorist team.
    CT = 3,
}
vector_enum_traits!(CSTeam, i32);

/// Represents the possible types of data that can be passed as a value in input actions.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FieldType {
    /// Automatically detect the type of the value.
    Auto = 0,
    /// A 32-bit floating-point number.
    Float32 = 1,
    /// A 64-bit floating-point number.
    Float64 = 2,
    /// A 32-bit signed integer.
    Int32 = 3,
    /// A 32-bit unsigned integer.
    UInt32 = 4,
    /// A 64-bit signed integer.
    Int64 = 5,
    /// A 64-bit unsigned integer.
    UInt64 = 6,
    /// A boolean value (true or false).
    Boolean = 7,
    /// A single character.
    Character = 8,
    /// A managed string object.
    String = 9,
    /// A null-terminated C-style string.
    CString = 10,
    /// A script handle, typically for scripting integration.
    HScript = 11,
    /// An entity handle, used to reference an entity within the system.
    EHandle = 12,
    /// A resource handle, such as a file or asset reference.
    Resource = 13,
    /// A 3D vector, typically representing position or direction.
    Vector3d = 14,
    /// A 2D vector, for planar data or coordinates.
    Vector2d = 15,
    /// A 4D vector, often used for advanced mathematical representations.
    Vector4d = 16,
    /// A 32-bit color value (RGBA).
    Color32 = 17,
    /// A quaternion-based angle representation.
    QAngle = 18,
    /// A quaternion, used for rotation and orientation calculations.
    Quaternion = 19,
}
vector_enum_traits!(FieldType, i32);

/// Enum representing various damage types.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DamageTypes {
    /// Generic damage.
    DMG_GENERIC = 0,
    /// Crush damage.
    DMG_CRUSH = 1,
    /// Bullet damage.
    DMG_BULLET = 2,
    /// Slash damage.
    DMG_SLASH = 4,
    /// Burn damage.
    DMG_BURN = 8,
    /// Vehicle damage.
    DMG_VEHICLE = 16,
    /// Fall damage.
    DMG_FALL = 32,
    /// Blast damage.
    DMG_BLAST = 64,
    /// Club damage.
    DMG_CLUB = 128,
    /// Shock damage.
    DMG_SHOCK = 256,
    /// Sonic damage.
    DMG_SONIC = 512,
    /// Energy beam damage.
    DMG_ENERGYBEAM = 1024,
    /// Drowning damage.
    DMG_DROWN = 16384,
    /// Poison damage.
    DMG_POISON = 32768,
    /// Radiation damage.
    DMG_RADIATION = 65536,
    /// Recovering from drowning damage.
    DMG_DROWNRECOVER = 131072,
    /// Acid damage.
    DMG_ACID = 262144,
    /// Physgun damage.
    DMG_PHYSGUN = 1048576,
    /// Dissolve damage.
    DMG_DISSOLVE = 2097152,
    /// Surface blast damage.
    DMG_BLAST_SURFACE = 4194304,
    /// Buckshot damage.
    DMG_BUCKSHOT = 16777216,
    /// Last generic flag damage.
    // DMG_LASTGENERICFLAG = 16777216,
    /// Headshot damage.
    DMG_HEADSHOT = 33554432,
    /// Danger zone damage.
    DMG_DANGERZONE = 67108864,
}
vector_enum_traits!(DamageTypes, i32);

/// Enum representing reasons for network disconnection.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NetworkDisconnectionReason {
    /// Invalid.
    Invalid = 0,
    /// Shutdown.
    Shutdown = 1,
    /// Disconnect by user.
    DisconnectByUser = 2,
    /// Disconnect by server.
    DisconnectByServer = 3,
    /// Lost.
    Lost = 4,
    /// Overflow.
    Overflow = 5,
    /// Steam banned.
    SteamBanned = 6,
    /// Steam inuse.
    SteamInuse = 7,
    /// Steam ticket.
    SteamTicket = 8,
    /// Steam logon.
    SteamLogon = 9,
    /// Steam authcancelled.
    SteamAuthcancelled = 10,
    /// Steam authalreadyused.
    SteamAuthalreadyused = 11,
    /// Steam authinvalid.
    SteamAuthinvalid = 12,
    /// Steam vacbanstate.
    SteamVacbanstate = 13,
    /// Steam logged in elsewhere.
    SteamLoggedInElsewhere = 14,
    /// Steam vac check timedout.
    SteamVacCheckTimedout = 15,
    /// Steam dropped.
    SteamDropped = 16,
    /// Steam ownership.
    SteamOwnership = 17,
    /// Serverinfo overflow.
    ServerinfoOverflow = 18,
    /// Tickmsg overflow.
    TickmsgOverflow = 19,
    /// Stringtablemsg overflow.
    StringtablemsgOverflow = 20,
    /// Deltaentmsg overflow.
    DeltaentmsgOverflow = 21,
    /// Tempentmsg overflow.
    TempentmsgOverflow = 22,
    /// Soundsmsg overflow.
    SoundsmsgOverflow = 23,
    /// Snapshotoverflow.
    Snapshotoverflow = 24,
    /// Snapshoterror.
    Snapshoterror = 25,
    /// Reliableoverflow.
    Reliableoverflow = 26,
    /// Baddeltatick.
    Baddeltatick = 27,
    /// Nomoresplits.
    Nomoresplits = 28,
    /// Timedout.
    Timedout = 29,
    /// Disconnected.
    Disconnected = 30,
    /// Leavingsplit.
    Leavingsplit = 31,
    /// Differentclasstables.
    Differentclasstables = 32,
    /// Badrelaypassword.
    Badrelaypassword = 33,
    /// Badspectatorpassword.
    Badspectatorpassword = 34,
    /// Hltvrestricted.
    Hltvrestricted = 35,
    /// Nospectators.
    Nospectators = 36,
    /// Hltvunavailable.
    Hltvunavailable = 37,
    /// Hltvstop.
    Hltvstop = 38,
    /// Kicked.
    Kicked = 39,
    /// Banadded.
    Banadded = 40,
    /// Kickbanadded.
    Kickbanadded = 41,
    /// Hltvdirect.
    Hltvdirect = 42,
    /// Pureserver clientextra.
    PureserverClientextra = 43,
    /// Pureserver mismatch.
    PureserverMismatch = 44,
    /// Usercmd.
    Usercmd = 45,
    /// Rejected by game.
    RejectedByGame = 46,
    /// Message parse error.
    MessageParseError = 47,
    /// Invalid message error.
    InvalidMessageError = 48,
    /// Bad server password.
    BadServerPassword = 49,
    /// Direct connect reservation.
    DirectConnectReservation = 50,
    /// Connection failure.
    ConnectionFailure = 51,
    /// No peer group handlers.
    NoPeerGroupHandlers = 52,
    /// Reconnection.
    Reconnection = 53,
    /// Loopshutdown.
    Loopshutdown = 54,
    /// Loopdeactivate.
    Loopdeactivate = 55,
    /// Host endgame.
    HostEndgame = 56,
    /// Loop levelload activate.
    LoopLevelloadActivate = 57,
    /// Create server failed.
    CreateServerFailed = 58,
    /// Exiting.
    Exiting = 59,
    /// Request hoststate idle.
    RequestHoststateIdle = 60,
    /// Request hoststate hltvrelay.
    RequestHoststateHltvrelay = 61,
    /// Client consistency fail.
    ClientConsistencyFail = 62,
    /// Client unable to crc map.
    ClientUnableToCrcMap = 63,
    /// Client no map.
    ClientNoMap = 64,
    /// Client different map.
    ClientDifferentMap = 65,
    /// Server requires steam.
    ServerRequiresSteam = 66,
    /// Steam deny misc.
    SteamDenyMisc = 67,
    /// Steam deny bad anti cheat.
    SteamDenyBadAntiCheat = 68,
    /// Server shutdown.
    ServerShutdown = 69,
    /// Replay incompatible.
    ReplayIncompatible = 71,
    /// Connect request timedout.
    ConnectRequestTimedout = 72,
    /// Server incompatible.
    ServerIncompatible = 73,
    /// Localproblem manyrelays.
    LocalproblemManyrelays = 74,
    /// Localproblem hostedserverprimaryrelay.
    LocalproblemHostedserverprimaryrelay = 75,
    /// Localproblem networkconfig.
    LocalproblemNetworkconfig = 76,
    /// Localproblem other.
    LocalproblemOther = 77,
    /// Remote timeout.
    RemoteTimeout = 79,
    /// Remote timeout connecting.
    RemoteTimeoutConnecting = 80,
    /// Remote other.
    RemoteOther = 81,
    /// Remote badcrypt.
    RemoteBadcrypt = 82,
    /// Remote certnottrusted.
    RemoteCertnottrusted = 83,
    /// Unusual.
    Unusual = 84,
    /// Internal error.
    InternalError = 85,
    /// Reject badchallenge.
    RejectBadchallenge = 128,
    /// Reject nolobby.
    RejectNolobby = 129,
    /// Reject background map.
    RejectBackgroundMap = 130,
    /// Reject single player.
    RejectSinglePlayer = 131,
    /// Reject hidden game.
    RejectHiddenGame = 132,
    /// Reject lanrestrict.
    RejectLanrestrict = 133,
    /// Reject badpassword.
    RejectBadpassword = 134,
    /// Reject serverfull.
    RejectServerfull = 135,
    /// Reject invalidreservation.
    RejectInvalidreservation = 136,
    /// Reject failedchannel.
    RejectFailedchannel = 137,
    /// Reject connect from lobby.
    RejectConnectFromLobby = 138,
    /// Reject reserved for lobby.
    RejectReservedForLobby = 139,
    /// Reject invalidkeylength.
    RejectInvalidkeylength = 140,
    /// Reject oldprotocol.
    RejectOldprotocol = 141,
    /// Reject newprotocol.
    RejectNewprotocol = 142,
    /// Reject invalidconnection.
    RejectInvalidconnection = 143,
    /// Reject invalidcertlen.
    RejectInvalidcertlen = 144,
    /// Reject invalidsteamcertlen.
    RejectInvalidsteamcertlen = 145,
    /// Reject steam.
    RejectSteam = 146,
    /// Reject serverauthdisabled.
    RejectServerauthdisabled = 147,
    /// Reject servercdkeyauthinvalid.
    RejectServercdkeyauthinvalid = 148,
    /// Reject banned.
    RejectBanned = 149,
    /// Kicked teamkilling.
    KickedTeamkilling = 150,
    /// Kicked tk start.
    KickedTkStart = 151,
    /// Kicked untrustedaccount.
    KickedUntrustedaccount = 152,
    /// Kicked convictedaccount.
    KickedConvictedaccount = 153,
    /// Kicked competitivecooldown.
    KickedCompetitivecooldown = 154,
    /// Kicked teamhurting.
    KickedTeamhurting = 155,
    /// Kicked hostagekilling.
    KickedHostagekilling = 156,
    /// Kicked votedoff.
    KickedVotedoff = 157,
    /// Kicked idle.
    KickedIdle = 158,
    /// Kicked suicide.
    KickedSuicide = 159,
    /// Kicked nosteamlogin.
    KickedNosteamlogin = 160,
    /// Kicked nosteamticket.
    KickedNosteamticket = 161,
    /// Kicked inputautomation.
    KickedInputautomation = 162,
    /// Kicked vacnetabnormalbehavior.
    KickedVacnetabnormalbehavior = 163,
    /// Kicked insecureclient.
    KickedInsecureclient = 164,
}
vector_enum_traits!(NetworkDisconnectionReason, i32);

/// Enum representing various flags for ConVars and ConCommands.
#[repr(i64)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConVarFlag {
    /// The default, no flags at all.
    None = 0,
    /// Linked to a ConCommand.
    LinkedConcommand = 1,
    /// Hidden in released products. Automatically removed if ALLOW_DEVELOPMENT_CVARS is defined.
    DevelopmentOnly = 2,
    /// Defined by the game DLL.
    GameDll = 4,
    /// Defined by the client DLL.
    ClientDll = 8,
    /// Hidden. Doesn't appear in find or auto-complete. Like DEVELOPMENTONLY but cannot be compiled out.
    Hidden = 16,
    /// Server cvar; data is not sent since it's sensitive (e.g., passwords).
    Protected = 32,
    /// This cvar cannot be changed by clients connected to a multiplayer server.
    SpOnly = 64,
    /// Saved to vars.rc.
    Archive = 128,
    /// Notifies players when changed.
    Notify = 256,
    /// Changes the client's info string.
    UserInfo = 512,
    /// Hides the cvar from lookups.
    Missing0 = 1024,
    /// If this is a server cvar, changes are not logged to the file or console.
    Unlogged = 2048,
    /// Hides the cvar from lookups.
    Missing1 = 4096,
    /// Server-enforced setting on clients.
    Replicated = 8192,
    /// Only usable in singleplayer/debug or multiplayer with sv_cheats.
    Cheat = 16384,
    /// Causes auto-generated varnameN for splitscreen slots.
    PerUser = 32768,
    /// Records this cvar when starting a demo file.
    Demo = 65536,
    /// Excluded from demo files.
    DontRecord = 131072,
    /// Reserved for future use.
    Missing2 = 262144,
    /// Cvars tagged with this are available to customers.
    Release = 524288,
    /// Marks the cvar as a menu bar item.
    MenuBarItem = 1048576,
    /// Reserved for future use.
    Missing3 = 2097152,
    /// Cannot be changed by a client connected to a server.
    NotConnected = 4194304,
    /// Enables fuzzy matching for vconsole.
    VconsoleFuzzyMatching = 8388608,
    /// The server can execute this command on clients.
    ServerCanExecute = 16777216,
    /// Allows clients to execute this command.
    ClientCanExecute = 33554432,
    /// The server cannot query this cvar's value.
    ServerCannotQuery = 67108864,
    /// Sets focus in the vconsole.
    VconsoleSetFocus = 134217728,
    /// IVEngineClient::ClientCmd can execute this command.
    ClientCmdCanExecute = 268435456,
    /// Executes the cvar every tick.
    ExecutePerTick = 536870912,
}
vector_enum_traits!(ConVarFlag, i64);

/// Enum representing the possible results of an operation.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ResultType {
    /// The action continues to be processed without interruption.
    Continue = 0,
    /// Indicates that the action has altered the state or behavior during execution.
    Changed = 1,
    /// The action has been successfully handled, and no further action is required.
    Handled = 2,
    /// The action processing is halted, and no further steps will be executed.
    Stop = 3,
}
vector_enum_traits!(ResultType, i32);

/// The command execution context.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConCommandContext {
    /// The command execute from the client's console.
    Console = 0,
    /// The command execute from the client's chat.
    Chat = 1,
}
vector_enum_traits!(ConCommandContext, i32);

/// Enum representing the type of callback.
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HookMode {
    /// Callback will be executed before the original function
    Pre = 0,
    /// Callback will be executed after the original function
    Post = 1,
}
vector_enum_traits!(HookMode, u8);

#[repr(i16)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConVarType {
    /// Invalid type
    Invalid = -1,
    /// Boolean type
    Bool = 0,
    /// 16-bit signed integer
    Int16 = 1,
    /// 16-bit unsigned integer
    UInt16 = 2,
    /// 32-bit signed integer
    Int32 = 3,
    /// 32-bit unsigned integer
    UInt32 = 4,
    /// 64-bit signed integer
    Int64 = 5,
    /// 64-bit unsigned integer
    UInt64 = 6,
    /// 32-bit floating point
    Float32 = 7,
    /// 64-bit floating point (double)
    Float64 = 8,
    /// String type
    String = 9,
    /// Color type
    Color = 10,
    /// 2D vector
    Vector2 = 11,
    /// 3D vector
    Vector3 = 12,
    /// 4D vector
    Vector4 = 13,
    /// Quaternion angle
    Qangle = 14,
    /// Maximum value (used for bounds checking)
    Max = 15,
}
vector_enum_traits!(ConVarType, i16);

/// Enum representing various flags for ConVars and ConCommands.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CvarValueStatus {
    /// It got the value fine.
    ValueIntact = 0,
    /// It did not found the value.
    CvarNotFound = 1,
    /// There's a ConCommand, but it's not a ConVar.
    NotACvar = 2,
    /// The cvar was marked with FCVAR_SERVER_CAN_NOT_QUERY, so the server is not allowed to have its value.
    CvarProtected = 3,
}
vector_enum_traits!(CvarValueStatus, i32);

/// Enum representing the type of callback.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EventHookError {
    /// Indicates that the event hook was successfully created.
    Okay = 0,
    /// Indicates that the event name provided is invalid or does not exist.
    InvalidEvent = 1,
    /// Indicates that the event system is not currently active or initialized.
    NotActive = 2,
    /// Indicates that the callback function provided is invalid or not compatible with the event system.
    InvalidCallback = 3,
}
vector_enum_traits!(EventHookError, i32);

/// Enum representing the possible verbosity of a logger.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LoggingVerbosity {
    /// Turns off all spew.
    Off = 0,
    /// Turns on vital logs.
    Essential = 1,
    /// Turns on most messages.
    Default = 2,
    /// Allows for walls of text that are usually useful.
    Detailed = 3,
    /// Allows everything.
    Max = 4,
}
vector_enum_traits!(LoggingVerbosity, i32);

/// Enum representing the possible verbosity of a logger.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LoggingSeverity {
    /// Turns off all spew.
    Off = 0,
    /// A debug message.
    Detailed = 1,
    /// An informative logging message.
    Message = 2,
    /// A warning, typically non-fatal.
    Warning = 3,
    /// A message caused by an Assert**() operation.
    Assert = 4,
    /// An error, typically fatal/unrecoverable.
    Error = 5,
}
vector_enum_traits!(LoggingSeverity, i32);

/// Logging channel behavior flags, set on channel creation.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LoggingChannelFlags {
    /// Indicates that the spew is only relevant to interactive consoles.
    ConsoleOnly = 1,
    /// Indicates that spew should not be echoed to any output devices.
    DoNotEcho = 2,
}
vector_enum_traits!(LoggingChannelFlags, i32);

/// Enum representing the possible reasons a vote creation or processing has failed.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VoteCreateFailed {
    /// Generic vote failure.
    Generic = 0,
    /// Vote failed due to players transitioning.
    TransitioningPlayers = 1,
    /// Vote failed because vote rate limit was exceeded.
    RateExceeded = 2,
    /// Vote failed because Yes votes must exceed No votes.
    YesMustExceedNo = 3,
    /// Vote failed due to quorum not being met.
    QuorumFailure = 4,
    /// Vote failed because the issue is disabled.
    IssueDisabled = 5,
    /// Vote failed because the map was not found.
    MapNotFound = 6,
    /// Vote failed because map name is required.
    MapNameRequired = 7,
    /// Vote failed because a similar vote failed recently.
    FailedRecently = 8,
    /// Vote to kick failed recently.
    FailedRecentKick = 9,
    /// Vote to change map failed recently.
    FailedRecentChangeMap = 10,
    /// Vote to swap teams failed recently.
    FailedRecentSwapTeams = 11,
    /// Vote to scramble teams failed recently.
    FailedRecentScrambleTeams = 12,
    /// Vote to restart failed recently.
    FailedRecentRestart = 13,
    /// Team is not allowed to call vote.
    TeamCantCall = 14,
    /// Vote failed because game is waiting for players.
    WaitingForPlayers = 15,
    /// Target player was not found.
    PlayerNotFound = 16,
    /// Cannot kick an admin.
    CannotKickAdmin = 17,
    /// Scramble is currently in progress.
    ScrambleInProgress = 18,
    /// Swap is currently in progress.
    SwapInProgress = 19,
    /// Spectators are not allowed to vote.
    Spectator = 20,
    /// Voting is disabled.
    Disabled = 21,
    /// Next level is already set.
    NextLevelSet = 22,
    /// Rematch vote failed.
    Rematch = 23,
    /// Vote to surrender failed due to being too early.
    TooEarlySurrender = 24,
    /// Vote to continue failed.
    Continue = 25,
    /// Vote failed because match is already paused.
    MatchPaused = 26,
    /// Vote failed because match is not paused.
    MatchNotPaused = 27,
    /// Vote failed because game is not in warmup.
    NotInWarmup = 28,
    /// Vote failed because there are not 10 players.
    Not10Players = 29,
    /// Vote failed due to an active timeout.
    TimeoutActive = 30,
    /// Vote failed because timeout is inactive.
    TimeoutInactive = 31,
    /// Vote failed because timeout has been exhausted.
    TimeoutExhausted = 32,
    /// Vote failed because the round can't end now.
    CantRoundEnd = 33,
    /// Sentinel value. Not a real failure reason.
    Max = 34,
}
vector_enum_traits!(VoteCreateFailed, i32);

/// Enum representing the possible types of a vote actions.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VoteAction {
    /// Triggered when the vote begins. No additional parameters are used.
    Start = 0,
    /// Triggered when a player casts a vote. 'clientSlot' holds the voter's slot and 'choice' is the selected option (e.g., VOTE_OPTION1 for yes, VOTE_OPTION2 for no).
    Vote = 1,
    /// Triggered when the vote concludes. 'clientSlot' is typically -1. 'choice' contains the reason the vote ended (from YesNoVoteEndReason).
    End = 2,
}
vector_enum_traits!(VoteAction, i32);

/// Enum representing the possible types of a vote.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VoteEndReason {
    /// All possible votes were cast.
    AllVotes = 0,
    /// Time ran out.
    TimeUp = 1,
    /// The vote got cancelled.
    Cancelled = 2,
}
vector_enum_traits!(VoteEndReason, i32);

/// Enum representing the possible flags of a timer.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TimerFlag {
    /// Timer with no unique properties.
    Default = 0,
    /// Timer will repeat until stopped.
    Repeat = 1,
    /// Timer will not carry over mapchanges.
    NoMapChange = 2,
}
vector_enum_traits!(TimerFlag, i32);

/// Enum representing the possible reasons for a round ending in Counter-Strike.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CSRoundEndReason {
    /// Target successfully bombed.
    TargetBombed = 1,
    /// The VIP has escaped (not present in CS:GO).
    VIPEscaped = 2,
    /// VIP has been assassinated (not present in CS:GO).
    VIPKilled = 3,
    /// The terrorists have escaped.
    TerroristsEscaped = 4,
    /// The CTs have prevented most of the terrorists from escaping.
    CTStoppedEscape = 5,
    /// Escaping terrorists have all been neutralized.
    TerroristsStopped = 6,
    /// The bomb has been defused.
    BombDefused = 7,
    /// Counter-Terrorists win.
    CTWin = 8,
    /// Terrorists win.
    TerroristWin = 9,
    /// Round draw.
    Draw = 10,
    /// All hostages have been rescued.
    HostagesRescued = 11,
    /// Target has been saved.
    TargetSaved = 12,
    /// Hostages have not been rescued.
    HostagesNotRescued = 13,
    /// Terrorists have not escaped.
    TerroristsNotEscaped = 14,
    /// VIP has not escaped (not present in CS:GO).
    VIPNotEscaped = 15,
    /// Game commencing.
    GameStart = 16,
    /// Terrorists surrender.
    TerroristsSurrender = 17,
    /// CTs surrender.
    CTSurrender = 18,
    /// Terrorists planted the bomb.
    TerroristsPlanted = 19,
    /// CTs reached the hostage.
    CTsReachedHostage = 20,
    /// Survival mode win.
    SurvivalWin = 21,
    /// Survival mode draw.
    SurvivalDraw = 22,
}
vector_enum_traits!(CSRoundEndReason, i32);

/// Enum representing different weapon types.
#[repr(u32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CSWeaponType {
    Knife = 0,
    Pistol = 1,
    SubmachineGun = 2,
    Rifle = 3,
    Shotgun = 4,
    SniperRifle = 5,
    MachineGun = 6,
    C4 = 7,
    Taser = 8,
    Grenade = 9,
    Equipment = 10,
    StackableItem = 11,
    Unknown = 12,
}
vector_enum_traits!(CSWeaponType, u32);

/// Enum representing different weapon categories.
#[repr(u32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CSWeaponCategory {
    Other = 0,
    Melee = 1,
    Secondary = 2,
    SMG = 3,
    Rifle = 4,
    Heavy = 5,
    Count = 6,
}
vector_enum_traits!(CSWeaponCategory, u32);

/// Enum representing different gear slots.
#[repr(u32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GearSlot {
    Invalid = 4294967295,
    Rifle = 0,
    Pistol = 1,
    Knife = 2,
    Grenades = 3,
    C4 = 4,
    ReservedSlot6 = 5,
    ReservedSlot7 = 6,
    ReservedSlot8 = 7,
    ReservedSlot9 = 8,
    ReservedSlot10 = 9,
    ReservedSlot11 = 10,
    Boosts = 11,
    Utility = 12,
    Count = 13,
    // First = 0,
    // Last = 12,
}
vector_enum_traits!(GearSlot, u32);

/// Enum representing different weapon definition indices.
#[repr(u16)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WeaponDefIndex {
    Invalid = 0,
    Deagle = 1,
    Elite = 2,
    FiveSeven = 3,
    Glock = 4,
    AK47 = 7,
    AUG = 8,
    AWP = 9,
    FAMAS = 10,
    G3SG1 = 11,
    GalilAR = 13,
    M249 = 14,
    M4A1 = 16,
    MAC10 = 17,
    P90 = 19,
    MP5SD = 23,
    UMP45 = 24,
    XM1014 = 25,
    Bizon = 26,
    MAG7 = 27,
    Negev = 28,
    SawedOff = 29,
    Tec9 = 30,
    Taser = 31,
    HKP2000 = 32,
    MP7 = 33,
    MP9 = 34,
    Nova = 35,
    P250 = 36,
    SCAR20 = 38,
    SG556 = 39,
    SSG08 = 40,
    KnifeGG = 41,
    Knife = 42,
    Flashbang = 43,
    HEGrenade = 44,
    SmokeGrenade = 45,
    Molotov = 46,
    Decoy = 47,
    IncGrenade = 48,
    C4 = 49,
    Kevlar = 50,
    AssaultSuit = 51,
    HeavyAssaultSuit = 52,
    Defuser = 55,
    KnifeT = 59,
    M4A1Silencer = 60,
    USPSilencer = 61,
    CZ75A = 63,
    Revolver = 64,
    Bayonet = 500,
    KnifeCSS = 503,
    KnifeFlip = 505,
    KnifeGut = 506,
    KnifeKarambit = 507,
    KnifeM9Bayonet = 508,
    KnifeTactical = 509,
    KnifeFalchion = 512,
    KnifeBowie = 514,
    KnifeButterfly = 515,
    KnifePush = 516,
    KnifeCord = 517,
    KnifeCanis = 518,
    KnifeUrsus = 519,
    KnifeGypsyJackknife = 520,
    KnifeOutdoor = 521,
    KnifeStiletto = 522,
    KnifeWidowmaker = 523,
    KnifeSkeleton = 525,
    KnifeKukri = 526,
}
vector_enum_traits!(WeaponDefIndex, u16);


/// Ownership type for RAII wrappers
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Ownership {
    Borrowed,
    Owned,
}
