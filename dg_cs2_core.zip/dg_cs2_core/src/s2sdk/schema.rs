// Generated from s2sdk.pplugin (group: schema)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Get the offset of a member in a given schema class.
///
/// # Arguments
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the member whose offset is to be retrieved.
///
/// # Returns - (int32):
/// The offset of the member in the class, or -1 if the offset is not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetSchemaOffset(className: &Str, memberName: &Str) -> i32 {
    unsafe { __s2sdk_GetSchemaOffset.expect("GetSchemaOffset function was not found")(className, memberName) }
}
pub type _GetSchemaOffset = unsafe extern "C" fn(&Str, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetSchemaOffset: Option<_GetSchemaOffset> = None;

/// Get the offset of a chain in a given schema class.
///
/// # Arguments
/// * `className` - (string): The name of the class.
///
/// # Returns - (int32):
/// The offset of the chain entity in the class, or -1 if the offset is not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetSchemaChainOffset(className: &Str) -> i32 {
    unsafe { __s2sdk_GetSchemaChainOffset.expect("GetSchemaChainOffset function was not found")(className) }
}
pub type _GetSchemaChainOffset = unsafe extern "C" fn(&Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetSchemaChainOffset: Option<_GetSchemaChainOffset> = None;

/// Check if a schema field is networked.
///
/// # Arguments
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the member to check.
///
/// # Returns - (bool):
/// True if the member is networked, false otherwise.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn IsSchemaFieldNetworked(className: &Str, memberName: &Str) -> bool {
    unsafe { __s2sdk_IsSchemaFieldNetworked.expect("IsSchemaFieldNetworked function was not found")(className, memberName) }
}
pub type _IsSchemaFieldNetworked = unsafe extern "C" fn(&Str, &Str) -> bool;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_IsSchemaFieldNetworked: Option<_IsSchemaFieldNetworked> = None;

/// Get the size of a schema class.
///
/// # Arguments
/// * `className` - (string): The name of the class.
///
/// # Returns - (int32):
/// The size of the class in bytes, or -1 if the class is not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetSchemaClassSize(className: &Str) -> i32 {
    unsafe { __s2sdk_GetSchemaClassSize.expect("GetSchemaClassSize function was not found")(className) }
}
pub type _GetSchemaClassSize = unsafe extern "C" fn(&Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetSchemaClassSize: Option<_GetSchemaClassSize> = None;

/// Peeks into an entity's object schema and retrieves the integer value at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `size` - (int32): Number of bytes to read (valid values are 1, 2, 4 or 8).
///
/// # Returns - (int64):
/// The integer value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntData2(entity: usize, offset: i32, size: i32) -> i64 {
    unsafe { __s2sdk_GetEntData2.expect("GetEntData2 function was not found")(entity, offset, size) }
}
pub type _GetEntData2 = unsafe extern "C" fn(usize, i32, i32) -> i64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntData2: Option<_GetEntData2> = None;

/// Peeks into an entity's object data and sets the integer value at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (int64): The integer value to set.
/// * `size` - (int32): Number of bytes to write (valid values are 1, 2, 4 or 8).
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntData2(entity: usize, offset: i32, value: i64, size: i32, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntData2.expect("SetEntData2 function was not found")(entity, offset, value, size, changeState, chainOffset) }
}
pub type _SetEntData2 = unsafe extern "C" fn(usize, i32, i64, i32, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntData2: Option<_SetEntData2> = None;

/// Peeks into an entity's object schema and retrieves the float value at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `size` - (int32): Number of bytes to read (valid values are 1, 2, 4 or 8).
///
/// # Returns - (double):
/// The float value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataFloat2(entity: usize, offset: i32, size: i32) -> f64 {
    unsafe { __s2sdk_GetEntDataFloat2.expect("GetEntDataFloat2 function was not found")(entity, offset, size) }
}
pub type _GetEntDataFloat2 = unsafe extern "C" fn(usize, i32, i32) -> f64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataFloat2: Option<_GetEntDataFloat2> = None;

/// Peeks into an entity's object data and sets the float value at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (double): The float value to set.
/// * `size` - (int32): Number of bytes to write (valid values are 1, 2, 4 or 8).
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataFloat2(entity: usize, offset: i32, value: f64, size: i32, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataFloat2.expect("SetEntDataFloat2 function was not found")(entity, offset, value, size, changeState, chainOffset) }
}
pub type _SetEntDataFloat2 = unsafe extern "C" fn(usize, i32, f64, i32, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataFloat2: Option<_SetEntDataFloat2> = None;

/// Peeks into an entity's object schema and retrieves the color value at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (vec4):
/// The color value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataColor2(entity: usize, offset: i32) -> Vec4 {
    unsafe { __s2sdk_GetEntDataColor2.expect("GetEntDataColor2 function was not found")(entity, offset) }
}
pub type _GetEntDataColor2 = unsafe extern "C" fn(usize, i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataColor2: Option<_GetEntDataColor2> = None;

/// Peeks into an entity's object data and sets the color at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (vec4): The color value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataColor2(entity: usize, offset: i32, value: &Vec4, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataColor2.expect("SetEntDataColor2 function was not found")(entity, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataColor2 = unsafe extern "C" fn(usize, i32, &Vec4, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataColor2: Option<_SetEntDataColor2> = None;

/// Peeks into an entity's object schema and retrieves the string value at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (string):
/// The string value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataString2(entity: usize, offset: i32) -> Str {
    unsafe { __s2sdk_GetEntDataString2.expect("GetEntDataString2 function was not found")(entity, offset) }
}
pub type _GetEntDataString2 = unsafe extern "C" fn(usize, i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataString2: Option<_GetEntDataString2> = None;

/// Peeks into an entity's object data and sets the string at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (string): The string value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataString2(entity: usize, offset: i32, value: &Str, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataString2.expect("SetEntDataString2 function was not found")(entity, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataString2 = unsafe extern "C" fn(usize, i32, &Str, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataString2: Option<_SetEntDataString2> = None;

/// Peeks into an entity's object schema and retrieves the string value at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `size` - (int32): Number of bytes to read.
///
/// # Returns - (string):
/// The string value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataCString2(entity: usize, offset: i32, size: i32) -> Str {
    unsafe { __s2sdk_GetEntDataCString2.expect("GetEntDataCString2 function was not found")(entity, offset, size) }
}
pub type _GetEntDataCString2 = unsafe extern "C" fn(usize, i32, i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataCString2: Option<_GetEntDataCString2> = None;

/// Peeks into an entity's object data and sets the string at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (string): The string value to set.
/// * `size` - (int32): Number of bytes to write.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataCString2(entity: usize, offset: i32, value: &Str, size: i32, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataCString2.expect("SetEntDataCString2 function was not found")(entity, offset, value, size, changeState, chainOffset) }
}
pub type _SetEntDataCString2 = unsafe extern "C" fn(usize, i32, &Str, i32, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataCString2: Option<_SetEntDataCString2> = None;

/// Peeks into an entity's object schema and retrieves the vector value at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (vec3):
/// The vector value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataVector3D2(entity: usize, offset: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntDataVector3D2.expect("GetEntDataVector3D2 function was not found")(entity, offset) }
}
pub type _GetEntDataVector3D2 = unsafe extern "C" fn(usize, i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataVector3D2: Option<_GetEntDataVector3D2> = None;

/// Peeks into an entity's object data and sets the vector at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (vec3): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataVector3D2(entity: usize, offset: i32, value: &Vec3, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataVector3D2.expect("SetEntDataVector3D2 function was not found")(entity, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataVector3D2 = unsafe extern "C" fn(usize, i32, &Vec3, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataVector3D2: Option<_SetEntDataVector3D2> = None;

/// Peeks into an entity's object schema and retrieves the vector value at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (vec4):
/// The vector value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataVector4D2(entity: usize, offset: i32) -> Vec4 {
    unsafe { __s2sdk_GetEntDataVector4D2.expect("GetEntDataVector4D2 function was not found")(entity, offset) }
}
pub type _GetEntDataVector4D2 = unsafe extern "C" fn(usize, i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataVector4D2: Option<_GetEntDataVector4D2> = None;

/// Peeks into an entity's object data and sets the vector at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (vec4): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataVector4D2(entity: usize, offset: i32, value: &Vec4, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataVector4D2.expect("SetEntDataVector4D2 function was not found")(entity, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataVector4D2 = unsafe extern "C" fn(usize, i32, &Vec4, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataVector4D2: Option<_SetEntDataVector4D2> = None;

/// Peeks into an entity's object schema and retrieves the vector value at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (vec2):
/// The vector value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataVector2D2(entity: usize, offset: i32) -> Vec2 {
    unsafe { __s2sdk_GetEntDataVector2D2.expect("GetEntDataVector2D2 function was not found")(entity, offset) }
}
pub type _GetEntDataVector2D2 = unsafe extern "C" fn(usize, i32) -> Vec2;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataVector2D2: Option<_GetEntDataVector2D2> = None;

/// Peeks into an entity's object data and sets the vector at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (vec2): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataVector2D2(entity: usize, offset: i32, value: &Vec2, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataVector2D2.expect("SetEntDataVector2D2 function was not found")(entity, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataVector2D2 = unsafe extern "C" fn(usize, i32, &Vec2, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataVector2D2: Option<_SetEntDataVector2D2> = None;

/// Peeks into an entity's object data and retrieves the entity handle at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (int32):
/// The entity handle at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataEnt2(entity: usize, offset: i32) -> i32 {
    unsafe { __s2sdk_GetEntDataEnt2.expect("GetEntDataEnt2 function was not found")(entity, offset) }
}
pub type _GetEntDataEnt2 = unsafe extern "C" fn(usize, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataEnt2: Option<_GetEntDataEnt2> = None;

/// Peeks into an entity's object data and sets the entity handle at the given offset.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (int32): The entity handle to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataEnt2(entity: usize, offset: i32, value: i32, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataEnt2.expect("SetEntDataEnt2 function was not found")(entity, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataEnt2 = unsafe extern "C" fn(usize, i32, i32, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataEnt2: Option<_SetEntDataEnt2> = None;

/// Updates the networked state of a schema field for a given entity pointer.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `offset` - (int32): The offset of the schema to use.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ChangeEntityState2(entity: usize, offset: i32, chainOffset: i32) {
    unsafe { __s2sdk_ChangeEntityState2.expect("ChangeEntityState2 function was not found")(entity, offset, chainOffset) }
}
pub type _ChangeEntityState2 = unsafe extern "C" fn(usize, i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ChangeEntityState2: Option<_ChangeEntityState2> = None;

/// Peeks into an entity's object schema and retrieves the integer value at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `size` - (int32): Number of bytes to read (valid values are 1, 2, 4 or 8).
///
/// # Returns - (int64):
/// The integer value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntData(entityHandle: i32, offset: i32, size: i32) -> i64 {
    unsafe { __s2sdk_GetEntData.expect("GetEntData function was not found")(entityHandle, offset, size) }
}
pub type _GetEntData = unsafe extern "C" fn(i32, i32, i32) -> i64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntData: Option<_GetEntData> = None;

/// Peeks into an entity's object data and sets the integer value at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (int64): The integer value to set.
/// * `size` - (int32): Number of bytes to write (valid values are 1, 2, 4 or 8).
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntData(entityHandle: i32, offset: i32, value: i64, size: i32, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntData.expect("SetEntData function was not found")(entityHandle, offset, value, size, changeState, chainOffset) }
}
pub type _SetEntData = unsafe extern "C" fn(i32, i32, i64, i32, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntData: Option<_SetEntData> = None;

/// Peeks into an entity's object schema and retrieves the float value at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `size` - (int32): Number of bytes to read (valid values are 1, 2, 4 or 8).
///
/// # Returns - (double):
/// The float value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataFloat(entityHandle: i32, offset: i32, size: i32) -> f64 {
    unsafe { __s2sdk_GetEntDataFloat.expect("GetEntDataFloat function was not found")(entityHandle, offset, size) }
}
pub type _GetEntDataFloat = unsafe extern "C" fn(i32, i32, i32) -> f64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataFloat: Option<_GetEntDataFloat> = None;

/// Peeks into an entity's object data and sets the float value at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (double): The float value to set.
/// * `size` - (int32): Number of bytes to write (valid values are 1, 2, 4 or 8).
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataFloat(entityHandle: i32, offset: i32, value: f64, size: i32, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataFloat.expect("SetEntDataFloat function was not found")(entityHandle, offset, value, size, changeState, chainOffset) }
}
pub type _SetEntDataFloat = unsafe extern "C" fn(i32, i32, f64, i32, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataFloat: Option<_SetEntDataFloat> = None;

/// Peeks into an entity's object schema and retrieves the color value at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (vec4):
/// The color value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataColor(entityHandle: i32, offset: i32) -> Vec4 {
    unsafe { __s2sdk_GetEntDataColor.expect("GetEntDataColor function was not found")(entityHandle, offset) }
}
pub type _GetEntDataColor = unsafe extern "C" fn(i32, i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataColor: Option<_GetEntDataColor> = None;

/// Peeks into an entity's object data and sets the color at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (vec4): The color value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataColor(entityHandle: i32, offset: i32, value: &Vec4, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataColor.expect("SetEntDataColor function was not found")(entityHandle, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataColor = unsafe extern "C" fn(i32, i32, &Vec4, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataColor: Option<_SetEntDataColor> = None;

/// Peeks into an entity's object schema and retrieves the string value at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (string):
/// The string value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataString(entityHandle: i32, offset: i32) -> Str {
    unsafe { __s2sdk_GetEntDataString.expect("GetEntDataString function was not found")(entityHandle, offset) }
}
pub type _GetEntDataString = unsafe extern "C" fn(i32, i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataString: Option<_GetEntDataString> = None;

/// Peeks into an entity's object data and sets the string at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (string): The string value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataString(entityHandle: i32, offset: i32, value: &Str, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataString.expect("SetEntDataString function was not found")(entityHandle, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataString = unsafe extern "C" fn(i32, i32, &Str, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataString: Option<_SetEntDataString> = None;

/// Peeks into an entity's object schema and retrieves the string value at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `size` - (int32): Number of bytes to read.
///
/// # Returns - (string):
/// The string value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataCString(entityHandle: i32, offset: i32, size: i32) -> Str {
    unsafe { __s2sdk_GetEntDataCString.expect("GetEntDataCString function was not found")(entityHandle, offset, size) }
}
pub type _GetEntDataCString = unsafe extern "C" fn(i32, i32, i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataCString: Option<_GetEntDataCString> = None;

/// Peeks into an entity's object data and sets the string at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (string): The string value to set.
/// * `size` - (int32): Number of bytes to write.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataCString(entityHandle: i32, offset: i32, value: &Str, size: i32, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataCString.expect("SetEntDataCString function was not found")(entityHandle, offset, value, size, changeState, chainOffset) }
}
pub type _SetEntDataCString = unsafe extern "C" fn(i32, i32, &Str, i32, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataCString: Option<_SetEntDataCString> = None;

/// Peeks into an entity's object schema and retrieves the vector value at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (vec3):
/// The vector value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataVector3D(entityHandle: i32, offset: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntDataVector3D.expect("GetEntDataVector3D function was not found")(entityHandle, offset) }
}
pub type _GetEntDataVector3D = unsafe extern "C" fn(i32, i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataVector3D: Option<_GetEntDataVector3D> = None;

/// Peeks into an entity's object data and sets the vector at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (vec3): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataVector3D(entityHandle: i32, offset: i32, value: &Vec3, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataVector3D.expect("SetEntDataVector3D function was not found")(entityHandle, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataVector3D = unsafe extern "C" fn(i32, i32, &Vec3, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataVector3D: Option<_SetEntDataVector3D> = None;

/// Peeks into an entity's object schema and retrieves the vector value at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (vec4):
/// The vector value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataVector4D(entityHandle: i32, offset: i32) -> Vec4 {
    unsafe { __s2sdk_GetEntDataVector4D.expect("GetEntDataVector4D function was not found")(entityHandle, offset) }
}
pub type _GetEntDataVector4D = unsafe extern "C" fn(i32, i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataVector4D: Option<_GetEntDataVector4D> = None;

/// Peeks into an entity's object data and sets the vector at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (vec4): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataVector4D(entityHandle: i32, offset: i32, value: &Vec4, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataVector4D.expect("SetEntDataVector4D function was not found")(entityHandle, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataVector4D = unsafe extern "C" fn(i32, i32, &Vec4, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataVector4D: Option<_SetEntDataVector4D> = None;

/// Peeks into an entity's object schema and retrieves the vector value at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (vec2):
/// The vector value at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataVector2D(entityHandle: i32, offset: i32) -> Vec2 {
    unsafe { __s2sdk_GetEntDataVector2D.expect("GetEntDataVector2D function was not found")(entityHandle, offset) }
}
pub type _GetEntDataVector2D = unsafe extern "C" fn(i32, i32) -> Vec2;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataVector2D: Option<_GetEntDataVector2D> = None;

/// Peeks into an entity's object data and sets the vector at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (vec2): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataVector2D(entityHandle: i32, offset: i32, value: &Vec2, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataVector2D.expect("SetEntDataVector2D function was not found")(entityHandle, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataVector2D = unsafe extern "C" fn(i32, i32, &Vec2, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataVector2D: Option<_SetEntDataVector2D> = None;

/// Peeks into an entity's object data and retrieves the entity handle at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
///
/// # Returns - (int32):
/// The entity handle at the given memory location.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntDataEnt(entityHandle: i32, offset: i32) -> i32 {
    unsafe { __s2sdk_GetEntDataEnt.expect("GetEntDataEnt function was not found")(entityHandle, offset) }
}
pub type _GetEntDataEnt = unsafe extern "C" fn(i32, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntDataEnt: Option<_GetEntDataEnt> = None;

/// Peeks into an entity's object data and sets the entity handle at the given offset.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `value` - (int32): The entity handle to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntDataEnt(entityHandle: i32, offset: i32, value: i32, changeState: bool, chainOffset: i32) {
    unsafe { __s2sdk_SetEntDataEnt.expect("SetEntDataEnt function was not found")(entityHandle, offset, value, changeState, chainOffset) }
}
pub type _SetEntDataEnt = unsafe extern "C" fn(i32, i32, i32, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntDataEnt: Option<_SetEntDataEnt> = None;

/// Updates the networked state of a schema field for a given entity handle.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `offset` - (int32): The offset of the schema to use.
/// * `chainOffset` - (int32): The offset of the chain entity in the class (-2 for non-entity classes).
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn ChangeEntityState(entityHandle: i32, offset: i32, chainOffset: i32) {
    unsafe { __s2sdk_ChangeEntityState.expect("ChangeEntityState function was not found")(entityHandle, offset, chainOffset) }
}
pub type _ChangeEntityState = unsafe extern "C" fn(i32, i32, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_ChangeEntityState: Option<_ChangeEntityState> = None;

/// Retrieves the count of values that an entity schema's array can store.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
///
/// # Returns - (int32):
/// Size of array (in elements) or 0 if schema is not an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaArraySize2(entity: usize, className: &Str, memberName: &Str) -> i32 {
    unsafe { __s2sdk_GetEntSchemaArraySize2.expect("GetEntSchemaArraySize2 function was not found")(entity, className, memberName) }
}
pub type _GetEntSchemaArraySize2 = unsafe extern "C" fn(usize, &Str, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaArraySize2: Option<_GetEntSchemaArraySize2> = None;

/// Retrieves an integer value from an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (int64):
/// An integer value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchema2(entity: usize, className: &Str, memberName: &Str, element: i32) -> i64 {
    unsafe { __s2sdk_GetEntSchema2.expect("GetEntSchema2 function was not found")(entity, className, memberName, element) }
}
pub type _GetEntSchema2 = unsafe extern "C" fn(usize, &Str, &Str, i32) -> i64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchema2: Option<_GetEntSchema2> = None;

/// Sets an integer value in an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (int64): The integer value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchema2(entity: usize, className: &Str, memberName: &Str, value: i64, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchema2.expect("SetEntSchema2 function was not found")(entity, className, memberName, value, changeState, element) }
}
pub type _SetEntSchema2 = unsafe extern "C" fn(usize, &Str, &Str, i64, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchema2: Option<_SetEntSchema2> = None;

/// Retrieves a float value from an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (double):
/// A float value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaFloat2(entity: usize, className: &Str, memberName: &Str, element: i32) -> f64 {
    unsafe { __s2sdk_GetEntSchemaFloat2.expect("GetEntSchemaFloat2 function was not found")(entity, className, memberName, element) }
}
pub type _GetEntSchemaFloat2 = unsafe extern "C" fn(usize, &Str, &Str, i32) -> f64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaFloat2: Option<_GetEntSchemaFloat2> = None;

/// Sets a float value in an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (double): The float value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaFloat2(entity: usize, className: &Str, memberName: &Str, value: f64, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaFloat2.expect("SetEntSchemaFloat2 function was not found")(entity, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaFloat2 = unsafe extern "C" fn(usize, &Str, &Str, f64, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaFloat2: Option<_SetEntSchemaFloat2> = None;

/// Retrieves a color value from an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (vec4):
/// A color value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaColor2(entity: usize, className: &Str, memberName: &Str, element: i32) -> Vec4 {
    unsafe { __s2sdk_GetEntSchemaColor2.expect("GetEntSchemaColor2 function was not found")(entity, className, memberName, element) }
}
pub type _GetEntSchemaColor2 = unsafe extern "C" fn(usize, &Str, &Str, i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaColor2: Option<_GetEntSchemaColor2> = None;

/// Sets a color value in an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (vec4): The color value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaColor2(entity: usize, className: &Str, memberName: &Str, value: &Vec4, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaColor2.expect("SetEntSchemaColor2 function was not found")(entity, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaColor2 = unsafe extern "C" fn(usize, &Str, &Str, &Vec4, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaColor2: Option<_SetEntSchemaColor2> = None;

/// Retrieves a string value from an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (string):
/// A string value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaString2(entity: usize, className: &Str, memberName: &Str, element: i32) -> Str {
    unsafe { __s2sdk_GetEntSchemaString2.expect("GetEntSchemaString2 function was not found")(entity, className, memberName, element) }
}
pub type _GetEntSchemaString2 = unsafe extern "C" fn(usize, &Str, &Str, i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaString2: Option<_GetEntSchemaString2> = None;

/// Sets a string value in an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (string): The string value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaString2(entity: usize, className: &Str, memberName: &Str, value: &Str, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaString2.expect("SetEntSchemaString2 function was not found")(entity, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaString2 = unsafe extern "C" fn(usize, &Str, &Str, &Str, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaString2: Option<_SetEntSchemaString2> = None;

/// Retrieves a vector value from an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (vec3):
/// A vector value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaVector3D2(entity: usize, className: &Str, memberName: &Str, element: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntSchemaVector3D2.expect("GetEntSchemaVector3D2 function was not found")(entity, className, memberName, element) }
}
pub type _GetEntSchemaVector3D2 = unsafe extern "C" fn(usize, &Str, &Str, i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaVector3D2: Option<_GetEntSchemaVector3D2> = None;

/// Sets a vector value in an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (vec3): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaVector3D2(entity: usize, className: &Str, memberName: &Str, value: &Vec3, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaVector3D2.expect("SetEntSchemaVector3D2 function was not found")(entity, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaVector3D2 = unsafe extern "C" fn(usize, &Str, &Str, &Vec3, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaVector3D2: Option<_SetEntSchemaVector3D2> = None;

/// Retrieves a vector value from an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (vec2):
/// A vector value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaVector2D2(entity: usize, className: &Str, memberName: &Str, element: i32) -> Vec2 {
    unsafe { __s2sdk_GetEntSchemaVector2D2.expect("GetEntSchemaVector2D2 function was not found")(entity, className, memberName, element) }
}
pub type _GetEntSchemaVector2D2 = unsafe extern "C" fn(usize, &Str, &Str, i32) -> Vec2;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaVector2D2: Option<_GetEntSchemaVector2D2> = None;

/// Sets a vector value in an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (vec2): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaVector2D2(entity: usize, className: &Str, memberName: &Str, value: &Vec2, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaVector2D2.expect("SetEntSchemaVector2D2 function was not found")(entity, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaVector2D2 = unsafe extern "C" fn(usize, &Str, &Str, &Vec2, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaVector2D2: Option<_SetEntSchemaVector2D2> = None;

/// Retrieves a vector value from an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (vec4):
/// A vector value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaVector4D2(entity: usize, className: &Str, memberName: &Str, element: i32) -> Vec4 {
    unsafe { __s2sdk_GetEntSchemaVector4D2.expect("GetEntSchemaVector4D2 function was not found")(entity, className, memberName, element) }
}
pub type _GetEntSchemaVector4D2 = unsafe extern "C" fn(usize, &Str, &Str, i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaVector4D2: Option<_GetEntSchemaVector4D2> = None;

/// Sets a vector value in an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (vec4): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaVector4D2(entity: usize, className: &Str, memberName: &Str, value: &Vec4, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaVector4D2.expect("SetEntSchemaVector4D2 function was not found")(entity, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaVector4D2 = unsafe extern "C" fn(usize, &Str, &Str, &Vec4, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaVector4D2: Option<_SetEntSchemaVector4D2> = None;

/// Retrieves an entity handle from an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (int32):
/// A string value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaEnt2(entity: usize, className: &Str, memberName: &Str, element: i32) -> i32 {
    unsafe { __s2sdk_GetEntSchemaEnt2.expect("GetEntSchemaEnt2 function was not found")(entity, className, memberName, element) }
}
pub type _GetEntSchemaEnt2 = unsafe extern "C" fn(usize, &Str, &Str, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaEnt2: Option<_GetEntSchemaEnt2> = None;

/// Sets an entity handle in an entity's schema.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (int32): The entity handle to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaEnt2(entity: usize, className: &Str, memberName: &Str, value: i32, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaEnt2.expect("SetEntSchemaEnt2 function was not found")(entity, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaEnt2 = unsafe extern "C" fn(usize, &Str, &Str, i32, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaEnt2: Option<_SetEntSchemaEnt2> = None;

/// Pushes an entity handle into an entity's schema collection.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be pushed.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (int32): The entity handle to push.
/// * `changeState` - (bool): If true, change will be sent over the network.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PushEntSchemaEnt2(entity: usize, className: &Str, memberName: &Str, value: i32, changeState: bool) {
    unsafe { __s2sdk_PushEntSchemaEnt2.expect("PushEntSchemaEnt2 function was not found")(entity, className, memberName, value, changeState) }
}
pub type _PushEntSchemaEnt2 = unsafe extern "C" fn(usize, &Str, &Str, i32, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PushEntSchemaEnt2: Option<_PushEntSchemaEnt2> = None;

/// Erases an entity handle from an entity's schema collection by index.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be erased.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element index to erase (starting from 0).
/// * `changeState` - (bool): If true, change will be sent over the network.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn EraseEntSchemaEnt2(entity: usize, className: &Str, memberName: &Str, element: i32, changeState: bool) {
    unsafe { __s2sdk_EraseEntSchemaEnt2.expect("EraseEntSchemaEnt2 function was not found")(entity, className, memberName, element, changeState) }
}
pub type _EraseEntSchemaEnt2 = unsafe extern "C" fn(usize, &Str, &Str, i32, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_EraseEntSchemaEnt2: Option<_EraseEntSchemaEnt2> = None;

/// Updates the networked state of a schema field for a given entity pointer.
///
/// # Arguments
/// * `entity` - (ptr64): Pointer to the instance of the class where the value is to be set.
/// * `className` - (string): The name of the class that contains the member.
/// * `memberName` - (string): The name of the member to be set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn NetworkStateChanged2(entity: usize, className: &Str, memberName: &Str) {
    unsafe { __s2sdk_NetworkStateChanged2.expect("NetworkStateChanged2 function was not found")(entity, className, memberName) }
}
pub type _NetworkStateChanged2 = unsafe extern "C" fn(usize, &Str, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_NetworkStateChanged2: Option<_NetworkStateChanged2> = None;

/// Retrieves the count of values that an entity schema's array can store.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
///
/// # Returns - (int32):
/// Size of array (in elements) or 0 if schema is not an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaArraySize(entityHandle: i32, className: &Str, memberName: &Str) -> i32 {
    unsafe { __s2sdk_GetEntSchemaArraySize.expect("GetEntSchemaArraySize function was not found")(entityHandle, className, memberName) }
}
pub type _GetEntSchemaArraySize = unsafe extern "C" fn(i32, &Str, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaArraySize: Option<_GetEntSchemaArraySize> = None;

/// Retrieves an integer value from an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (int64):
/// An integer value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchema(entityHandle: i32, className: &Str, memberName: &Str, element: i32) -> i64 {
    unsafe { __s2sdk_GetEntSchema.expect("GetEntSchema function was not found")(entityHandle, className, memberName, element) }
}
pub type _GetEntSchema = unsafe extern "C" fn(i32, &Str, &Str, i32) -> i64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchema: Option<_GetEntSchema> = None;

/// Sets an integer value in an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (int64): The integer value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchema(entityHandle: i32, className: &Str, memberName: &Str, value: i64, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchema.expect("SetEntSchema function was not found")(entityHandle, className, memberName, value, changeState, element) }
}
pub type _SetEntSchema = unsafe extern "C" fn(i32, &Str, &Str, i64, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchema: Option<_SetEntSchema> = None;

/// Retrieves a float value from an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (double):
/// A float value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaFloat(entityHandle: i32, className: &Str, memberName: &Str, element: i32) -> f64 {
    unsafe { __s2sdk_GetEntSchemaFloat.expect("GetEntSchemaFloat function was not found")(entityHandle, className, memberName, element) }
}
pub type _GetEntSchemaFloat = unsafe extern "C" fn(i32, &Str, &Str, i32) -> f64;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaFloat: Option<_GetEntSchemaFloat> = None;

/// Sets a float value in an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (double): The float value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaFloat(entityHandle: i32, className: &Str, memberName: &Str, value: f64, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaFloat.expect("SetEntSchemaFloat function was not found")(entityHandle, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaFloat = unsafe extern "C" fn(i32, &Str, &Str, f64, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaFloat: Option<_SetEntSchemaFloat> = None;

/// Retrieves a color value from an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (vec4):
/// A color value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaColor(entityHandle: i32, className: &Str, memberName: &Str, element: i32) -> Vec4 {
    unsafe { __s2sdk_GetEntSchemaColor.expect("GetEntSchemaColor function was not found")(entityHandle, className, memberName, element) }
}
pub type _GetEntSchemaColor = unsafe extern "C" fn(i32, &Str, &Str, i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaColor: Option<_GetEntSchemaColor> = None;

/// Sets a color value in an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (vec4): The color value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaColor(entityHandle: i32, className: &Str, memberName: &Str, value: &Vec4, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaColor.expect("SetEntSchemaColor function was not found")(entityHandle, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaColor = unsafe extern "C" fn(i32, &Str, &Str, &Vec4, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaColor: Option<_SetEntSchemaColor> = None;

/// Retrieves a string value from an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (string):
/// A string value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaString(entityHandle: i32, className: &Str, memberName: &Str, element: i32) -> Str {
    unsafe { __s2sdk_GetEntSchemaString.expect("GetEntSchemaString function was not found")(entityHandle, className, memberName, element) }
}
pub type _GetEntSchemaString = unsafe extern "C" fn(i32, &Str, &Str, i32) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaString: Option<_GetEntSchemaString> = None;

/// Sets a string value in an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (string): The string value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaString(entityHandle: i32, className: &Str, memberName: &Str, value: &Str, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaString.expect("SetEntSchemaString function was not found")(entityHandle, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaString = unsafe extern "C" fn(i32, &Str, &Str, &Str, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaString: Option<_SetEntSchemaString> = None;

/// Retrieves a vector value from an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (vec3):
/// A string value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaVector3D(entityHandle: i32, className: &Str, memberName: &Str, element: i32) -> Vec3 {
    unsafe { __s2sdk_GetEntSchemaVector3D.expect("GetEntSchemaVector3D function was not found")(entityHandle, className, memberName, element) }
}
pub type _GetEntSchemaVector3D = unsafe extern "C" fn(i32, &Str, &Str, i32) -> Vec3;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaVector3D: Option<_GetEntSchemaVector3D> = None;

/// Sets a vector value in an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (vec3): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaVector3D(entityHandle: i32, className: &Str, memberName: &Str, value: &Vec3, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaVector3D.expect("SetEntSchemaVector3D function was not found")(entityHandle, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaVector3D = unsafe extern "C" fn(i32, &Str, &Str, &Vec3, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaVector3D: Option<_SetEntSchemaVector3D> = None;

/// Retrieves a vector value from an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (vec2):
/// A string value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaVector2D(entityHandle: i32, className: &Str, memberName: &Str, element: i32) -> Vec2 {
    unsafe { __s2sdk_GetEntSchemaVector2D.expect("GetEntSchemaVector2D function was not found")(entityHandle, className, memberName, element) }
}
pub type _GetEntSchemaVector2D = unsafe extern "C" fn(i32, &Str, &Str, i32) -> Vec2;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaVector2D: Option<_GetEntSchemaVector2D> = None;

/// Sets a vector value in an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (vec2): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaVector2D(entityHandle: i32, className: &Str, memberName: &Str, value: &Vec2, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaVector2D.expect("SetEntSchemaVector2D function was not found")(entityHandle, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaVector2D = unsafe extern "C" fn(i32, &Str, &Str, &Vec2, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaVector2D: Option<_SetEntSchemaVector2D> = None;

/// Retrieves a vector value from an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (vec4):
/// A string value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaVector4D(entityHandle: i32, className: &Str, memberName: &Str, element: i32) -> Vec4 {
    unsafe { __s2sdk_GetEntSchemaVector4D.expect("GetEntSchemaVector4D function was not found")(entityHandle, className, memberName, element) }
}
pub type _GetEntSchemaVector4D = unsafe extern "C" fn(i32, &Str, &Str, i32) -> Vec4;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaVector4D: Option<_GetEntSchemaVector4D> = None;

/// Sets a vector value in an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (vec4): The vector value to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaVector4D(entityHandle: i32, className: &Str, memberName: &Str, value: &Vec4, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaVector4D.expect("SetEntSchemaVector4D function was not found")(entityHandle, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaVector4D = unsafe extern "C" fn(i32, &Str, &Str, &Vec4, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaVector4D: Option<_SetEntSchemaVector4D> = None;

/// Retrieves an entity handle from an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
///
/// # Returns - (int32):
/// A string value at the given schema offset.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetEntSchemaEnt(entityHandle: i32, className: &Str, memberName: &Str, element: i32) -> i32 {
    unsafe { __s2sdk_GetEntSchemaEnt.expect("GetEntSchemaEnt function was not found")(entityHandle, className, memberName, element) }
}
pub type _GetEntSchemaEnt = unsafe extern "C" fn(i32, &Str, &Str, i32) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetEntSchemaEnt: Option<_GetEntSchemaEnt> = None;

/// Sets an entity handle in an entity's schema.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (int32): The entity handle to set.
/// * `changeState` - (bool): If true, change will be sent over the network.
/// * `element` - (int32): Element # (starting from 0) if schema is an array.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn SetEntSchemaEnt(entityHandle: i32, className: &Str, memberName: &Str, value: i32, changeState: bool, element: i32) {
    unsafe { __s2sdk_SetEntSchemaEnt.expect("SetEntSchemaEnt function was not found")(entityHandle, className, memberName, value, changeState, element) }
}
pub type _SetEntSchemaEnt = unsafe extern "C" fn(i32, &Str, &Str, i32, bool, i32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_SetEntSchemaEnt: Option<_SetEntSchemaEnt> = None;

/// Pushes an entity handle into an entity's schema collection.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose schema collection is modified.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `value` - (int32): The entity handle to push.
/// * `changeState` - (bool): If true, change will be sent over the network.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn PushEntSchemaEnt(entityHandle: i32, className: &Str, memberName: &Str, value: i32, changeState: bool) {
    unsafe { __s2sdk_PushEntSchemaEnt.expect("PushEntSchemaEnt function was not found")(entityHandle, className, memberName, value, changeState) }
}
pub type _PushEntSchemaEnt = unsafe extern "C" fn(i32, &Str, &Str, i32, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_PushEntSchemaEnt: Option<_PushEntSchemaEnt> = None;

/// Erases an entity handle from an entity's schema collection by index.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity whose schema collection is modified.
/// * `className` - (string): The name of the class.
/// * `memberName` - (string): The name of the schema member.
/// * `element` - (int32): Element index to erase (starting from 0).
/// * `changeState` - (bool): If true, change will be sent over the network.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn EraseEntSchemaEnt(entityHandle: i32, className: &Str, memberName: &Str, element: i32, changeState: bool) {
    unsafe { __s2sdk_EraseEntSchemaEnt.expect("EraseEntSchemaEnt function was not found")(entityHandle, className, memberName, element, changeState) }
}
pub type _EraseEntSchemaEnt = unsafe extern "C" fn(i32, &Str, &Str, i32, bool);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_EraseEntSchemaEnt: Option<_EraseEntSchemaEnt> = None;

/// Updates the networked state of a schema field for a given entity handle.
///
/// # Arguments
/// * `entityHandle` - (int32): The handle of the entity from which the value is to be retrieved.
/// * `className` - (string): The name of the class that contains the member.
/// * `memberName` - (string): The name of the member to be set.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn NetworkStateChanged(entityHandle: i32, className: &Str, memberName: &Str) {
    unsafe { __s2sdk_NetworkStateChanged.expect("NetworkStateChanged function was not found")(entityHandle, className, memberName) }
}
pub type _NetworkStateChanged = unsafe extern "C" fn(i32, &Str, &Str);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_NetworkStateChanged: Option<_NetworkStateChanged> = None;

