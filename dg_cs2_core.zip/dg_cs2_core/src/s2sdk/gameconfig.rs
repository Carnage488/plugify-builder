// Generated from s2sdk.pplugin (group: gameconfig)

#[allow(unused_imports)]
use std::sync::RwLock;
#[allow(unused_imports)]
use super::enums::*;
#[allow(unused_imports)]
use super::aliases::*;
#[allow(unused_imports)]
use super::delegates::*;
#[allow(unused_imports)]
use plugify::{scope, Str, Arr, Var, Vec2, Vec3, Vec4, Mat4x4};

/// Closes a game configuration file.
///
/// # Arguments
/// * `id` - (uint32): An id to the game configuration to be closed.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn CloseGameConfigFile(id: u32) {
    unsafe { __s2sdk_CloseGameConfigFile.expect("CloseGameConfigFile function was not found")(id) }
}
pub type _CloseGameConfigFile = unsafe extern "C" fn(u32);
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_CloseGameConfigFile: Option<_CloseGameConfigFile> = None;

/// Loads a game configuration file.
///
/// # Arguments
/// * `paths` - (string[]): The paths to the game configuration file to be loaded.
///
/// # Returns - (uint32):
/// A id to the loaded game configuration object, or -1 if loading fails.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn LoadGameConfigFile(paths: &Arr<Str>) -> u32 {
    unsafe { __s2sdk_LoadGameConfigFile.expect("LoadGameConfigFile function was not found")(paths) }
}
pub type _LoadGameConfigFile = unsafe extern "C" fn(&Arr<Str>) -> u32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_LoadGameConfigFile: Option<_LoadGameConfigFile> = None;

/// Retrieves a patch associated with the game configuration.
///
/// # Arguments
/// * `id` - (uint32): An id to the game configuration from which to retrieve the patch.
/// * `name` - (string): The name of the patch to be retrieved.
///
/// # Returns - (string):
/// A string where the patch will be stored.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameConfigPatch(id: u32, name: &Str) -> Str {
    unsafe { __s2sdk_GetGameConfigPatch.expect("GetGameConfigPatch function was not found")(id, name) }
}
pub type _GetGameConfigPatch = unsafe extern "C" fn(u32, &Str) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameConfigPatch: Option<_GetGameConfigPatch> = None;

/// Retrieves the offset associated with a name from the game configuration.
///
/// # Arguments
/// * `id` - (uint32): An id to the game configuration from which to retrieve the offset.
/// * `name` - (string): The name whose offset is to be retrieved.
///
/// # Returns - (int32):
/// The offset associated with the specified name.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameConfigOffset(id: u32, name: &Str) -> i32 {
    unsafe { __s2sdk_GetGameConfigOffset.expect("GetGameConfigOffset function was not found")(id, name) }
}
pub type _GetGameConfigOffset = unsafe extern "C" fn(u32, &Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameConfigOffset: Option<_GetGameConfigOffset> = None;

/// Retrieves the address associated with a name from the game configuration.
///
/// # Arguments
/// * `id` - (uint32): An id to the game configuration from which to retrieve the address.
/// * `name` - (string): The name whose address is to be retrieved.
///
/// # Returns - (ptr64):
/// A pointer to the address associated with the specified name.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameConfigAddress(id: u32, name: &Str) -> usize {
    unsafe { __s2sdk_GetGameConfigAddress.expect("GetGameConfigAddress function was not found")(id, name) }
}
pub type _GetGameConfigAddress = unsafe extern "C" fn(u32, &Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameConfigAddress: Option<_GetGameConfigAddress> = None;

/// Retrieves a vtable associated with the game configuration.
///
/// # Arguments
/// * `id` - (uint32): An id to the game configuration from which to retrieve the vtable.
/// * `name` - (string): The name of the vtable to be retrieved.
///
/// # Returns - (ptr64):
/// A pointer to the vtable associated with the specified name
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameConfigVTable(id: u32, name: &Str) -> usize {
    unsafe { __s2sdk_GetGameConfigVTable.expect("GetGameConfigVTable function was not found")(id, name) }
}
pub type _GetGameConfigVTable = unsafe extern "C" fn(u32, &Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameConfigVTable: Option<_GetGameConfigVTable> = None;

/// Retrieves the signature associated with a name from the game configuration.
///
/// # Arguments
/// * `id` - (uint32): An id to the game configuration from which to retrieve the signature.
/// * `name` - (string): The name whose signature is to be resolved and retrieved.
///
/// # Returns - (ptr64):
/// A pointer to the signature associated with the specified name.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameConfigSignature(id: u32, name: &Str) -> usize {
    unsafe { __s2sdk_GetGameConfigSignature.expect("GetGameConfigSignature function was not found")(id, name) }
}
pub type _GetGameConfigSignature = unsafe extern "C" fn(u32, &Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameConfigSignature: Option<_GetGameConfigSignature> = None;

/// Retrieves a patch by scanning all loaded game configurations.
///
/// # Arguments
/// * `name` - (string): The name of the patch to be retrieved.
///
/// # Returns - (string):
/// A string containing the patch, or an empty string if not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameConfigPatchAll(name: &Str) -> Str {
    unsafe { __s2sdk_GetGameConfigPatchAll.expect("GetGameConfigPatchAll function was not found")(name) }
}
pub type _GetGameConfigPatchAll = unsafe extern "C" fn(&Str) -> Str;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameConfigPatchAll: Option<_GetGameConfigPatchAll> = None;

/// Retrieves an offset by scanning all loaded game configurations.
///
/// # Arguments
/// * `name` - (string): The name whose offset is to be retrieved.
///
/// # Returns - (int32):
/// The offset associated with the specified name, or -1 if not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameConfigOffsetAll(name: &Str) -> i32 {
    unsafe { __s2sdk_GetGameConfigOffsetAll.expect("GetGameConfigOffsetAll function was not found")(name) }
}
pub type _GetGameConfigOffsetAll = unsafe extern "C" fn(&Str) -> i32;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameConfigOffsetAll: Option<_GetGameConfigOffsetAll> = None;

/// Retrieves an address by scanning all loaded game configurations.
///
/// # Arguments
/// * `name` - (string): The name whose address is to be retrieved.
///
/// # Returns - (ptr64):
/// A pointer to the address associated with the specified name, or nullptr if not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameConfigAddressAll(name: &Str) -> usize {
    unsafe { __s2sdk_GetGameConfigAddressAll.expect("GetGameConfigAddressAll function was not found")(name) }
}
pub type _GetGameConfigAddressAll = unsafe extern "C" fn(&Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameConfigAddressAll: Option<_GetGameConfigAddressAll> = None;

/// Retrieves a vtable by scanning all loaded game configurations.
///
/// # Arguments
/// * `name` - (string): The name of the vtable to be retrieved.
///
/// # Returns - (ptr64):
/// A pointer to the vtable associated with the specified name, or nullptr if not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameConfigVTableAll(name: &Str) -> usize {
    unsafe { __s2sdk_GetGameConfigVTableAll.expect("GetGameConfigVTableAll function was not found")(name) }
}
pub type _GetGameConfigVTableAll = unsafe extern "C" fn(&Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameConfigVTableAll: Option<_GetGameConfigVTableAll> = None;

/// Retrieves a signature by scanning all loaded game configurations.
///
/// # Arguments
/// * `name` - (string): The name whose signature is to be resolved and retrieved.
///
/// # Returns - (ptr64):
/// A pointer to the signature associated with the specified name, or nullptr if not found.
#[track_caller]
#[allow(dead_code, non_snake_case)]
pub fn GetGameConfigSignatureAll(name: &Str) -> usize {
    unsafe { __s2sdk_GetGameConfigSignatureAll.expect("GetGameConfigSignatureAll function was not found")(name) }
}
pub type _GetGameConfigSignatureAll = unsafe extern "C" fn(&Str) -> usize;
#[allow(dead_code, non_upper_case_globals)]
#[unsafe(no_mangle)]
pub static mut __s2sdk_GetGameConfigSignatureAll: Option<_GetGameConfigSignatureAll> = None;

