use plugify::register_plugin; // Подключаем макрос, который "регистрирует" плагин в движке CS2
use std::error::Error;        // Подключаем стандартный инструмент для работы с любыми ошибками
use std::sync::Mutex;         // Подключаем "электронный замок" для защиты глобальных данных
mod s2sdk;                    // Говорим компилятору: "найди и подключи наш файл s2sdk.rs"
mod chat;                     // Говорим компилятору: "найди и подключи наш файл chat.rs"
mod config;                   // Говорим компилятору: "найди и подключи наш файл config.rs"

// Создаём чертёж (структуру) для хранения состояния нашего таймера
struct AdvertTimer {
    elapsed: f32,              // Сколько секунд прошло с последнего показа рекламы
    current_index: usize,      // Номер текущего сообщения в списке
    interval_seconds: f32,     // Интервал между рекламами из конфига
    messages: Vec<String>,     // Список рекламных сообщений, загруженный из конфига
}

static ADVERT_TIMER: Mutex<AdvertTimer> = Mutex::new(AdvertTimer { // [static ИМЯ: ТИП = СОЗДАТЬ_ОБЪЕКТ]
    elapsed: 0.0,                                                   // Выделяем поле под время и ставим ровно 0.0 секунд
    current_index: 0,                                               // Ставим индекс 0 (начнём показ с самого первого сообщения)
    interval_seconds: 30.0,                                         // Устанавливаем интервал по умолчанию (30 секунд)
    messages: Vec::new(),                                           // Создаем внутри структуры пустой список для будущих строк
});

fn on_plugin_start() -> Result<(), Box<dyn Error>> {               // [Имя функции] -> [Возвращает: Успех или Ошибку]
    println!("[Advert] Plugin successfully loaded");                // Просто выводим текст в консоль сервера

    let config = config::Config::load()?;                          // Пытаемся загрузить настройки из файла. Если что-то пойдет не так, функция сама выкинет ошибку и закроется

    let mut state = ADVERT_TIMER                                   // Создаем изменяемую переменную-ссылку
        .lock()                                                    // Пытаемся открыть замок сейфа
        .map_err(|e| format!("[Advert] Failed to lock advert timer on start: {}", e))?; // Если замок сломан — логируем причину и выходим

    // elapsed = 0.0 — первый показ произойдёт ровно через один полный интервал после старта плагина
    *state = AdvertTimer {                                         // Звёздочка: заменяем внутренности сейфа новой структурой
        elapsed: 0.0,                                              // Сбрасываем секундомер на ноль
        current_index: 0,                                          // Выставляем начальный индекс строки
        interval_seconds: config.adverts.interval_seconds,
        messages: config.adverts.messages,
    };                                                             // Точка с запятой закрывает операцию перезаписи *state

    Ok(())                                                         // Возвращаем знак "Всё прошло успешно, ошибок нет"
}

fn on_plugin_update(dt: f32) -> Result<(), Box<dyn Error>> {
    // Берём сообщение под замком и сразу освобождаем его —
    // FFI-вызов chat::print_colored_to_all происходит уже без удержания мьютекса
    let message_to_send: Option<String> = {
        let mut timer = ADVERT_TIMER                               // Создаем изменяемую переменную-ссылку
            .lock()                                                // Пытаемся открыть замок сейфа
            .map_err(|e| format!("[Advert] Failed to lock advert timer on update: {}", e))?; // Если замок сломан — логируем причину и выходим

        if timer.messages.is_empty() {                             // Если список сообщений пустой — нечего показывать
            None
        } else {
            timer.elapsed += dt;                                   // Добавляем время прошедшего кадра к секундомеру

            if timer.elapsed >= timer.interval_seconds {           // Если секундомер насчитал 30 или больше секунд
                let msg = timer.messages[timer.current_index].clone(); // Берём из списка одну строку по её текущему номеру
                timer.current_index = (timer.current_index + 1) % timer.messages.len(); // Двигаем номер строки на +1, а % крутит их по кругу
                timer.elapsed = 0.0;                               // Обнуляем секундомер, чтобы начать новый отсчёт
                Some(msg)                                          // Возвращаем сообщение наружу из блока
            } else {
                None                                               // Интервал ещё не истёк — ничего не отправляем
            }
        }
    }; // <- замок освобождается здесь, timer выходит из области видимости

    if let Some(msg) = message_to_send {                           // Если сообщение есть — отправляем его в чат
        chat::print_colored_to_all(&msg);                          // Отправляем строку в чат абсолютно всем игрокам
    }

    Ok(())                                                         // Отдаем серверу сигнал: "Кадр посчитан без ошибок"
}

fn on_plugin_end() -> Result<(), Box<dyn Error>> {
    println!("[Advert] Plugin successfully unloaded");             // Выводим текст в консоль сервера при выгрузке
    Ok(())                                                         // Возвращаем знак "Всё прошло успешно, ошибок нет"
}

register_plugin!(
    start: on_plugin_start,
    update: on_plugin_update,
    end: on_plugin_end
);