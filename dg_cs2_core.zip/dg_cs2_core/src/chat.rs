use plugify::Str;

use crate::s2sdk::console;

pub fn print_to_all(message: &str) {
    let msg = Str::from(message);
    console::PrintToChatAll(&msg);
}

pub fn print_colored_to_all(message: &str) {
    let msg = Str::from(message);
    console::PrintToChatColoredAll(&msg);
}

pub fn print_to_player(player_slot: i32, message: &str) {
    let msg = Str::from(message);
    console::PrintToChat(player_slot, &msg);
}